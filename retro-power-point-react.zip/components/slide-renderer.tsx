"use client"

import { motion } from "framer-motion"
import type { Slide, SlideElement } from "@/lib/slides"

interface SlideRendererProps {
  slide: Slide
  direction: number
}

function renderElement(element: SlideElement, index: number) {
  const delay = element.delay || 0

  switch (element.type) {
    case "boot-sequence":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.3 }}
          className="space-y-2 text-left"
        >
          <div className="text-xs text-muted-foreground mb-4">BOOTING STAR-OPS SYSTEM...</div>
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.4, duration: 0.3 }}
              className="flex items-center gap-3 text-sm"
            >
              <span className="text-muted-foreground">{item.label}</span>
              <span className="flex-1 text-muted-foreground/30">{"."}</span>
              <span className={item.status === "ok" ? "text-primary text-glow" : "text-secondary"}>{item.value}</span>
            </motion.div>
          ))}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: delay + (element.items?.length || 0) * 0.4 + 0.3, duration: 0.3 }}
            className="text-primary text-glow mt-4 text-sm"
          >
            ACCESS GRANTED
          </motion.div>
        </motion.div>
      )

    case "ascii-title":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay, duration: 0.5 }}
          className="text-center my-6"
        >
          <h1 className="text-5xl md:text-7xl font-bold text-primary text-glow tracking-widest">{element.content}</h1>
        </motion.div>
      )

    case "command":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.3 }}
          className="mb-4"
        >
          <span className="text-primary text-glow">{element.command}</span>
          <span className="cursor-blink text-primary">█</span>
        </motion.div>
      )

    case "output":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay, duration: 0.4 }}
          className="text-muted-foreground whitespace-pre-line leading-relaxed text-base md:text-lg"
        >
          {element.content}
        </motion.div>
      )

    case "alert":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.3 }}
          className="my-4 p-4 border border-destructive bg-destructive/10"
        >
          <pre className="text-destructive text-glow-red whitespace-pre-line text-sm md:text-base font-bold">
            {element.content}
          </pre>
        </motion.div>
      )

    case "telemetry":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 space-y-3"
        >
          {element.content && (
            <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">{element.content}</div>
          )}
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.15, duration: 0.3 }}
              className="flex items-center gap-4"
            >
              <span
                className={`text-sm w-28 ${
                  item.status === "ok"
                    ? "text-primary"
                    : item.status === "warn"
                      ? "text-secondary"
                      : item.status === "error"
                        ? "text-destructive"
                        : "text-accent"
                }`}
              >
                {item.label}
              </span>
              <span
                className={`font-mono text-sm ${
                  item.status === "ok"
                    ? "text-primary text-glow"
                    : item.status === "warn"
                      ? "text-secondary text-glow-amber"
                      : item.status === "error"
                        ? "text-destructive text-glow-red"
                        : "text-accent text-glow-cyan"
                }`}
              >
                {item.value}
              </span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "system-status":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-4 space-y-2"
        >
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay + i * 0.1, duration: 0.3 }}
              className="flex items-start gap-3 text-sm md:text-base"
            >
              <span
                className={`${
                  item.status === "ok"
                    ? "text-primary"
                    : item.status === "warn"
                      ? "text-secondary"
                      : item.status === "error"
                        ? "text-destructive"
                        : "text-accent"
                }`}
              >
                {item.status === "ok"
                  ? "[✓]"
                  : item.status === "warn"
                    ? "[!]"
                    : item.status === "error"
                      ? "[✗]"
                      : "[i]"}
              </span>
              <span className="text-muted-foreground">{item.label}:</span>
              <span className="text-foreground">{item.value}</span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "module-grid":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          {element.modules?.map((mod, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: delay + i * 0.15, duration: 0.3 }}
              className="p-4 border border-border hover:border-primary transition-colors pulse-glow"
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-primary text-glow font-bold">{mod.name}</span>
                <span
                  className={`text-xs px-2 py-0.5 ${
                    mod.status === "ACTIVE"
                      ? "bg-primary/20 text-primary"
                      : mod.status === "HIGH"
                        ? "bg-primary/20 text-primary"
                        : "bg-muted text-muted-foreground"
                  }`}
                >
                  {mod.status}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mb-1">{mod.path}</div>
              <div className="text-sm text-foreground">{mod.description}</div>
            </motion.div>
          ))}
        </motion.div>
      )

    case "comparison-terminal":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          {element.columns?.map((col, i) => (
            <div key={i} className={`p-4 border ${col.highlight ? "border-primary bg-primary/5" : "border-border"}`}>
              <div
                className={`text-sm font-bold mb-3 ${col.highlight ? "text-primary text-glow" : "text-muted-foreground"}`}
              >
                {col.title}
              </div>
              <ul className="space-y-2">
                {col.items.map((item, j) => (
                  <li key={j} className="flex items-start gap-2 text-sm">
                    <span className={col.highlight ? "text-primary" : "text-muted-foreground"}>▸</span>
                    <span className={col.highlight ? "text-foreground" : "text-muted-foreground"}>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </motion.div>
      )

    case "table-terminal":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 overflow-x-auto"
        >
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-primary">
                {element.tableHeaders?.map((header, i) => (
                  <th key={i} className="text-left py-2 px-3 text-primary text-glow font-bold">
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {element.tableRows?.map((row, i) => (
                <tr key={i} className="border-b border-border">
                  {row.cells.map((cell, j) => (
                    <td
                      key={j}
                      className={`py-2 px-3 ${j === 0 ? "text-accent text-glow-cyan" : "text-muted-foreground"}`}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )

    case "kpi-readout":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 space-y-2"
        >
          {element.kpis?.map((kpi, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.1, duration: 0.3 }}
              className="flex items-center gap-4 text-sm border-b border-border py-2"
            >
              <span className="text-primary w-32">{kpi.component}</span>
              <span className="text-foreground flex-1">{kpi.kpi}</span>
              <span className="text-muted-foreground">{kpi.value}</span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "progress-list":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-4 space-y-2"
        >
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.15, duration: 0.3 }}
              className="flex items-center gap-3 text-sm md:text-base"
            >
              <span
                className={`text-xs px-2 py-0.5 ${
                  item.status === "ok" || item.status === "info"
                    ? "bg-primary/20 text-primary"
                    : item.status === "warn"
                      ? "bg-secondary/20 text-secondary"
                      : "bg-destructive/20 text-destructive"
                }`}
              >
                {item.value}
              </span>
              <span className="text-muted-foreground">{item.label}</span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "quote-terminal":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-4 p-4 border-l-2 border-accent bg-accent/5"
        >
          <pre className="text-accent text-glow-cyan whitespace-pre-line text-sm md:text-base">{element.content}</pre>
        </motion.div>
      )

    case "image-placeholder":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 w-full max-w-2xl mx-auto aspect-video border border-dashed border-primary/50 flex items-center justify-center bg-primary/5"
        >
          <pre className="text-primary/60 text-center text-sm whitespace-pre-line">{element.content}</pre>
        </motion.div>
      )

    default:
      return null
  }
}

export default function SlideRenderer({ slide }: SlideRendererProps) {
  const layoutClasses = {
    default: "items-start justify-start text-left",
    title: "items-center justify-center text-center",
    centered: "items-center justify-center text-center",
    "two-column": "items-start justify-start text-left",
    command: "items-start justify-start text-left",
  }

  return (
    <motion.div
      className={`absolute inset-0 flex flex-col p-6 md:p-10 overflow-y-auto ${layoutClasses[slide.layout || "default"]}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className={`w-full ${slide.layout === "title" || slide.layout === "centered" ? "max-w-3xl" : "max-w-5xl"}`}>
        {slide.elements.map((element, index) => renderElement(element, index))}
      </div>
    </motion.div>
  )
}
