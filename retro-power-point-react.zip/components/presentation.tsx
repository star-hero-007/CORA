"use client"

import { useState, useEffect, useCallback } from "react"
import { AnimatePresence } from "framer-motion"
import { slides } from "@/lib/slides"
import SlideRenderer from "./slide-renderer"
import { ChevronLeft, ChevronRight, Home, Grid3X3 } from "lucide-react"

export default function Presentation() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [direction, setDirection] = useState(0)
  const [isGridView, setIsGridView] = useState(false)

  const goToSlide = useCallback(
    (index: number) => {
      setDirection(index > currentSlide ? 1 : -1)
      setCurrentSlide(index)
      setIsGridView(false)
    },
    [currentSlide],
  )

  const nextSlide = useCallback(() => {
    if (currentSlide < slides.length - 1) {
      setDirection(1)
      setCurrentSlide((prev) => prev + 1)
    }
  }, [currentSlide])

  const prevSlide = useCallback(() => {
    if (currentSlide > 0) {
      setDirection(-1)
      setCurrentSlide((prev) => prev - 1)
    }
  }, [currentSlide])

  const goHome = useCallback(() => {
    setDirection(-1)
    setCurrentSlide(0)
  }, [])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " ") {
        nextSlide()
      } else if (e.key === "ArrowLeft") {
        prevSlide()
      } else if (e.key === "Home") {
        goHome()
      } else if (e.key === "g") {
        setIsGridView((prev) => !prev)
      } else if (e.key === "Escape") {
        setIsGridView(false)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [nextSlide, prevSlide, goHome])

  const progress = ((currentSlide + 1) / slides.length) * 100
  const currentCommand = slides[currentSlide].command || "ready"

  return (
    <div className="relative w-screen h-screen flex items-center justify-center p-3 md:p-6 overflow-hidden bg-background grid-bg">
      {/* CRT Scanlines */}
      <div className="crt-overlay" />

      {/* Grid View */}
      {isGridView ? (
        <div className="w-full max-w-6xl z-10">
          <div className="terminal-window">
            <div className="terminal-header">
              <span className="terminal-title">STAR-OPS :: SLIDE INDEX</span>
              <button
                onClick={() => setIsGridView(false)}
                className="ml-auto text-muted-foreground hover:text-primary transition-colors text-xl"
              >
                ×
              </button>
            </div>
            <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-3 max-h-[70vh] overflow-y-auto bg-background">
              {slides.map((slide, index) => (
                <button
                  key={slide.id}
                  onClick={() => goToSlide(index)}
                  className={`grid-thumb aspect-video relative overflow-hidden border ${
                    index === currentSlide
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50 bg-card"
                  }`}
                >
                  <div className="absolute inset-0 p-2 flex flex-col">
                    <p className="text-xs text-primary truncate text-left font-mono">
                      {slide.command || `slide_${index + 1}`}
                    </p>
                  </div>
                  <div className="absolute bottom-1 right-1 text-xs font-mono text-muted-foreground">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3 w-full max-w-6xl z-10">
          {/* Terminal Window */}
          <div className="terminal-window w-full flicker">
            <div className="terminal-header">
              <span className="terminal-title">STAR-OPS :: Secure Terminal Interface v7.3-Alpha</span>
              <span className="ml-auto text-xs text-muted-foreground">
                [{String(currentSlide + 1).padStart(2, "0")}/{slides.length}]
              </span>
            </div>
            <div className="terminal-body">
              <AnimatePresence mode="wait" custom={direction}>
                <SlideRenderer key={currentSlide} slide={slides[currentSlide]} direction={direction} />
              </AnimatePresence>
            </div>
          </div>

          {/* Command Line + Navigation */}
          <div className="flex items-center gap-3 w-full">
            {/* Command Display */}
            <div className="flex-1 flex items-center gap-2 px-3 py-2 border border-border bg-card text-sm">
              <span className="text-muted-foreground">root@cora:~$</span>
              <span className="text-primary text-glow">{currentCommand}</span>
              <span className="cursor-blink text-primary">█</span>
            </div>

            {/* Progress */}
            <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground">
              <span>[</span>
              <div className="w-24 h-1 bg-border">
                <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
              </div>
              <span>]</span>
              <span>{Math.round(progress)}%</span>
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center gap-1">
              <button onClick={goHome} className="nav-btn-terminal" title="Home">
                <Home className="w-4 h-4" />
              </button>
              <button onClick={prevSlide} disabled={currentSlide === 0} className="nav-btn-terminal" title="Prev">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextSlide}
                disabled={currentSlide === slides.length - 1}
                className="nav-btn-terminal"
                title="Next"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <button onClick={() => setIsGridView(true)} className="nav-btn-terminal" title="Grid">
                <Grid3X3 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Keyboard Hints */}
      <div className="fixed bottom-3 left-3 text-xs text-muted-foreground/40 hidden md:flex items-center gap-2 font-mono">
        <span className="kbd-terminal">←</span>
        <span className="kbd-terminal">→</span>
        <span>nav</span>
        <span className="text-border">|</span>
        <span className="kbd-terminal">G</span>
        <span>grid</span>
        <span className="text-border">|</span>
        <span className="kbd-terminal">Home</span>
        <span>first</span>
      </div>
    </div>
  )
}
