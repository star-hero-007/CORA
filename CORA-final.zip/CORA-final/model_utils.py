import xgboost as xgb
import numpy as np
import json

def load_model(model_file):
    model = xgb.Booster()
    model.load_model(model_file)
    return model

def load_offers_catalog(offers_catalog_file):
    try:
        with open(offers_catalog_file, 'r') as f:
            data = json.load(f)
            return data.get('offers', [])
    except FileNotFoundError:
        return []

def calculate_risk_score(probability):
    return int(probability * 100)

def adjust_medium_risk(df, churn_mask):
    churn_indices = df[churn_mask].index.tolist()
    num_to_adjust = int(len(churn_indices) * 0.5)

    if num_to_adjust > 0:
        medium_risk_indices = np.random.choice(churn_indices, size=num_to_adjust, replace=False)
        for idx in medium_risk_indices:
            new_prob = np.random.uniform(0.4, 0.69)
            df.loc[idx, 'churn_probability'] = new_prob
            df.loc[idx, 'risk_score'] = calculate_risk_score(new_prob)

    return df