"use client"

import { useState, useEffect } from "react"
import { AnimatePresence, motion } from "framer-motion"
import { Sidebar } from "@/components/sidebar"
import { Overview } from "@/components/views/overview" 
import { RiskFeed } from "@/components/views/risk-feed" 
import { Customer360 } from "@/components/views/customer-360"
import { OfferLab } from "@/components/views/offer-lab"
import { Simulation } from "@/components/views/simulation"
import { Analytics } from "@/components/views/analytics"
import { ModelOps } from "@/components/views/model-ops"
import type { Offer } from "@/lib/mock-data"
import { Toaster } from "@/components/ui/toaster"
import { useToast } from "@/hooks/use-toast"

interface TimelineEvent {
  date: string
  event: string
  type: "neg" | "pos" | "neu"
}

interface Passenger {
  id: string
  name: string
  email: string
  riskScore: number
  churnDriver: string
  ltv: number
  tier: "Platinum" | "Gold" | "Silver" | "Bronze"
  commChannel: "Email" | "WhatsApp" | "App"
  lastFlight: string
  totalFlights: number
  milesBalance: number
  timeline: TimelineEvent[]
  sentimentScore: number
  openTickets: number
}

interface GeneratedPersona {
  id: string
  name: string
  behavioralTraits: {
    valueSensitivity: number
    frustrationTolerance: number
    loyaltyOrientation: number
    conveniencePreference: number
    serviceRecoveryExpectation: number
    priceElasticity: number
  }
  derivedFrom: string[]
  summary: string
}

export default function CoraApp() {
  const [activeView, setActiveView] = useState("overview")
  const [selectedPassenger, setSelectedPassenger] = useState<Passenger | null>(null)
  const [shortlistedOffers, setShortlistedOffers] = useState<Offer[]>([])
  const [currentPersona, setCurrentPersona] = useState<GeneratedPersona | null>(null)
  const { toast } = useToast()

  const [riskFeedRefreshKey, setRiskFeedRefreshKey] = useState(0)

  const [theme, setTheme] = useState<"light" | "dark">("dark")

  useEffect(() => {
    const savedTheme = localStorage.getItem("cora-theme") as "light" | "dark" | null
    const initialTheme = savedTheme || "dark"
    setTheme(initialTheme)
    document.documentElement.classList.toggle("dark", initialTheme === "dark")
  }, [])

  const handleToggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark"
    setTheme(newTheme)
    localStorage.setItem("cora-theme", newTheme)
    document.documentElement.classList.toggle("dark", newTheme === "dark")
  }

  const handleNavigate = (view: string) => {
    setActiveView(view)
    if (view === "offer-lab" || view === "simulation") {
      if (activeView !== "customer-360" && activeView !== "offer-lab") {
        setSelectedPassenger(null)
        setShortlistedOffers([])
        setCurrentPersona(null)
      }
    }
  }

  const handleNavigateToHome = (view: string) => {
    setActiveView(view)
    setSelectedPassenger(null)
    setShortlistedOffers([])
    setCurrentPersona(null)
  }

  const handleSelectPassenger = (passenger: Passenger) => {
    setSelectedPassenger(passenger)
    setActiveView("customer-360")
    setShortlistedOffers([])
    setCurrentPersona(null)
  }

  const handleShortlistOffers = (passenger: Passenger) => {
    setSelectedPassenger(passenger)
    setActiveView("offer-lab")
  }

  const handleToggleShortlist = (offer: Offer) => {
    setShortlistedOffers((prev) =>
      prev.some((o) => o.id === offer.id) ? prev.filter((o) => o.id !== offer.id) : [...prev, offer],
    )
  }

  const handleRunSimulation = (persona: GeneratedPersona, selectedOffers: Offer[]) => {
    setCurrentPersona(persona)
    setShortlistedOffers(selectedOffers)
    setActiveView("simulation")
  }

  const handleSendOfferFromLab = (offer: Offer) => {
    toast({
      title: "Offer Sent Successfully",
      description: `${offer.title} sent to ${selectedPassenger?.name} via ${selectedPassenger?.commChannel}`,
    })
    setTimeout(() => {
      setShortlistedOffers([])
      setSelectedPassenger(null)
      setCurrentPersona(null)
      setActiveView("overview")
    }, 2000)
  }

  const handleSendOffer = (offer: Offer) => {
    setTimeout(() => {
      setShortlistedOffers([])
      setSelectedPassenger(null)
      setCurrentPersona(null)
      setActiveView("overview")
    }, 2000)
  }
  
  const handleSuccessfulRefresh = () => {
    setRiskFeedRefreshKey(prevKey => prevKey + 1)
  }

  const renderView = () => {
    switch (activeView) {
      case "overview":
        return <Overview onSuccessfulRefresh={handleSuccessfulRefresh} />
      case "risk-feed":
        return <RiskFeed onSelectPassenger={handleSelectPassenger} refreshKey={riskFeedRefreshKey} />
      case "customer-360":
        return <Customer360 passenger={selectedPassenger} onShortlistOffers={handleShortlistOffers} />
      case "offer-lab":
        return (
          <OfferLab
            passenger={selectedPassenger}
            shortlistedOffers={shortlistedOffers}
            onToggleShortlist={handleToggleShortlist}
            onRunSimulation={handleRunSimulation}
            onNavigateHome={() => handleNavigateToHome("offer-lab")}
            onSendOffer={handleSendOfferFromLab}
          />
        )
      case "simulation":
        return (
          <Simulation
            passenger={selectedPassenger}
            shortlistedOffers={shortlistedOffers}
            persona={currentPersona}
            onSendOffer={handleSendOffer}
            onNavigateHome={() => handleNavigateToHome("simulation")}
          />
        )
      case "analytics":
        return <Analytics />
      case "model-ops":
        return <ModelOps />
      default:
        return <Overview onSuccessfulRefresh={handleSuccessfulRefresh} /> 
    }
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 hex-pattern opacity-30 pointer-events-none" />
      <div className="fixed inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none" />

      <Sidebar activeView={activeView} onNavigate={handleNavigate} theme={theme} onToggleTheme={handleToggleTheme} />
      <main className="flex-1 overflow-y-auto relative">
        <div className="min-h-full grid-pattern">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {renderView()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      <Toaster />
    </div>
  )
}