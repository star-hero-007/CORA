export interface Passenger {
  id: string
  name: string
  email: string
  riskScore: number
  churnDriver: string
  ltv: number
  tier: "Platinum" | "Gold" | "Silver" | "Bronze"
  commChannel: "Email" | "WhatsApp" | "App"
  lastFlight: string
  totalFlights: number
  milesBalance: number
  timeline: { date: string; event: string; type: "neg" | "pos" | "neu" }[]
  sentimentScore: number
  openTickets: number
}

export interface Offer {
  id: string
  title: string
  desc: string
  fitScore: number
  category: "Miles" | "Upgrade" | "Experience" | "Discount"
  value: number
  icon: string
  status: "active" | "draft" | "archived"
  createdAt: string
  usageCount: number
  successRate: number
}

export interface Persona {
  id: string
  persona: string
  description: string
  traits: string[]
  preferredOffers: string[]
  acceptanceBaseline: number
  icon: string
  status: "active" | "draft"
}

export interface SimulationResult {
  persona: string
  personaId: string
  description: string
  acceptanceProb: number
  rationale: string
  expectedUplift: number
  offerId: string
  offerTitle: string
}

export interface SimulationAgent {
  id: string
  name: string
  type: "emotional" | "rational" | "financial" | "convenience" | "experience"
  description: string
  icon: string
  priority: string[]
  weight: number
}

export interface GeneratedPersona {
  id: string
  name: string
  behavioralTraits: {
    valueSensitivity: number
    frustrationTolerance: number
    loyaltyOrientation: number
    conveniencePreference: number
    serviceRecoveryExpectation: number
    priceElasticity: number
  }
  derivedFrom: string[]
  summary: string
}

export interface SimulationConfig {
  iterations: number
  variabilityWeight: number
  selectedAgents: string[]
  persona: GeneratedPersona | null
}

export interface AgentDebateResult {
  agentId: string
  agentName: string
  decision: "accept" | "reject" | "neutral"
  probability: number
  reasoning: string
  finalStance: string
}

export interface OfferSimulationResult {
  offerId: string
  offerTitle: string
  acceptanceLikelihood: number
  confidence: number
  variance: number
  agentResults: AgentDebateResult[]
  topInfluencingArguments: string[]
  recommendation: "highly_recommended" | "recommended" | "neutral" | "not_recommended"
}

export interface Campaign {
  id: string
  name: string
  status: "active" | "completed"
  targetSegment: string
  offersUsed: string[]
  customersReached: number
  conversionRate: number
  revenueSaved: number
}

export interface InterventionRecord {
  id: string
  passengerId: string
  passengerName: string
  offerId: string
  offerTitle: string
  sentAt: string
  channel: "Email" | "WhatsApp" | "App"
  status: "sent" | "opened" | "accepted" | "rejected" | "expired"
  acceptedAt?: string
  retentionOutcome?: "retained" | "churned" | "pending"
  revenueImpact?: number
  feedbackScore?: number
  notes?: string
}

export interface FeedbackMetrics {
  totalInterventions: number
  acceptanceRate: number
  retentionRate: number
  avgRevenuePerIntervention: number
  topPerformingOffers: { offerId: string; title: string; successRate: number }[]
  offersBySegment: { segment: string; bestOffer: string; successRate: number }[]
  weeklyTrend: { week: string; sent: number; accepted: number; retained: number }[]
}

export interface GeneratedMessage {
  subject: string
  greeting: string
  body: string
  offerDetails: string
  couponCode: string
  callToAction: string
  footer: string
  channel: "Email" | "WhatsApp" | "App"
}

export const passengers: Passenger[] = [
  {
    id: "PAX-001",
    name: "Elena Rodriguez",
    email: "elena.r@email.com",
    riskScore: 87,
    churnDriver: "Frequent Delays",
    ltv: 45000,
    tier: "Platinum",
    commChannel: "WhatsApp",
    lastFlight: "2024-11-15",
    totalFlights: 156,
    milesBalance: 234500,
    sentimentScore: 32,
    openTickets: 2,
    timeline: [
      { date: "2024-11-15", event: "Flight delayed 4 hours - LHR to JFK", type: "neg" },
      { date: "2024-11-10", event: "Baggage lost - Filed complaint", type: "neg" },
      { date: "2024-10-28", event: "Upgraded to Business Class", type: "pos" },
      { date: "2024-10-15", event: "Flight cancelled - Rebooked next day", type: "neg" },
      { date: "2024-09-20", event: "Completed survey - Low satisfaction", type: "neg" },
      { date: "2024-08-05", event: "Redeemed miles for lounge access", type: "pos" },
    ],
  },
  {
    id: "PAX-002",
    name: "Marcus Chen",
    email: "m.chen@techcorp.com",
    riskScore: 72,
    churnDriver: "Loyalty Neglect",
    ltv: 38000,
    tier: "Gold",
    commChannel: "Email",
    lastFlight: "2024-11-20",
    totalFlights: 89,
    milesBalance: 156000,
    sentimentScore: 45,
    openTickets: 1,
    timeline: [
      { date: "2024-11-20", event: "Regular flight - No issues", type: "neu" },
      { date: "2024-11-01", event: "Status downgrade warning sent", type: "neg" },
      { date: "2024-10-15", event: "Competitor offer received", type: "neg" },
      { date: "2024-09-30", event: "Miles expiration notice", type: "neg" },
      { date: "2024-08-12", event: "Positive feedback on crew", type: "pos" },
    ],
  },
  {
    id: "PAX-003",
    name: "Sarah Williams",
    email: "sarah.w@consulting.io",
    riskScore: 65,
    churnDriver: "Price Sensitivity",
    ltv: 28000,
    tier: "Silver",
    commChannel: "App",
    lastFlight: "2024-11-18",
    totalFlights: 45,
    milesBalance: 67000,
    sentimentScore: 58,
    openTickets: 0,
    timeline: [
      { date: "2024-11-18", event: "Booked competitor for next trip", type: "neg" },
      { date: "2024-11-05", event: "Searched competitor prices 3x", type: "neg" },
      { date: "2024-10-22", event: "Declined upgrade offer", type: "neu" },
      { date: "2024-10-01", event: "Completed flight without issues", type: "pos" },
    ],
  },
  {
    id: "PAX-004",
    name: "James Okonkwo",
    email: "j.okonkwo@finance.com",
    riskScore: 91,
    churnDriver: "Service Failure",
    ltv: 62000,
    tier: "Platinum",
    commChannel: "WhatsApp",
    lastFlight: "2024-11-12",
    totalFlights: 203,
    milesBalance: 445000,
    sentimentScore: 18,
    openTickets: 4,
    timeline: [
      { date: "2024-11-12", event: "VIP lounge access denied - System error", type: "neg" },
      { date: "2024-11-08", event: "Seat preference ignored - 3rd time", type: "neg" },
      { date: "2024-11-01", event: "Complaint escalated to management", type: "neg" },
      { date: "2024-10-25", event: "Meal preference not available", type: "neg" },
      { date: "2024-10-10", event: "Positive experience with ground staff", type: "pos" },
    ],
  },
  {
    id: "PAX-005",
    name: "Anna Kowalski",
    email: "anna.k@media.eu",
    riskScore: 54,
    churnDriver: "Inactivity",
    ltv: 19000,
    tier: "Silver",
    commChannel: "Email",
    lastFlight: "2024-08-22",
    totalFlights: 32,
    milesBalance: 34000,
    sentimentScore: 62,
    openTickets: 0,
    timeline: [
      { date: "2024-08-22", event: "Last flight - 3 months ago", type: "neu" },
      { date: "2024-08-15", event: "Ignored promotional email", type: "neg" },
      { date: "2024-07-01", event: "App uninstalled", type: "neg" },
      { date: "2024-06-15", event: "Completed satisfaction survey - Neutral", type: "neu" },
    ],
  },
  {
    id: "PAX-006",
    name: "David Park",
    email: "d.park@startup.co",
    riskScore: 78,
    churnDriver: "Route Changes",
    ltv: 31000,
    tier: "Gold",
    commChannel: "App",
    lastFlight: "2024-11-19",
    totalFlights: 67,
    milesBalance: 98000,
    sentimentScore: 41,
    openTickets: 1,
    timeline: [
      { date: "2024-11-19", event: "Preferred route discontinued", type: "neg" },
      { date: "2024-11-10", event: "Had to connect vs direct flight", type: "neg" },
      { date: "2024-11-01", event: "Searched alternative airlines", type: "neg" },
      { date: "2024-10-20", event: "Used miles for seat upgrade", type: "pos" },
    ],
  },
]

export const offers: Offer[] = [
  {
    id: "OFF-001",
    title: "Priority Lounge Pass",
    desc: "Complimentary access to all premium lounges for 6 months",
    fitScore: 92,
    category: "Experience",
    value: 1200,
    icon: "Crown",
    status: "active",
    createdAt: "2024-09-15",
    usageCount: 234,
    successRate: 78,
  },
  {
    id: "OFF-002",
    title: "Double Miles Boost",
    desc: "Earn 2x miles on all flights for the next 3 months",
    fitScore: 88,
    category: "Miles",
    value: 800,
    icon: "Plane",
    status: "active",
    createdAt: "2024-08-20",
    usageCount: 567,
    successRate: 82,
  },
  {
    id: "OFF-003",
    title: "Complimentary Upgrade",
    desc: "Free upgrade to Business Class on next 2 flights",
    fitScore: 85,
    category: "Upgrade",
    value: 2500,
    icon: "ArrowUpCircle",
    status: "active",
    createdAt: "2024-10-01",
    usageCount: 189,
    successRate: 91,
  },
  {
    id: "OFF-004",
    title: "Loyalty Bonus Miles",
    desc: "25,000 bonus miles credited immediately",
    fitScore: 78,
    category: "Miles",
    value: 500,
    icon: "Gift",
    status: "active",
    createdAt: "2024-07-10",
    usageCount: 892,
    successRate: 71,
  },
  {
    id: "OFF-005",
    title: "Price Match Guarantee",
    desc: "110% price match if you find a lower fare",
    fitScore: 82,
    category: "Discount",
    value: 0,
    icon: "Shield",
    status: "active",
    createdAt: "2024-11-01",
    usageCount: 45,
    successRate: 68,
  },
  {
    id: "OFF-006",
    title: "Exclusive Route Preview",
    desc: "Early access to book new routes before public release",
    fitScore: 75,
    category: "Experience",
    value: 0,
    icon: "Sparkles",
    status: "draft",
    createdAt: "2024-11-20",
    usageCount: 0,
    successRate: 0,
  },
  {
    id: "OFF-007",
    title: "Family Miles Transfer",
    desc: "Free miles transfer to family members (up to 50,000)",
    fitScore: 70,
    category: "Miles",
    value: 200,
    icon: "Users",
    status: "active",
    createdAt: "2024-06-15",
    usageCount: 156,
    successRate: 65,
  },
  {
    id: "OFF-008",
    title: "Premium Seat Selection",
    desc: "Free premium seat selection for next 5 flights",
    fitScore: 72,
    category: "Experience",
    value: 350,
    icon: "Armchair",
    status: "active",
    createdAt: "2024-09-01",
    usageCount: 412,
    successRate: 74,
  },
]

export const personas: Persona[] = [
  {
    id: "PER-001",
    persona: "Budget Traveler",
    description: "Price-sensitive, books in advance, values discounts over perks",
    traits: ["Cost-conscious", "Early booker", "Economy class", "Flexible dates"],
    preferredOffers: ["Price Match", "Discount", "Bonus Miles"],
    acceptanceBaseline: 65,
    icon: "DollarSign",
    status: "active",
  },
  {
    id: "PER-002",
    persona: "Business Executive",
    description: "Time-conscious, values convenience and status, expense account",
    traits: ["Time-sensitive", "Premium seeker", "Loyalty focused", "High frequency"],
    preferredOffers: ["Upgrade", "Lounge Access", "Priority Boarding"],
    acceptanceBaseline: 72,
    icon: "Briefcase",
    status: "active",
  },
  {
    id: "PER-003",
    persona: "Frequent Flyer",
    description: "Loyalty-focused, accumulates miles, values tier benefits",
    traits: ["Miles collector", "Status maintainer", "Brand loyal", "Benefit maximizer"],
    preferredOffers: ["Double Miles", "Bonus Miles", "Status Extension"],
    acceptanceBaseline: 78,
    icon: "Plane",
    status: "active",
  },
  {
    id: "PER-004",
    persona: "Leisure Traveler",
    description: "Occasional traveler, seeks experiences, flexible on timing",
    traits: ["Experience-driven", "Vacation focused", "Family oriented", "Seasonal"],
    preferredOffers: ["Experience", "Family Benefits", "Vacation Packages"],
    acceptanceBaseline: 58,
    icon: "Palmtree",
    status: "active",
  },
  {
    id: "PER-005",
    persona: "Corporate Road Warrior",
    description: "Ultra-frequent business traveler, efficiency-obsessed",
    traits: ["100+ flights/year", "Expedited everything", "Workspace needs", "Predictable routes"],
    preferredOffers: ["Fast Track", "Guaranteed Upgrades", "Workspace Access"],
    acceptanceBaseline: 81,
    icon: "Rocket",
    status: "active",
  },
  {
    id: "PER-006",
    persona: "Luxury Seeker",
    description: "Premium-only traveler, expects white-glove service",
    traits: ["First class only", "Concierge services", "Exclusive access", "High LTV"],
    preferredOffers: ["VIP Services", "Luxury Experiences", "Personal Concierge"],
    acceptanceBaseline: 69,
    icon: "Crown",
    status: "draft",
  },
]

export const aiOfferSuggestions = [
  {
    title: "Delay Compensation Plus",
    desc: "Automatic 5,000 miles credit for any delay over 2 hours",
    category: "Miles",
    reasoning: "Based on high churn correlation with flight delays, proactive compensation improves retention by 34%",
  },
  {
    title: "Personalized Route Alerts",
    desc: "AI-powered notifications for preferred routes and price drops",
    category: "Experience",
    reasoning: "Route changes are a top-5 churn driver. Personalized alerts show 28% higher engagement",
  },
  {
    title: "Status Challenge Fast Track",
    desc: "Accelerated path to next tier with 50% fewer qualifying flights",
    category: "Upgrade",
    reasoning: "Mid-tier customers show highest churn risk. Status challenges reduce churn by 41%",
  },
]

export const aiPersonaSuggestions = [
  {
    persona: "Delay-Sensitive Traveler",
    description: "Travelers who have experienced multiple delays and show high frustration",
    reasoning: "23% of high-risk customers share this pattern. Targeted offers show 45% better acceptance",
  },
  {
    persona: "Lapsed Premium Member",
    description: "Former Gold/Platinum members who haven't flown in 60+ days",
    reasoning: "This segment represents $2.3M in at-risk revenue. Re-engagement campaigns show 52% success",
  },
  {
    persona: "Competitor Considerer",
    description: "Customers who have searched competitor fares in last 30 days",
    reasoning: "Early intervention with this segment prevents 38% of potential defections",
  },
]

export const campaigns: Campaign[] = [
  {
    id: "CMP-001",
    name: "Q4 High-Risk Recovery",
    status: "active",
    targetSegment: "High Risk Platinum",
    offersUsed: ["Lounge Pass", "Double Miles"],
    customersReached: 1234,
    conversionRate: 34.5,
    revenueSaved: 456000,
  },
  {
    id: "CMP-002",
    name: "Delay Compensation Drive",
    status: "active",
    targetSegment: "Delay Affected",
    offersUsed: ["Upgrade", "Bonus Miles"],
    customersReached: 567,
    conversionRate: 42.1,
    revenueSaved: 234000,
  },
  {
    id: "CMP-003",
    name: "Inactive Re-engagement",
    status: "completed",
    targetSegment: "90+ Days Inactive",
    offersUsed: ["Price Match", "Route Preview"],
    customersReached: 2341,
    conversionRate: 18.7,
    revenueSaved: 189000,
  },
]

export const simulationAgents: SimulationAgent[] = [
  {
    id: "agent-emotional",
    name: "Emotional Agent",
    type: "emotional",
    description: "Prioritizes frustration, loyalty issues, recent delays. More reactive to negative experiences.",
    icon: "Heart",
    priority: ["Recent negative events", "Frustration level", "Emotional sentiment", "Service failures"],
    weight: 0.2,
  },
  {
    id: "agent-rational",
    name: "Rational Agent",
    type: "rational",
    description: "Optimizes value, LTV impact, and long-term benefits. Logical decision making.",
    icon: "Brain",
    priority: ["LTV calculations", "Long-term value", "Cost-benefit analysis", "Strategic benefits"],
    weight: 0.25,
  },
  {
    id: "agent-financial",
    name: "Financial Agent",
    type: "financial",
    description: "Focuses on cost, budget, and price sensitivity. Evaluates monetary value.",
    icon: "DollarSign",
    priority: ["Price sensitivity", "Budget constraints", "Monetary value", "Cost savings"],
    weight: 0.2,
  },
  {
    id: "agent-convenience",
    name: "Convenience Agent",
    type: "convenience",
    description: "Values comfort, ease, and seamless experiences. Prioritizes friction reduction.",
    icon: "Zap",
    priority: ["Ease of use", "Time savings", "Friction reduction", "Seamless experience"],
    weight: 0.15,
  },
  {
    id: "agent-experience",
    name: "Experience Agent",
    type: "experience",
    description: "Focuses on brand loyalty, past interactions, and overall experience quality.",
    icon: "Star",
    priority: ["Brand loyalty", "Past interactions", "Experience quality", "Relationship history"],
    weight: 0.2,
  },
]

export const analyticsData = {
  riskTrend: [
    { month: "Jun", highRisk: 450, mediumRisk: 890, lowRisk: 2100 },
    { month: "Jul", highRisk: 520, mediumRisk: 920, lowRisk: 2050 },
    { month: "Aug", highRisk: 480, mediumRisk: 850, lowRisk: 2200 },
    { month: "Sep", highRisk: 410, mediumRisk: 780, lowRisk: 2350 },
    { month: "Oct", highRisk: 350, mediumRisk: 720, lowRisk: 2480 },
    { month: "Nov", highRisk: 280, mediumRisk: 650, lowRisk: 2620 },
  ],
  offerPerformance: [
    { offer: "Lounge Pass", acceptance: 67, retention: 82 },
    { offer: "Double Miles", acceptance: 72, retention: 76 },
    { offer: "Upgrade", acceptance: 58, retention: 89 },
    { offer: "Bonus Miles", acceptance: 81, retention: 71 },
    { offer: "Price Match", acceptance: 45, retention: 68 },
  ],
  churnDrivers: [
    { driver: "Delays", count: 342, percentage: 28 },
    { driver: "Service Issues", count: 256, percentage: 21 },
    { driver: "Price Sensitivity", count: 198, percentage: 16 },
    { driver: "Loyalty Neglect", count: 178, percentage: 15 },
    { driver: "Route Changes", count: 134, percentage: 11 },
    { driver: "Inactivity", count: 112, percentage: 9 },
  ],
}

export const interventionHistory: InterventionRecord[] = [
  {
    id: "INT-001",
    passengerId: "PAX-007",
    passengerName: "Michael Thompson",
    offerId: "OFF-001",
    offerTitle: "Priority Lounge Pass",
    sentAt: "2024-11-28T10:30:00Z",
    channel: "Email",
    status: "accepted",
    acceptedAt: "2024-11-28T14:15:00Z",
    retentionOutcome: "retained",
    revenueImpact: 12500,
    feedbackScore: 4.5,
  },
  {
    id: "INT-002",
    passengerId: "PAX-008",
    passengerName: "Lisa Chang",
    offerId: "OFF-002",
    offerTitle: "Double Miles Boost",
    sentAt: "2024-11-27T09:00:00Z",
    channel: "WhatsApp",
    status: "accepted",
    acceptedAt: "2024-11-27T11:30:00Z",
    retentionOutcome: "retained",
    revenueImpact: 8900,
    feedbackScore: 5,
  },
  {
    id: "INT-003",
    passengerId: "PAX-009",
    passengerName: "Robert Miller",
    offerId: "OFF-003",
    offerTitle: "Complimentary Upgrade",
    sentAt: "2024-11-26T15:45:00Z",
    channel: "App",
    status: "rejected",
    retentionOutcome: "churned",
    revenueImpact: -31000,
    notes: "Customer cited price as main concern - upgrade offer mismatch",
  },
  {
    id: "INT-004",
    passengerId: "PAX-010",
    passengerName: "Jennifer Adams",
    offerId: "OFF-005",
    offerTitle: "Price Match Guarantee",
    sentAt: "2024-11-25T08:20:00Z",
    channel: "Email",
    status: "accepted",
    acceptedAt: "2024-11-25T16:00:00Z",
    retentionOutcome: "retained",
    revenueImpact: 15200,
    feedbackScore: 4,
  },
  {
    id: "INT-005",
    passengerId: "PAX-011",
    passengerName: "Carlos Mendez",
    offerId: "OFF-004",
    offerTitle: "Loyalty Bonus Miles",
    sentAt: "2024-11-24T12:00:00Z",
    channel: "WhatsApp",
    status: "opened",
    retentionOutcome: "pending",
  },
  {
    id: "INT-006",
    passengerId: "PAX-012",
    passengerName: "Emma Wilson",
    offerId: "OFF-001",
    offerTitle: "Priority Lounge Pass",
    sentAt: "2024-11-23T14:30:00Z",
    channel: "Email",
    status: "accepted",
    acceptedAt: "2024-11-24T09:15:00Z",
    retentionOutcome: "retained",
    revenueImpact: 22000,
    feedbackScore: 5,
  },
  {
    id: "INT-007",
    passengerId: "PAX-013",
    passengerName: "David Kim",
    offerId: "OFF-002",
    offerTitle: "Double Miles Boost",
    sentAt: "2024-11-22T11:00:00Z",
    channel: "App",
    status: "expired",
    retentionOutcome: "churned",
    revenueImpact: -28000,
    notes: "No engagement within 72 hours",
  },
  {
    id: "INT-008",
    passengerId: "PAX-014",
    passengerName: "Sophie Brown",
    offerId: "OFF-003",
    offerTitle: "Complimentary Upgrade",
    sentAt: "2024-11-21T16:45:00Z",
    channel: "WhatsApp",
    status: "accepted",
    acceptedAt: "2024-11-21T18:30:00Z",
    retentionOutcome: "retained",
    revenueImpact: 45000,
    feedbackScore: 5,
  },
]

export const feedbackMetrics: FeedbackMetrics = {
  totalInterventions: 156,
  acceptanceRate: 67.3,
  retentionRate: 82.1,
  avgRevenuePerIntervention: 18500,
  topPerformingOffers: [
    { offerId: "OFF-003", title: "Complimentary Upgrade", successRate: 91 },
    { offerId: "OFF-002", title: "Double Miles Boost", successRate: 82 },
    { offerId: "OFF-001", title: "Priority Lounge Pass", successRate: 78 },
  ],
  offersBySegment: [
    { segment: "High Risk Platinum", bestOffer: "Complimentary Upgrade", successRate: 89 },
    { segment: "Delay Affected", bestOffer: "Lounge Pass", successRate: 84 },
    { segment: "Price Sensitive", bestOffer: "Price Match", successRate: 76 },
    { segment: "Loyalty Neglect", bestOffer: "Double Miles", successRate: 81 },
  ],
  weeklyTrend: [
    { week: "Week 1", sent: 32, accepted: 21, retained: 18 },
    { week: "Week 2", sent: 38, accepted: 26, retained: 22 },
    { week: "Week 3", sent: 41, accepted: 29, retained: 25 },
    { week: "Week 4", sent: 45, accepted: 32, retained: 28 },
  ],
}
