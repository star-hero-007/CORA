(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_views_3790e801._.js",
  "static/chunks/components_55dd6d6b._.js",
  "static/chunks/_73a370aa._.js",
  "static/chunks/node_modules_framer-motion_dist_es_7048033e._.js",
  "static/chunks/node_modules_motion-dom_dist_es_a3821813._.js",
  "static/chunks/node_modules_recharts_es6_util_cf463a6e._.js",
  "static/chunks/node_modules_recharts_es6_component_a9bf31bf._.js",
  "static/chunks/node_modules_recharts_es6_state_f9f0d106._.js",
  "static/chunks/node_modules_recharts_es6_polar_46c13783._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_56496506._.js",
  "static/chunks/node_modules_recharts_es6_14e25754._.js",
  "static/chunks/node_modules_@radix-ui_b11e1b79._.js",
  "static/chunks/node_modules_@reduxjs_toolkit_b00a18bb._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_2e7f807f._.js"
],
    source: "dynamic"
});
