(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/mock-data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "aiOfferSuggestions",
    ()=>aiOfferSuggestions,
    "aiPersonaSuggestions",
    ()=>aiPersonaSuggestions,
    "analyticsData",
    ()=>analyticsData,
    "campaigns",
    ()=>campaigns,
    "feedbackMetrics",
    ()=>feedbackMetrics,
    "interventionHistory",
    ()=>interventionHistory,
    "offers",
    ()=>offers,
    "passengers",
    ()=>passengers,
    "personas",
    ()=>personas,
    "simulationAgents",
    ()=>simulationAgents
]);
const passengers = [
    {
        id: "PAX-001",
        name: "Elena Rodriguez",
        email: "elena.r@email.com",
        riskScore: 87,
        churnDriver: "Frequent Delays",
        ltv: 45000,
        tier: "Platinum",
        commChannel: "WhatsApp",
        lastFlight: "2024-11-15",
        totalFlights: 156,
        milesBalance: 234500,
        sentimentScore: 32,
        openTickets: 2,
        timeline: [
            {
                date: "2024-11-15",
                event: "Flight delayed 4 hours - LHR to JFK",
                type: "neg"
            },
            {
                date: "2024-11-10",
                event: "Baggage lost - Filed complaint",
                type: "neg"
            },
            {
                date: "2024-10-28",
                event: "Upgraded to Business Class",
                type: "pos"
            },
            {
                date: "2024-10-15",
                event: "Flight cancelled - Rebooked next day",
                type: "neg"
            },
            {
                date: "2024-09-20",
                event: "Completed survey - Low satisfaction",
                type: "neg"
            },
            {
                date: "2024-08-05",
                event: "Redeemed miles for lounge access",
                type: "pos"
            }
        ]
    },
    {
        id: "PAX-002",
        name: "Marcus Chen",
        email: "m.chen@techcorp.com",
        riskScore: 72,
        churnDriver: "Loyalty Neglect",
        ltv: 38000,
        tier: "Gold",
        commChannel: "Email",
        lastFlight: "2024-11-20",
        totalFlights: 89,
        milesBalance: 156000,
        sentimentScore: 45,
        openTickets: 1,
        timeline: [
            {
                date: "2024-11-20",
                event: "Regular flight - No issues",
                type: "neu"
            },
            {
                date: "2024-11-01",
                event: "Status downgrade warning sent",
                type: "neg"
            },
            {
                date: "2024-10-15",
                event: "Competitor offer received",
                type: "neg"
            },
            {
                date: "2024-09-30",
                event: "Miles expiration notice",
                type: "neg"
            },
            {
                date: "2024-08-12",
                event: "Positive feedback on crew",
                type: "pos"
            }
        ]
    },
    {
        id: "PAX-003",
        name: "Sarah Williams",
        email: "sarah.w@consulting.io",
        riskScore: 65,
        churnDriver: "Price Sensitivity",
        ltv: 28000,
        tier: "Silver",
        commChannel: "App",
        lastFlight: "2024-11-18",
        totalFlights: 45,
        milesBalance: 67000,
        sentimentScore: 58,
        openTickets: 0,
        timeline: [
            {
                date: "2024-11-18",
                event: "Booked competitor for next trip",
                type: "neg"
            },
            {
                date: "2024-11-05",
                event: "Searched competitor prices 3x",
                type: "neg"
            },
            {
                date: "2024-10-22",
                event: "Declined upgrade offer",
                type: "neu"
            },
            {
                date: "2024-10-01",
                event: "Completed flight without issues",
                type: "pos"
            }
        ]
    },
    {
        id: "PAX-004",
        name: "James Okonkwo",
        email: "j.okonkwo@finance.com",
        riskScore: 91,
        churnDriver: "Service Failure",
        ltv: 62000,
        tier: "Platinum",
        commChannel: "WhatsApp",
        lastFlight: "2024-11-12",
        totalFlights: 203,
        milesBalance: 445000,
        sentimentScore: 18,
        openTickets: 4,
        timeline: [
            {
                date: "2024-11-12",
                event: "VIP lounge access denied - System error",
                type: "neg"
            },
            {
                date: "2024-11-08",
                event: "Seat preference ignored - 3rd time",
                type: "neg"
            },
            {
                date: "2024-11-01",
                event: "Complaint escalated to management",
                type: "neg"
            },
            {
                date: "2024-10-25",
                event: "Meal preference not available",
                type: "neg"
            },
            {
                date: "2024-10-10",
                event: "Positive experience with ground staff",
                type: "pos"
            }
        ]
    },
    {
        id: "PAX-005",
        name: "Anna Kowalski",
        email: "anna.k@media.eu",
        riskScore: 54,
        churnDriver: "Inactivity",
        ltv: 19000,
        tier: "Silver",
        commChannel: "Email",
        lastFlight: "2024-08-22",
        totalFlights: 32,
        milesBalance: 34000,
        sentimentScore: 62,
        openTickets: 0,
        timeline: [
            {
                date: "2024-08-22",
                event: "Last flight - 3 months ago",
                type: "neu"
            },
            {
                date: "2024-08-15",
                event: "Ignored promotional email",
                type: "neg"
            },
            {
                date: "2024-07-01",
                event: "App uninstalled",
                type: "neg"
            },
            {
                date: "2024-06-15",
                event: "Completed satisfaction survey - Neutral",
                type: "neu"
            }
        ]
    },
    {
        id: "PAX-006",
        name: "David Park",
        email: "d.park@startup.co",
        riskScore: 78,
        churnDriver: "Route Changes",
        ltv: 31000,
        tier: "Gold",
        commChannel: "App",
        lastFlight: "2024-11-19",
        totalFlights: 67,
        milesBalance: 98000,
        sentimentScore: 41,
        openTickets: 1,
        timeline: [
            {
                date: "2024-11-19",
                event: "Preferred route discontinued",
                type: "neg"
            },
            {
                date: "2024-11-10",
                event: "Had to connect vs direct flight",
                type: "neg"
            },
            {
                date: "2024-11-01",
                event: "Searched alternative airlines",
                type: "neg"
            },
            {
                date: "2024-10-20",
                event: "Used miles for seat upgrade",
                type: "pos"
            }
        ]
    }
];
const offers = [
    {
        id: "OFF-001",
        title: "Priority Lounge Pass",
        desc: "Complimentary access to all premium lounges for 6 months",
        fitScore: 92,
        category: "Experience",
        value: 1200,
        icon: "Crown",
        status: "active",
        createdAt: "2024-09-15",
        usageCount: 234,
        successRate: 78
    },
    {
        id: "OFF-002",
        title: "Double Miles Boost",
        desc: "Earn 2x miles on all flights for the next 3 months",
        fitScore: 88,
        category: "Miles",
        value: 800,
        icon: "Plane",
        status: "active",
        createdAt: "2024-08-20",
        usageCount: 567,
        successRate: 82
    },
    {
        id: "OFF-003",
        title: "Complimentary Upgrade",
        desc: "Free upgrade to Business Class on next 2 flights",
        fitScore: 85,
        category: "Upgrade",
        value: 2500,
        icon: "ArrowUpCircle",
        status: "active",
        createdAt: "2024-10-01",
        usageCount: 189,
        successRate: 91
    },
    {
        id: "OFF-004",
        title: "Loyalty Bonus Miles",
        desc: "25,000 bonus miles credited immediately",
        fitScore: 78,
        category: "Miles",
        value: 500,
        icon: "Gift",
        status: "active",
        createdAt: "2024-07-10",
        usageCount: 892,
        successRate: 71
    },
    {
        id: "OFF-005",
        title: "Price Match Guarantee",
        desc: "110% price match if you find a lower fare",
        fitScore: 82,
        category: "Discount",
        value: 0,
        icon: "Shield",
        status: "active",
        createdAt: "2024-11-01",
        usageCount: 45,
        successRate: 68
    },
    {
        id: "OFF-006",
        title: "Exclusive Route Preview",
        desc: "Early access to book new routes before public release",
        fitScore: 75,
        category: "Experience",
        value: 0,
        icon: "Sparkles",
        status: "draft",
        createdAt: "2024-11-20",
        usageCount: 0,
        successRate: 0
    },
    {
        id: "OFF-007",
        title: "Family Miles Transfer",
        desc: "Free miles transfer to family members (up to 50,000)",
        fitScore: 70,
        category: "Miles",
        value: 200,
        icon: "Users",
        status: "active",
        createdAt: "2024-06-15",
        usageCount: 156,
        successRate: 65
    },
    {
        id: "OFF-008",
        title: "Premium Seat Selection",
        desc: "Free premium seat selection for next 5 flights",
        fitScore: 72,
        category: "Experience",
        value: 350,
        icon: "Armchair",
        status: "active",
        createdAt: "2024-09-01",
        usageCount: 412,
        successRate: 74
    }
];
const personas = [
    {
        id: "PER-001",
        persona: "Budget Traveler",
        description: "Price-sensitive, books in advance, values discounts over perks",
        traits: [
            "Cost-conscious",
            "Early booker",
            "Economy class",
            "Flexible dates"
        ],
        preferredOffers: [
            "Price Match",
            "Discount",
            "Bonus Miles"
        ],
        acceptanceBaseline: 65,
        icon: "DollarSign",
        status: "active"
    },
    {
        id: "PER-002",
        persona: "Business Executive",
        description: "Time-conscious, values convenience and status, expense account",
        traits: [
            "Time-sensitive",
            "Premium seeker",
            "Loyalty focused",
            "High frequency"
        ],
        preferredOffers: [
            "Upgrade",
            "Lounge Access",
            "Priority Boarding"
        ],
        acceptanceBaseline: 72,
        icon: "Briefcase",
        status: "active"
    },
    {
        id: "PER-003",
        persona: "Frequent Flyer",
        description: "Loyalty-focused, accumulates miles, values tier benefits",
        traits: [
            "Miles collector",
            "Status maintainer",
            "Brand loyal",
            "Benefit maximizer"
        ],
        preferredOffers: [
            "Double Miles",
            "Bonus Miles",
            "Status Extension"
        ],
        acceptanceBaseline: 78,
        icon: "Plane",
        status: "active"
    },
    {
        id: "PER-004",
        persona: "Leisure Traveler",
        description: "Occasional traveler, seeks experiences, flexible on timing",
        traits: [
            "Experience-driven",
            "Vacation focused",
            "Family oriented",
            "Seasonal"
        ],
        preferredOffers: [
            "Experience",
            "Family Benefits",
            "Vacation Packages"
        ],
        acceptanceBaseline: 58,
        icon: "Palmtree",
        status: "active"
    },
    {
        id: "PER-005",
        persona: "Corporate Road Warrior",
        description: "Ultra-frequent business traveler, efficiency-obsessed",
        traits: [
            "100+ flights/year",
            "Expedited everything",
            "Workspace needs",
            "Predictable routes"
        ],
        preferredOffers: [
            "Fast Track",
            "Guaranteed Upgrades",
            "Workspace Access"
        ],
        acceptanceBaseline: 81,
        icon: "Rocket",
        status: "active"
    },
    {
        id: "PER-006",
        persona: "Luxury Seeker",
        description: "Premium-only traveler, expects white-glove service",
        traits: [
            "First class only",
            "Concierge services",
            "Exclusive access",
            "High LTV"
        ],
        preferredOffers: [
            "VIP Services",
            "Luxury Experiences",
            "Personal Concierge"
        ],
        acceptanceBaseline: 69,
        icon: "Crown",
        status: "draft"
    }
];
const aiOfferSuggestions = [
    {
        title: "Delay Compensation Plus",
        desc: "Automatic 5,000 miles credit for any delay over 2 hours",
        category: "Miles",
        reasoning: "Based on high churn correlation with flight delays, proactive compensation improves retention by 34%"
    },
    {
        title: "Personalized Route Alerts",
        desc: "AI-powered notifications for preferred routes and price drops",
        category: "Experience",
        reasoning: "Route changes are a top-5 churn driver. Personalized alerts show 28% higher engagement"
    },
    {
        title: "Status Challenge Fast Track",
        desc: "Accelerated path to next tier with 50% fewer qualifying flights",
        category: "Upgrade",
        reasoning: "Mid-tier customers show highest churn risk. Status challenges reduce churn by 41%"
    }
];
const aiPersonaSuggestions = [
    {
        persona: "Delay-Sensitive Traveler",
        description: "Travelers who have experienced multiple delays and show high frustration",
        reasoning: "23% of high-risk customers share this pattern. Targeted offers show 45% better acceptance"
    },
    {
        persona: "Lapsed Premium Member",
        description: "Former Gold/Platinum members who haven't flown in 60+ days",
        reasoning: "This segment represents $2.3M in at-risk revenue. Re-engagement campaigns show 52% success"
    },
    {
        persona: "Competitor Considerer",
        description: "Customers who have searched competitor fares in last 30 days",
        reasoning: "Early intervention with this segment prevents 38% of potential defections"
    }
];
const campaigns = [
    {
        id: "CMP-001",
        name: "Q4 High-Risk Recovery",
        status: "active",
        targetSegment: "High Risk Platinum",
        offersUsed: [
            "Lounge Pass",
            "Double Miles"
        ],
        customersReached: 1234,
        conversionRate: 34.5,
        revenueSaved: 456000
    },
    {
        id: "CMP-002",
        name: "Delay Compensation Drive",
        status: "active",
        targetSegment: "Delay Affected",
        offersUsed: [
            "Upgrade",
            "Bonus Miles"
        ],
        customersReached: 567,
        conversionRate: 42.1,
        revenueSaved: 234000
    },
    {
        id: "CMP-003",
        name: "Inactive Re-engagement",
        status: "completed",
        targetSegment: "90+ Days Inactive",
        offersUsed: [
            "Price Match",
            "Route Preview"
        ],
        customersReached: 2341,
        conversionRate: 18.7,
        revenueSaved: 189000
    }
];
const simulationAgents = [
    {
        id: "agent-emotional",
        name: "Emotional Agent",
        type: "emotional",
        description: "Prioritizes frustration, loyalty issues, recent delays. More reactive to negative experiences.",
        icon: "Heart",
        priority: [
            "Recent negative events",
            "Frustration level",
            "Emotional sentiment",
            "Service failures"
        ],
        weight: 0.2
    },
    {
        id: "agent-rational",
        name: "Rational Agent",
        type: "rational",
        description: "Optimizes value, LTV impact, and long-term benefits. Logical decision making.",
        icon: "Brain",
        priority: [
            "LTV calculations",
            "Long-term value",
            "Cost-benefit analysis",
            "Strategic benefits"
        ],
        weight: 0.25
    },
    {
        id: "agent-financial",
        name: "Financial Agent",
        type: "financial",
        description: "Focuses on cost, budget, and price sensitivity. Evaluates monetary value.",
        icon: "DollarSign",
        priority: [
            "Price sensitivity",
            "Budget constraints",
            "Monetary value",
            "Cost savings"
        ],
        weight: 0.2
    },
    {
        id: "agent-convenience",
        name: "Convenience Agent",
        type: "convenience",
        description: "Values comfort, ease, and seamless experiences. Prioritizes friction reduction.",
        icon: "Zap",
        priority: [
            "Ease of use",
            "Time savings",
            "Friction reduction",
            "Seamless experience"
        ],
        weight: 0.15
    },
    {
        id: "agent-experience",
        name: "Experience Agent",
        type: "experience",
        description: "Focuses on brand loyalty, past interactions, and overall experience quality.",
        icon: "Star",
        priority: [
            "Brand loyalty",
            "Past interactions",
            "Experience quality",
            "Relationship history"
        ],
        weight: 0.2
    }
];
const analyticsData = {
    riskTrend: [
        {
            month: "Jun",
            highRisk: 450,
            mediumRisk: 890,
            lowRisk: 2100
        },
        {
            month: "Jul",
            highRisk: 520,
            mediumRisk: 920,
            lowRisk: 2050
        },
        {
            month: "Aug",
            highRisk: 480,
            mediumRisk: 850,
            lowRisk: 2200
        },
        {
            month: "Sep",
            highRisk: 410,
            mediumRisk: 780,
            lowRisk: 2350
        },
        {
            month: "Oct",
            highRisk: 350,
            mediumRisk: 720,
            lowRisk: 2480
        },
        {
            month: "Nov",
            highRisk: 280,
            mediumRisk: 650,
            lowRisk: 2620
        }
    ],
    offerPerformance: [
        {
            offer: "Lounge Pass",
            acceptance: 67,
            retention: 82
        },
        {
            offer: "Double Miles",
            acceptance: 72,
            retention: 76
        },
        {
            offer: "Upgrade",
            acceptance: 58,
            retention: 89
        },
        {
            offer: "Bonus Miles",
            acceptance: 81,
            retention: 71
        },
        {
            offer: "Price Match",
            acceptance: 45,
            retention: 68
        }
    ],
    churnDrivers: [
        {
            driver: "Delays",
            count: 342,
            percentage: 28
        },
        {
            driver: "Service Issues",
            count: 256,
            percentage: 21
        },
        {
            driver: "Price Sensitivity",
            count: 198,
            percentage: 16
        },
        {
            driver: "Loyalty Neglect",
            count: 178,
            percentage: 15
        },
        {
            driver: "Route Changes",
            count: 134,
            percentage: 11
        },
        {
            driver: "Inactivity",
            count: 112,
            percentage: 9
        }
    ]
};
const interventionHistory = [
    {
        id: "INT-001",
        passengerId: "PAX-007",
        passengerName: "Michael Thompson",
        offerId: "OFF-001",
        offerTitle: "Priority Lounge Pass",
        sentAt: "2024-11-28T10:30:00Z",
        channel: "Email",
        status: "accepted",
        acceptedAt: "2024-11-28T14:15:00Z",
        retentionOutcome: "retained",
        revenueImpact: 12500,
        feedbackScore: 4.5
    },
    {
        id: "INT-002",
        passengerId: "PAX-008",
        passengerName: "Lisa Chang",
        offerId: "OFF-002",
        offerTitle: "Double Miles Boost",
        sentAt: "2024-11-27T09:00:00Z",
        channel: "WhatsApp",
        status: "accepted",
        acceptedAt: "2024-11-27T11:30:00Z",
        retentionOutcome: "retained",
        revenueImpact: 8900,
        feedbackScore: 5
    },
    {
        id: "INT-003",
        passengerId: "PAX-009",
        passengerName: "Robert Miller",
        offerId: "OFF-003",
        offerTitle: "Complimentary Upgrade",
        sentAt: "2024-11-26T15:45:00Z",
        channel: "App",
        status: "rejected",
        retentionOutcome: "churned",
        revenueImpact: -31000,
        notes: "Customer cited price as main concern - upgrade offer mismatch"
    },
    {
        id: "INT-004",
        passengerId: "PAX-010",
        passengerName: "Jennifer Adams",
        offerId: "OFF-005",
        offerTitle: "Price Match Guarantee",
        sentAt: "2024-11-25T08:20:00Z",
        channel: "Email",
        status: "accepted",
        acceptedAt: "2024-11-25T16:00:00Z",
        retentionOutcome: "retained",
        revenueImpact: 15200,
        feedbackScore: 4
    },
    {
        id: "INT-005",
        passengerId: "PAX-011",
        passengerName: "Carlos Mendez",
        offerId: "OFF-004",
        offerTitle: "Loyalty Bonus Miles",
        sentAt: "2024-11-24T12:00:00Z",
        channel: "WhatsApp",
        status: "opened",
        retentionOutcome: "pending"
    },
    {
        id: "INT-006",
        passengerId: "PAX-012",
        passengerName: "Emma Wilson",
        offerId: "OFF-001",
        offerTitle: "Priority Lounge Pass",
        sentAt: "2024-11-23T14:30:00Z",
        channel: "Email",
        status: "accepted",
        acceptedAt: "2024-11-24T09:15:00Z",
        retentionOutcome: "retained",
        revenueImpact: 22000,
        feedbackScore: 5
    },
    {
        id: "INT-007",
        passengerId: "PAX-013",
        passengerName: "David Kim",
        offerId: "OFF-002",
        offerTitle: "Double Miles Boost",
        sentAt: "2024-11-22T11:00:00Z",
        channel: "App",
        status: "expired",
        retentionOutcome: "churned",
        revenueImpact: -28000,
        notes: "No engagement within 72 hours"
    },
    {
        id: "INT-008",
        passengerId: "PAX-014",
        passengerName: "Sophie Brown",
        offerId: "OFF-003",
        offerTitle: "Complimentary Upgrade",
        sentAt: "2024-11-21T16:45:00Z",
        channel: "WhatsApp",
        status: "accepted",
        acceptedAt: "2024-11-21T18:30:00Z",
        retentionOutcome: "retained",
        revenueImpact: 45000,
        feedbackScore: 5
    }
];
const feedbackMetrics = {
    totalInterventions: 156,
    acceptanceRate: 67.3,
    retentionRate: 82.1,
    avgRevenuePerIntervention: 18500,
    topPerformingOffers: [
        {
            offerId: "OFF-003",
            title: "Complimentary Upgrade",
            successRate: 91
        },
        {
            offerId: "OFF-002",
            title: "Double Miles Boost",
            successRate: 82
        },
        {
            offerId: "OFF-001",
            title: "Priority Lounge Pass",
            successRate: 78
        }
    ],
    offersBySegment: [
        {
            segment: "High Risk Platinum",
            bestOffer: "Complimentary Upgrade",
            successRate: 89
        },
        {
            segment: "Delay Affected",
            bestOffer: "Lounge Pass",
            successRate: 84
        },
        {
            segment: "Price Sensitive",
            bestOffer: "Price Match",
            successRate: 76
        },
        {
            segment: "Loyalty Neglect",
            bestOffer: "Double Miles",
            successRate: 81
        }
    ],
    weeklyTrend: [
        {
            week: "Week 1",
            sent: 32,
            accepted: 21,
            retained: 18
        },
        {
            week: "Week 2",
            sent: 38,
            accepted: 26,
            retained: 22
        },
        {
            week: "Week 3",
            sent: 41,
            accepted: 29,
            retained: 25
        },
        {
            week: "Week 4",
            sent: 45,
            accepted: 32,
            retained: 28
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/use-toast.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reducer",
    ()=>reducer,
    "toast",
    ()=>toast,
    "useToast",
    ()=>useToast
]);
// Inspired by react-hot-toast library
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1000000;
const actionTypes = {
    ADD_TOAST: 'ADD_TOAST',
    UPDATE_TOAST: 'UPDATE_TOAST',
    DISMISS_TOAST: 'DISMISS_TOAST',
    REMOVE_TOAST: 'REMOVE_TOAST'
};
let count = 0;
function genId() {
    count = (count + 1) % Number.MAX_SAFE_INTEGER;
    return count.toString();
}
const toastTimeouts = new Map();
const addToRemoveQueue = (toastId)=>{
    if (toastTimeouts.has(toastId)) {
        return;
    }
    const timeout = setTimeout(()=>{
        toastTimeouts.delete(toastId);
        dispatch({
            type: 'REMOVE_TOAST',
            toastId: toastId
        });
    }, TOAST_REMOVE_DELAY);
    toastTimeouts.set(toastId, timeout);
};
const reducer = (state, action)=>{
    switch(action.type){
        case 'ADD_TOAST':
            return {
                ...state,
                toasts: [
                    action.toast,
                    ...state.toasts
                ].slice(0, TOAST_LIMIT)
            };
        case 'UPDATE_TOAST':
            return {
                ...state,
                toasts: state.toasts.map((t)=>t.id === action.toast.id ? {
                        ...t,
                        ...action.toast
                    } : t)
            };
        case 'DISMISS_TOAST':
            {
                const { toastId } = action;
                // ! Side effects ! - This could be extracted into a dismissToast() action,
                // but I'll keep it here for simplicity
                if (toastId) {
                    addToRemoveQueue(toastId);
                } else {
                    state.toasts.forEach((toast)=>{
                        addToRemoveQueue(toast.id);
                    });
                }
                return {
                    ...state,
                    toasts: state.toasts.map((t)=>t.id === toastId || toastId === undefined ? {
                            ...t,
                            open: false
                        } : t)
                };
            }
        case 'REMOVE_TOAST':
            if (action.toastId === undefined) {
                return {
                    ...state,
                    toasts: []
                };
            }
            return {
                ...state,
                toasts: state.toasts.filter((t)=>t.id !== action.toastId)
            };
    }
};
const listeners = [];
let memoryState = {
    toasts: []
};
function dispatch(action) {
    memoryState = reducer(memoryState, action);
    listeners.forEach((listener)=>{
        listener(memoryState);
    });
}
function toast({ ...props }) {
    const id = genId();
    const update = (props)=>dispatch({
            type: 'UPDATE_TOAST',
            toast: {
                ...props,
                id
            }
        });
    const dismiss = ()=>dispatch({
            type: 'DISMISS_TOAST',
            toastId: id
        });
    dispatch({
        type: 'ADD_TOAST',
        toast: {
            ...props,
            id,
            open: true,
            onOpenChange: (open)=>{
                if (!open) dismiss();
            }
        }
    });
    return {
        id: id,
        dismiss,
        update
    };
}
function useToast() {
    _s();
    const [state, setState] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](memoryState);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useToast.useEffect": ()=>{
            listeners.push(setState);
            return ({
                "useToast.useEffect": ()=>{
                    const index = listeners.indexOf(setState);
                    if (index > -1) {
                        listeners.splice(index, 1);
                    }
                }
            })["useToast.useEffect"];
        }
    }["useToast.useEffect"], [
        state
    ]);
    return {
        ...state,
        toast,
        dismiss: (toastId)=>dispatch({
                type: 'DISMISS_TOAST',
                toastId
            })
    };
}
_s(useToast, "SPWE98mLGnlsnNfIwu/IAKTSZtk=");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CoraApp
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/sidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$overview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/overview.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$risk$2d$feed$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/risk-feed.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$customer$2d$360$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/customer-360.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$offer$2d$lab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/offer-lab.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$simulation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/simulation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$analytics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/analytics.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$model$2d$ops$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/views/model-ops.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/toaster.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function CoraApp() {
    _s();
    const [activeView, setActiveView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("overview");
    const [selectedPassenger, setSelectedPassenger] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [shortlistedOffers, setShortlistedOffers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentPersona, setCurrentPersona] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const [riskFeedRefreshKey, setRiskFeedRefreshKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [theme, setTheme] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("dark");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CoraApp.useEffect": ()=>{
            const savedTheme = localStorage.getItem("cora-theme");
            const initialTheme = savedTheme || "dark";
            setTheme(initialTheme);
            document.documentElement.classList.toggle("dark", initialTheme === "dark");
        }
    }["CoraApp.useEffect"], []);
    const handleToggleTheme = ()=>{
        const newTheme = theme === "dark" ? "light" : "dark";
        setTheme(newTheme);
        localStorage.setItem("cora-theme", newTheme);
        document.documentElement.classList.toggle("dark", newTheme === "dark");
    };
    const handleNavigate = (view)=>{
        setActiveView(view);
        if (view === "offer-lab" || view === "simulation") {
            if (activeView !== "customer-360" && activeView !== "offer-lab") {
                setSelectedPassenger(null);
                setShortlistedOffers([]);
                setCurrentPersona(null);
            }
        }
    };
    const handleNavigateToHome = (view)=>{
        setActiveView(view);
        setSelectedPassenger(null);
        setShortlistedOffers([]);
        setCurrentPersona(null);
    };
    const handleSelectPassenger = (passenger)=>{
        setSelectedPassenger(passenger);
        setActiveView("customer-360");
        setShortlistedOffers([]);
        setCurrentPersona(null);
    };
    const handleShortlistOffers = (passenger)=>{
        setSelectedPassenger(passenger);
        setActiveView("offer-lab");
    };
    const handleToggleShortlist = (offer)=>{
        setShortlistedOffers((prev)=>prev.some((o)=>o.id === offer.id) ? prev.filter((o)=>o.id !== offer.id) : [
                ...prev,
                offer
            ]);
    };
    const handleRunSimulation = (persona, selectedOffers)=>{
        setCurrentPersona(persona);
        setShortlistedOffers(selectedOffers);
        setActiveView("simulation");
    };
    const handleSendOfferFromLab = (offer)=>{
        toast({
            title: "Offer Sent Successfully",
            description: `${offer.title} sent to ${selectedPassenger?.name} via ${selectedPassenger?.commChannel}`
        });
        setTimeout(()=>{
            setShortlistedOffers([]);
            setSelectedPassenger(null);
            setCurrentPersona(null);
            setActiveView("overview");
        }, 2000);
    };
    const handleSendOffer = (offer)=>{
        setTimeout(()=>{
            setShortlistedOffers([]);
            setSelectedPassenger(null);
            setCurrentPersona(null);
            setActiveView("overview");
        }, 2000);
    };
    const handleSuccessfulRefresh = ()=>{
        setRiskFeedRefreshKey((prevKey)=>prevKey + 1);
    };
    const renderView = ()=>{
        switch(activeView){
            case "overview":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$overview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Overview"], {
                    onSuccessfulRefresh: handleSuccessfulRefresh
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 151,
                    columnNumber: 16
                }, this);
            case "risk-feed":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$risk$2d$feed$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiskFeed"], {
                    onSelectPassenger: handleSelectPassenger,
                    refreshKey: riskFeedRefreshKey
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 153,
                    columnNumber: 16
                }, this);
            case "customer-360":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$customer$2d$360$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Customer360"], {
                    passenger: selectedPassenger,
                    onShortlistOffers: handleShortlistOffers
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 155,
                    columnNumber: 16
                }, this);
            case "offer-lab":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$offer$2d$lab$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OfferLab"], {
                    passenger: selectedPassenger,
                    shortlistedOffers: shortlistedOffers,
                    onToggleShortlist: handleToggleShortlist,
                    onRunSimulation: handleRunSimulation,
                    onNavigateHome: ()=>handleNavigateToHome("offer-lab"),
                    onSendOffer: handleSendOfferFromLab
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 158,
                    columnNumber: 11
                }, this);
            case "simulation":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$simulation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Simulation"], {
                    passenger: selectedPassenger,
                    shortlistedOffers: shortlistedOffers,
                    persona: currentPersona,
                    onSendOffer: handleSendOffer,
                    onNavigateHome: ()=>handleNavigateToHome("simulation")
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 169,
                    columnNumber: 11
                }, this);
            case "analytics":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$analytics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Analytics"], {}, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 178,
                    columnNumber: 16
                }, this);
            case "model-ops":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$model$2d$ops$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModelOps"], {}, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 180,
                    columnNumber: 16
                }, this);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$views$2f$overview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Overview"], {
                    onSuccessfulRefresh: handleSuccessfulRefresh
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 182,
                    columnNumber: 16
                }, this);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen bg-background overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 hex-pattern opacity-30 pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 189,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$sidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sidebar"], {
                activeView: activeView,
                onNavigate: handleNavigate,
                theme: theme,
                onToggleTheme: handleToggleTheme
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 191,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 overflow-y-auto relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "min-h-full grid-pattern",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$components$2f$AnimatePresence$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimatePresence"], {
                        mode: "wait",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            initial: {
                                opacity: 0,
                                x: 20
                            },
                            animate: {
                                opacity: 1,
                                x: 0
                            },
                            exit: {
                                opacity: 0,
                                x: -20
                            },
                            transition: {
                                duration: 0.2
                            },
                            children: renderView()
                        }, activeView, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 195,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 194,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 193,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 192,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$toaster$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toaster"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 207,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 187,
        columnNumber: 5
    }, this);
}
_s(CoraApp, "egw0+q9ei9g/U6a3eVbm2EHSLJ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = CoraApp;
var _c;
__turbopack_context__.k.register(_c, "CoraApp");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_73a370aa._.js.map