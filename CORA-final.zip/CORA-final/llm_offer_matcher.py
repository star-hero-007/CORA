import json
from openai import OpenAI

client = OpenAI(api_key="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")

def llm_match_offers_to_persona(persona_data, offers_list):
    traits_summary = ", ".join([f"{k}: {v}%" for k, v in persona_data['traits'].items()])
    
    offers_descriptions = []
    for offer in offers_list:
        offers_descriptions.append(f"ID: {offer['id']}, Title: {offer['title']}, Category: {offer['category']}, Description: {offer['description']}")
    
    offers_text = "\n".join(offers_descriptions)
    
    prompt = f"""You are an airline retention specialist. Match the best offers to this passenger persona.

Persona Summary: {persona_data['summary']}
Persona Traits: {traits_summary}
Top Behavioral Features: {', '.join(persona_data.get('top_features', []))}

Available Offers:
{offers_text}

Select the top 5 offers that best match this persona. For each offer, provide a fit score (0-100) based on how well it aligns with the persona's traits and behaviors.

Provide JSON:
{{
  "matched_offers": [
    {{
      "offer_id": "OFF-XXX",
      "fit_score": 95,
      "reasoning": "brief explanation why this offer fits"
    }},
    ...
  ]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline retention specialist. Match offers to customer personas based on behavioral analysis."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=800
        )
        
        raw_text = response.choices[0].message.content
        result = json.loads(raw_text)
        return result.get('matched_offers', [])
    except Exception as e:
        print(f"LLM offer matching failed: {e}")
        return []