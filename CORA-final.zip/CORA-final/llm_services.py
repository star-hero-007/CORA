# llm_services.py

import json
import numpy as np
from openai import OpenAI

client = OpenAI(api_key="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")

def llm_get_churn_driver_and_insights(features_dict, risk_score):
    prompt = f"""Analyze this airline passenger's churn risk and determine the PRIMARY churn driver.

Risk Score: {risk_score}%

Feature Values:
- Booking frequency change: {features_dict['booking_freq_change']:.2f}
- Fare downgrade trend: {features_dict['fare_downgrade_trend']:.2f}
- Booking abandon rate: {features_dict['booking_abandon_rate']:.2f}
- Recent disruptions: {features_dict['recent_disruption_count']:.0f}
- Service issues: {features_dict['recent_service_issues']:.0f}
- Lounge access issues: {features_dict['lounge_access_issues']:.0f}
- App usage drop: {features_dict['app_usage_drop']:.2f}
- Email engagement drop: {features_dict['email_engagement_drop']:.2f}
- Loyalty inactivity days: {features_dict['loyalty_inactivity_days']:.0f}
- Ancillary spend drop: {features_dict['ancillary_spend_drop']:.2f}
- Upgrade acceptance drop: {features_dict['upgrade_acceptance_drop']:.2f}
- Spend per trip decline: {features_dict['spend_per_trip_decline']:.2f}
- Frustration score: {features_dict['frustration_score_llm']:.2f}
- Complaint frequency change: {features_dict['complaint_frequency_change']:.2f}
- Churn intent signal: {features_dict['churn_intent_signal_llm']:.2f}

Determine the PRIMARY churn driver from: "Frequent Delays", "Service Failure", "Price Sensitivity", "Loyalty Neglect", "Route Changes", "Inactivity"

Provide JSON with:
{{
  "churn_driver": "one of the six categories",
  "insight": "brief explanation based on feature analysis",
  "top_contributing_features": ["feature1", "feature2", "feature3"]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline customer retention analyst. Provide ONLY valid JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500
        )
        
        raw_text = response.choices[0].message.content
        
        try:
            result = json.loads(raw_text)
            return result.get('churn_driver', 'Service Failure'), result
        except json.JSONDecodeError:
            start = raw_text.find('{')
            end = raw_text.rfind('}') + 1
            if start != -1 and end > start:
                result = json.loads(raw_text[start:end])
                return result.get('churn_driver', 'Service Failure'), result
            raise ValueError("Invalid JSON from LLM")
    except Exception as e:
        print(f"LLM analysis failed: {e}")
        return get_churn_driver_fallback(features_dict), {
            "churn_driver": get_churn_driver_fallback(features_dict),
            "insight": "Using rule-based analysis",
            "top_contributing_features": []
        }

def get_churn_driver_fallback(features_dict):
    drivers = {
        'Frequent Delays': features_dict.get('recent_disruption_count', 0),
        'Service Failure': features_dict.get('recent_service_issues', 0) + features_dict.get('lounge_access_issues', 0),
        'Price Sensitivity': features_dict.get('fare_downgrade_trend', 0),
        'Loyalty Neglect': features_dict.get('loyalty_inactivity_days', 0) / 100,
        'Route Changes': features_dict.get('booking_abandon_rate', 0),
        'Inactivity': features_dict.get('app_usage_drop', 0) + features_dict.get('email_engagement_drop', 0)
    }
    return max(drivers, key=drivers.get)

def llm_generate_persona_traits(persona_features):
    prompt = f"""Analyze this airline passenger's behavioral data and generate 5-6 unique persona traits.

Passenger Features:
- Average fare per km: {persona_features.get('avg_fare_per_km', 0):.2f}
- Cabin class mix ratio: {persona_features.get('cabin_class_mix_ratio', 0):.2f}
- Upgrade acceptance rate: {persona_features.get('upgrade_acceptance_rate', 0):.2f}
- Price comparison behavior: {persona_features.get('price_comparison_behavior_score', 0):.2f}
- Mobile-first engagement: {persona_features.get('mobile_first_engagement_score', 0):.2f}
- Spontaneous booking rate: {persona_features.get('spontaneous_booking_rate', 0):.2f}
- Meal preference intensity: {persona_features.get('meal_preference_intensity', 0):.2f}
- Lounge usage frequency: {persona_features.get('lounge_usage_frequency', 0):.2f}
- Complaint rate: {persona_features.get('complaint_rate', 0):.2f}
- Support sentiment score: {persona_features.get('support_sentiment_score', 0):.2f}
- Disruption rebooking rate: {persona_features.get('disruption_rebooking_rate', 0):.2f}
- Loyalty engagement score: {persona_features.get('loyalty_engagement_score', 0):.2f}
- Competitor search frequency: {persona_features.get('competitor_search_frequency', 0):.2f}

Generate 5-6 behavioral traits as percentages (0-100) that describe this passenger's travel preferences and behaviors.

Examples of traits: price_sensitive, comfort_preferred, genz_traveller, food_focused, lounge_enthusiast, low_frustration_tolerance, loyalty_oriented, spontaneous_traveler, mobile_native, premium_seeker

Also identify the top 5 most impactful features from the list above that define this persona's behavior.

Provide JSON:
{{
  "traits": {{
    "trait_name_1": percentage_value,
    "trait_name_2": percentage_value,
    ...
  }},
  "summary": "brief 1-2 sentence description of passenger archetype",
  "top_features": ["feature_name_1", "feature_name_2", "feature_name_3", "feature_name_4", "feature_name_5"]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline behavioral analyst. Generate passenger persona traits as JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=600
        )
        
        raw_text = response.choices[0].message.content
        result = json.loads(raw_text)
        return result
    except Exception as e:
        print(f"LLM persona generation failed: {e}")
        return generate_fallback_persona(persona_features)

def generate_fallback_persona(features):
    traits = {
        "price_sensitive": min(100, int(features.get('price_comparison_behavior_score', 50) * 100)),
        "comfort_preferred": min(100, int(features.get('cabin_class_mix_ratio', 0.3) * 100)),
        "mobile_native": min(100, int(features.get('mobile_first_engagement_score', 0.5) * 100)),
        "loyalty_oriented": min(100, int(features.get('loyalty_engagement_score', 0.5) * 100)),
        "low_frustration_tolerance": min(100, int(features.get('complaint_rate', 0) * 20))
    }
    
    top_features = sorted(features.items(), key=lambda x: abs(x[1]), reverse=True)[:5]
    
    return {
        "traits": traits,
        "summary": "Behavioral profile generated from travel patterns",
        "top_features": [f[0] for f in top_features]
    }

def llm_match_offers_to_persona(persona_data, offers_list):
    traits_summary = ", ".join([f"{k}: {v}%" for k, v in persona_data['traits'].items()])
    
    offers_descriptions = []
    for offer in offers_list:
        offers_descriptions.append(f"ID: {offer['id']}, Title: {offer['title']}, Category: {offer['category']}, Description: {offer['description']}")
    
    offers_text = "\n".join(offers_descriptions)
    
    prompt = f"""You are an airline retention specialist. Match the best offers to this passenger persona.

Persona Summary: {persona_data['summary']}
Persona Traits: {traits_summary}
Top Behavioral Features: {', '.join(persona_data.get('top_features', []))}

Available Offers:
{offers_text}

Select the top 5 offers that best match this persona. For each offer, provide a fit score (0-100) based on how well it aligns with the persona's traits and behaviors.

Provide JSON:
{{
  "matched_offers": [
    {{
      "offer_id": "OFF-XXX",
      "fit_score": 95,
      "reasoning": "brief explanation why this offer fits"
    }},
    ...
  ]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline retention specialist. Match offers to customer personas based on behavioral analysis."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=800
        )
        
        raw_text = response.choices[0].message.content
        result = json.loads(raw_text)
        return result.get('matched_offers', [])
    except Exception as e:
        print(f"LLM offer matching failed: {e}")
        return []

def simulate_multi_agent_debate(persona_data, offers, agents, iterations, variability):
    results = []
    
    for offer in offers:
        agent_results = []
        
        for agent in agents:
            base_prob = offer['fit_score'] / 100
            
            if agent['type'] == 'emotional':
                frustration_trait = persona_data['traits'].get('low_frustration_tolerance', 50)
                base_prob *= (100 - frustration_trait) / 100
                base_prob *= 1.2
            elif agent['type'] == 'rational':
                loyalty_trait = persona_data['traits'].get('loyalty_oriented', 50)
                base_prob *= loyalty_trait / 100
            elif agent['type'] == 'financial':
                price_trait = persona_data['traits'].get('price_sensitive', 50)
                base_prob *= (100 - price_trait) / 150
                if offer['category'] == 'Discount':
                    base_prob *= 1.3
            elif agent['type'] == 'convenience':
                mobile_trait = persona_data['traits'].get('mobile_native', 50)
                base_prob *= mobile_trait / 100
            elif agent['type'] == 'experience':
                comfort_trait = persona_data['traits'].get('comfort_preferred', 50)
                base_prob *= comfort_trait / 100
                if offer['category'] == 'Experience':
                    base_prob *= 1.2
            
            variance = (np.random.random() - 0.5) * variability * 0.4
            final_prob = np.clip(base_prob + variance, 0.15, 0.95)
            
            decision = 'accept' if final_prob > 0.65 else ('reject' if final_prob < 0.35 else 'neutral')
            
            reasonings = {
                'emotional': [
                    "Recent frustrations suggest high receptivity to service recovery offers.",
                    "Emotional state indicates need for immediate positive reinforcement.",
                    "Past negative experiences create opportunity for redemption narrative."
                ],
                'rational': [
                    "LTV analysis supports investment in retention offer.",
                    "Long-term value proposition aligns with customer profile.",
                    "Cost-benefit calculation favors offer acceptance."
                ],
                'financial': [
                    "Price sensitivity profile matches offer value proposition.",
                    "Budget constraints suggest moderate acceptance likelihood.",
                    "Monetary value of offer aligns with spending patterns."
                ],
                'convenience': [
                    "Convenience factors strongly influence this customer segment.",
                    "Seamless experience delivery is a key driver.",
                    "Friction reduction in offer appeals to preferences."
                ],
                'experience': [
                    "Brand relationship history supports positive reception.",
                    "Past interactions indicate receptivity to experience-based offers.",
                    "Loyalty patterns suggest alignment with offer type."
                ]
            }
            
            agent_results.append({
                'agent_id': agent['id'],
                'agent_name': agent['name'],
                'decision': decision,
                'probability': int(final_prob * 100),
                'reasoning': reasonings[agent['type']][np.random.randint(0, 3)],
                'final_stance': f"Recommends proceeding with offer." if decision == 'accept' else (
                    f"Suggests alternative approach." if decision == 'reject' else "Neutral stance, additional factors needed."
                )
            })
        
        probabilities = []
        for _ in range(iterations):
            iter_prob = 0
            total_weight = 0
            
            for agent_result, agent in zip(agent_results, agents):
                iter_variance = (np.random.random() - 0.5) * variability * 20
                iter_prob += (agent_result['probability'] + iter_variance) * agent['weight']
                total_weight += agent['weight']
            
            normalized_prob = np.clip(iter_prob / total_weight, 15, 95)
            probabilities.append(normalized_prob)
        
        avg_prob = np.mean(probabilities)
        std_dev = np.std(probabilities)
        
        recommendation = 'highly_recommended' if avg_prob >= 75 else (
            'recommended' if avg_prob >= 55 else (
                'neutral' if avg_prob >= 40 else 'not_recommended'
            )
        )
        
        top_agents = sorted(agent_results, key=lambda x: x['probability'], reverse=True)[:2]
        
        results.append({
            'offer_id': offer['id'],
            'offer_title': offer['title'],
            'acceptance_likelihood': int(avg_prob),
            'confidence': max(60, int(100 - std_dev * 2)),
            'variance': round(std_dev, 1),
            'agent_results': agent_results,
            'top_influencing_arguments': [a['reasoning'] for a in top_agents],
            'recommendation': recommendation
        })
    
    results.sort(key=lambda x: x['acceptance_likelihood'], reverse=True)
    return results