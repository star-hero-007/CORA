"use client"

import { motion } from "framer-motion"
import { Moon, Sun } from "lucide-react"
import { cn } from "@/lib/utils"

interface ThemeToggleProps {
  theme: "light" | "dark"
  onToggle: () => void
}

export function ThemeToggle({ theme, onToggle }: ThemeToggleProps) {
  return (
    <button
      onClick={onToggle}
      className={cn(
        "relative flex items-center w-14 h-7 rounded-full p-1 transition-colors duration-300",
        "border border-border",
        theme === "dark" ? "bg-secondary" : "bg-muted",
      )}
      aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
    >
      {/* Track icons */}
      <Sun
        className={cn(
          "absolute left-1.5 w-3.5 h-3.5 transition-opacity duration-300",
          theme === "light" ? "opacity-0" : "opacity-40 text-muted-foreground",
        )}
      />
      <Moon
        className={cn(
          "absolute right-1.5 w-3.5 h-3.5 transition-opacity duration-300",
          theme === "dark" ? "opacity-0" : "opacity-40 text-muted-foreground",
        )}
      />

      {/* Sliding indicator */}
      <motion.div
        className={cn("w-5 h-5 rounded-full flex items-center justify-center", "bg-primary shadow-sm")}
        animate={{
          x: theme === "dark" ? 28 : 0,
        }}
        transition={{
          type: "spring",
          stiffness: 500,
          damping: 30,
        }}
      >
        {theme === "dark" ? (
          <Moon className="w-3 h-3 text-primary-foreground" />
        ) : (
          <Sun className="w-3 h-3 text-primary-foreground" />
        )}
      </motion.div>
    </button>
  )
}
