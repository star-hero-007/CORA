"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  LayoutDashboard,
  AlertTriangle,
  User,
  Gift,
  FlaskConical,
  BarChart3,
  Cpu,
  ChevronDown,
  Radar,
  Zap,
  Brain,
  Terminal,
  Activity,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { ThemeToggle } from "@/components/theme-toggle"

interface SidebarProps {
  activeView: string
  onNavigate: (view: string) => void
  theme: "light" | "dark"
  onToggleTheme: () => void
}

interface NavGroup {
  title: string
  icon: React.ReactNode
  items: { id: string; label: string; icon: React.ReactNode }[]
}

const navGroups: NavGroup[] = [
  {
    title: "INTELLIGENCE",
    icon: <Brain className="w-3 h-3" />,
    items: [
      { id: "overview", label: "Overview", icon: <LayoutDashboard className="w-4 h-4" /> },
      { id: "risk-feed", label: "Risk Feed", icon: <AlertTriangle className="w-4 h-4" /> },
      { id: "customer-360", label: "Customer 360", icon: <User className="w-4 h-4" /> },
    ],
  },
  {
    title: "ACTIONS",
    icon: <Zap className="w-3 h-3" />,
    items: [
      { id: "offer-lab", label: "Offer Lab", icon: <Gift className="w-4 h-4" /> },
      { id: "simulation", label: "Simulation", icon: <FlaskConical className="w-4 h-4" /> },
    ],
  },
  {
    title: "INSIGHTS",
    icon: <Radar className="w-3 h-3" />,
    items: [
      { id: "analytics", label: "Analytics", icon: <BarChart3 className="w-4 h-4" /> },
      { id: "model-ops", label: "Model Ops", icon: <Cpu className="w-4 h-4" /> },
    ],
  },
]

function TerminalStatus() {
  const [text, setText] = useState("")
  const [showCursor, setShowCursor] = useState(true)
  const fullText = "SYSTEMS NOMINAL"

  useEffect(() => {
    let i = 0
    const typeInterval = setInterval(() => {
      if (i < fullText.length) {
        setText(fullText.slice(0, i + 1))
        i++
      } else {
        clearInterval(typeInterval)
      }
    }, 100)

    const cursorInterval = setInterval(() => {
      setShowCursor((prev) => !prev)
    }, 530)

    return () => {
      clearInterval(typeInterval)
      clearInterval(cursorInterval)
    }
  }, [])

  return (
    <span className="text-primary text-[10px] tracking-wider">
      {text}
      <span className={cn("ml-0.5", showCursor ? "opacity-100" : "opacity-0")}>_</span>
    </span>
  )
}

export function Sidebar({ activeView, onNavigate, theme, onToggleTheme }: SidebarProps) {
  const [expandedGroups, setExpandedGroups] = useState<string[]>(["INTELLIGENCE", "ACTIONS", "INSIGHTS"])

  const toggleGroup = (title: string) => {
    setExpandedGroups((prev) => (prev.includes(title) ? prev.filter((g) => g !== title) : [...prev, title]))
  }

  return (
    <div className="w-64 h-screen bg-sidebar border-r border-sidebar-border flex flex-col relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none opacity-30 scanlines" />

      {/* Logo */}
      <div className="p-5 border-b border-sidebar-border relative">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center border border-primary/30 glow-primary">
            <Terminal className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-widest text-primary glow-text">CORA</h1>
            <p className="text-[9px] uppercase tracking-[0.25em] text-muted-foreground">Retention Agent v2.1</p>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2">
          <Activity className="w-3 h-3 text-chart-4 animate-pulse" />
          <TerminalStatus />
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navGroups.map((group, groupIndex) => (
          <div key={group.title} className="space-y-1">
            <button
              onClick={() => toggleGroup(group.title)}
              className={cn(
                "flex items-center justify-between w-full px-3 py-2.5 rounded",
                "bg-gradient-to-r from-primary/5 to-transparent",
                "border-l-2 border-primary/50",
                "text-[10px] font-bold uppercase tracking-[0.2em]",
                "text-primary/80 hover:text-primary transition-colors",
                "mt-4 first:mt-0",
              )}
            >
              <span className="flex items-center gap-2">
                <span className="text-primary/60">{group.icon}</span>
                <span className="text-primary/60 font-mono">[{groupIndex + 1}]</span>
                {group.title}
              </span>
              <ChevronDown
                className={cn(
                  "w-3 h-3 transition-transform duration-200 text-primary/50",
                  expandedGroups.includes(group.title) ? "rotate-0" : "-rotate-90",
                )}
              />
            </button>
            <AnimatePresence>
              {expandedGroups.includes(group.title) && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden pl-2"
                >
                  {group.items.map((item, itemIndex) => (
                    <button
                      key={item.id}
                      onClick={() => onNavigate(item.id)}
                      className={cn(
                        "flex items-center gap-3 w-full px-3 py-2.5 rounded text-xs transition-all duration-200 group",
                        "border border-transparent",
                        activeView === item.id
                          ? "bg-primary/10 text-primary border-primary/30 glow-primary"
                          : "text-sidebar-foreground hover:text-foreground hover:bg-sidebar-accent hover:border-border",
                      )}
                    >
                      <span
                        className={cn(
                          "font-mono text-[10px] w-4",
                          activeView === item.id ? "text-primary" : "text-muted-foreground/50",
                        )}
                      >
                        {">"}
                      </span>
                      <span
                        className={
                          activeView === item.id
                            ? "text-primary"
                            : "text-sidebar-foreground group-hover:text-foreground"
                        }
                      >
                        {item.icon}
                      </span>
                      <span className="flex-1 text-left">{item.label}</span>
                      {activeView === item.id && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"
                        />
                      )}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </nav>

      {/* Agent Status */}
      <div className="p-3 border-t border-sidebar-border">
        <div className="p-3 rounded bg-card/50 border border-primary/20 corner-brackets">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-2 h-2 rounded-full bg-chart-4 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-chart-4">Agents Online</span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-[10px]">
            <div className="text-center p-2 rounded bg-background/50">
              <div className="font-mono text-sm text-primary font-bold">3</div>
              <div className="text-muted-foreground mt-0.5">Active</div>
            </div>
            <div className="text-center p-2 rounded bg-background/50">
              <div className="font-mono text-sm text-foreground font-bold">847</div>
              <div className="text-muted-foreground mt-0.5">Analyzed</div>
            </div>
            <div className="text-center p-2 rounded bg-background/50">
              <div className="font-mono text-sm text-accent font-bold">23</div>
              <div className="text-muted-foreground mt-0.5">Offers</div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-3 border-t border-sidebar-border">
        <div className="flex items-center justify-between px-2">
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Theme</span>
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
        </div>
      </div>
    </div>
  )
}
