"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import {
  Gift,
  Crown,
  Plane,
  ArrowUpCircle,
  Shield,
  Sparkles,
  FlaskConical,
  Plus,
  Users,
  Armchair,
  Terminal,
  Brain,
  Home,
  Send,
  User,
  Heart,
  DollarSign,
  Star,
  AlertCircle,
  Zap,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { type Passenger } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

interface PersonaTrait {
  [key: string]: number
}

interface Offer {
  id: string
  title: string
  description: string
  category: string
  value: number
  icon: string
  status: string
  fit_score: number
  match_reasoning?: string
}

interface GeneratedPersona {
  id: string
  name: string
  traits: PersonaTrait
  summary: string
  top_features: string[]
  matched_offers: Offer[]
  rawFeatures?: Record<string, number>
}

interface OfferLabProps {
  passenger: Passenger | null
  shortlistedOffers: Offer[]
  onToggleShortlist: (offer: Offer) => void
  onRunSimulation: (persona: GeneratedPersona, selectedOffers: Offer[]) => void
  onNavigateHome: () => void
  onSendOffer: (offer: Offer) => void
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Crown,
  Plane,
  ArrowUpCircle,
  Gift,
  Shield,
  Sparkles,
  Users,
  Armchair,
  Star,
  Zap,
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'

function EmptyState({ onNavigateHome }: { onNavigateHome: () => void }) {
  const [cursorVisible, setCursorVisible] = useState(true)
  const [allOffers, setAllOffers] = useState<Offer[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setCursorVisible((prev) => !prev)
    }, 530)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    fetchOffers()
  }, [])

  const fetchOffers = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/offers`)
      const data = await response.json()
      setAllOffers(data.offers || [])
    } catch (error) {
      console.error('Failed to fetch offers:', error)
    } finally {
      setLoading(false)
    }
  }

  const activeOffers = allOffers.filter((o) => o.status === "active")

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight text-primary">OFFER_LAB</h1>
          </div>
          <p className="text-muted-foreground text-sm font-mono">
            <span className="text-primary">$</span> offers.catalog | active
          </p>
        </div>
      </div>

      <div className="p-4 rounded border border-accent/30 bg-accent/5 corner-brackets">
        <div className="flex items-center gap-3">
          <Brain className="w-5 h-5 text-accent" />
          <div>
            <p className="text-sm font-mono text-accent">Select a passenger to generate personalized offers</p>
            <p className="text-xs text-muted-foreground font-mono mt-1">
              Navigate to <span className="text-primary">Customer 360</span> and click "Show Personalised Offer"
              <span className={cn("ml-1", cursorVisible ? "opacity-100" : "opacity-0")}>_</span>
            </p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="catalog" className="w-full">
        <TabsList className="bg-muted/50 border border-border">
          <TabsTrigger
            value="catalog"
            className="font-mono text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
          >
            OFFER CATALOG ({activeOffers.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="catalog" className="mt-4">
          {loading ? (
            <div className="flex justify-center py-12">
              <p className="text-sm text-muted-foreground font-mono">Loading offers...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {activeOffers.map((offer, index) => {
                const IconComponent = iconMap[offer.icon] || Gift
                return (
                  <motion.div
                    key={offer.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Card className="bg-card border-border hover:border-primary/30 transition-all">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center border border-primary/20">
                            <IconComponent className="w-5 h-5 text-primary" />
                          </div>
                          <Badge variant="outline" className="text-[10px] font-mono text-foreground">
                            {offer.category}
                          </Badge>
                        </div>
                        <h3 className="font-bold text-sm mb-1 text-foreground">{offer.title}</h3>
                        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{offer.description}</p>
                        <div className="flex items-center justify-between pt-3 border-t border-border text-[10px] font-mono text-muted-foreground">
                          <span>${offer.value}</span>
                          <span className="text-chart-4">{offer.success_rate || 0}% success</span>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

function PersonaCreationLoader({ passenger }: { passenger: Passenger }) {
  const [step, setStep] = useState(0)
  const steps = [
    { label: "Fetching behavioral data...", icon: Plane },
    { label: "Analyzing travel patterns...", icon: Plane },
    { label: "Processing sentiment data...", icon: Heart },
    { label: "Evaluating loyalty metrics...", icon: Star },
    { label: "Calculating price sensitivity...", icon: DollarSign },
    { label: "Building digital twin...", icon: User },
    { label: "Matching best offers...", icon: Gift },
    { label: "Generating persona traits...", icon: Brain },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => Math.min(prev + 1, steps.length - 1))
    }, 400)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex flex-col items-center justify-center py-16">
      <div className="relative mb-8">
        <motion.div
          animate={{
            scale: [1, 1.05, 1],
            boxShadow: [
              "0 0 20px rgba(45, 212, 191, 0.3)",
              "0 0 40px rgba(45, 212, 191, 0.5)",
              "0 0 20px rgba(45, 212, 191, 0.3)",
            ],
          }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center border-2 border-primary/50"
        >
          <User className="w-12 h-12 text-primary" />
        </motion.div>

        {[0, 1, 2, 3].map((i) => (
          <motion.div
            key={i}
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "linear", delay: i * 0.75 }}
            className="absolute inset-0"
          >
            <motion.div
              animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: i * 0.25 }}
              className="absolute w-3 h-3 rounded-full bg-primary"
              style={{ top: "-6px", left: "50%", transform: "translateX(-50%)" }}
            />
          </motion.div>
        ))}

        <motion.div
          animate={{ y: [-48, 48, -48] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent"
          style={{ top: "50%" }}
        />
      </div>

      <div className="w-64 mb-6">
        <Progress value={((step + 1) / steps.length) * 100} className="h-2" />
      </div>

      <motion.div key={step} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          {(() => {
            const StepIcon = steps[step].icon
            return <StepIcon className="w-5 h-5 text-primary animate-pulse" />
          })()}
          <p className="text-base font-bold font-mono text-primary">Creating Persona</p>
        </div>
        <p className="text-sm text-muted-foreground font-mono">{steps[step].label}</p>
      </motion.div>

      <div className="mt-6 text-center">
        <p className="text-xs text-muted-foreground font-mono">
          Analyzing <span className="text-primary">{passenger.name}</span>
        </p>
        <p className="text-[10px] text-muted-foreground/60 font-mono mt-1">
          {passenger.totalFlights} flights | {passenger.tier} tier | Risk: {passenger.riskScore}%
        </p>
      </div>
    </div>
  )
}

function PersonaAndOffers({
  passenger,
  persona,
  shortlistedOffers,
  onSendOffer,
  onRunSimulation,
}: {
  passenger: Passenger
  persona: GeneratedPersona
  shortlistedOffers: Offer[]
  onSendOffer: (offer: Offer) => void
  onRunSimulation: () => void
}) {
  const formatTraitName = (key: string): string => {
    return key
    .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ')
  }

  const formatFeatureName = (key: string): string => {
    return key
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ')
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <Card className="bg-card border-primary/30 corner-brackets glow-primary">
        <CardContent className="p-6">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center border-2 border-primary/50">
              <User className="w-8 h-8 text-primary" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-lg font-bold text-foreground">{persona.name}</h3>
                <Badge className="bg-primary/20 text-primary border-primary/30 text-[10px] font-mono">
                  DIGITAL TWIN
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{persona.summary}</p>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex items-center gap-2 mb-3">
              <Brain className="w-4 h-4 text-accent" />
              <span className="text-sm font-mono font-bold text-foreground">Behavioral Traits</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(persona.traits).map(([key, value]) => (
                <div key={key} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-muted-foreground">{formatTraitName(key)}</span>
                    <span className="text-[10px] font-mono text-primary">{Math.round(value)}%</span>
                  </div>
                  <Progress value={value} className="h-1.5" />
                </div>
              ))}
            </div>
          </div>

          {persona.top_features && persona.top_features.length > 0 && (
            <div className="mb-4 pt-3 border-t border-border">
              <div className="flex items-center gap-2 mb-2">
                <Star className="w-4 h-4 text-accent" />
                <span className="text-xs font-mono font-bold text-foreground">Top Behavioral Features</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {persona.top_features.map((feature, idx) => (
                  <Badge key={idx} variant="outline" className="text-[10px] font-mono text-foreground">
                    {formatFeatureName(feature)}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {persona.rawFeatures && (
            <div className="pt-3 border-t border-border">
              <details className="group">
                <summary className="text-xs font-mono text-muted-foreground cursor-pointer hover:text-primary transition-colors">
                  View Raw Features →
                </summary>
                <div className="mt-2 grid grid-cols-2 md:grid-cols-3 gap-2">
                  {Object.entries(persona.rawFeatures).slice(0, 6).map(([key, value]) => (
                    <Badge key={key} variant="outline" className="text-[9px] font-mono text-foreground justify-between">
                      <span className="truncate">{key.replace(/_/g, ' ')}</span>
                      <span className="ml-1 text-primary">{typeof value === 'number' ? value.toFixed(2) : value}</span>
                    </Badge>
                  ))}
                </div>
              </details>
            </div>
          )}
        </CardContent>
      </Card>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <Gift className="w-4 h-4 text-primary" />
          <span className="text-sm font-mono font-bold text-foreground">PERSONALISED OFFERS</span>
          <span className="text-xs text-muted-foreground font-mono">// AI-matched for this persona</span>
        </div>

        <div className="space-y-3">
          {shortlistedOffers.map((offer, index) => {
            const IconComponent = iconMap[offer.icon] || Gift
            return (
              <motion.div
                key={offer.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className={cn(
                    "bg-card border-border hover:border-primary/50 transition-all",
                    index === 0 && "border-chart-4/50 bg-chart-4/5",
                  )}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div
                        className={cn(
                          "w-10 h-10 rounded flex items-center justify-center border",
                          index === 0 ? "bg-chart-4/20 border-chart-4/30" : "bg-primary/10 border-primary/20",
                        )}
                      >
                        <IconComponent className={cn("w-5 h-5", index === 0 ? "text-chart-4" : "text-primary")} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {index === 0 && (
                            <Badge className="bg-chart-4/20 text-chart-4 border-chart-4/30 text-[10px] font-mono">
                              TOP PICK
                            </Badge>
                          )}
                          <h4 className="font-bold text-sm text-foreground">{offer.title}</h4>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-1">{offer.description}</p>
                        {offer.match_reasoning && (
                          <p className="text-[10px] text-accent mt-1 line-clamp-1">
                            <span className="font-mono">AI:</span> {offer.match_reasoning}
                          </p>
                        )}
                      </div>
                      <div className="text-right mr-4">
                        <p className="text-lg font-bold font-mono text-primary">{offer.fit_score}%</p>
                        <p className="text-[10px] text-muted-foreground font-mono">FIT SCORE</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => onSendOffer(offer)}
                        className="font-mono text-xs bg-primary hover:bg-primary/90"
                      >
                        <Send className="w-3 h-3 mr-1" />
                        Send
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      </div>

      <div className="flex gap-4 pt-4 border-t border-border">
        <Button
          onClick={onRunSimulation}
          className="flex-1 font-mono bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          <FlaskConical className="w-4 h-4 mr-2" />
          Run Simulation with Top {shortlistedOffers.length}
        </Button>
      </div>
    </motion.div>
  )
}

export function OfferLab({
  passenger,
  shortlistedOffers,
  onToggleShortlist,
  onRunSimulation,
  onNavigateHome,
  onSendOffer,
}: OfferLabProps) {
  const [isCreatingPersona, setIsCreatingPersona] = useState(false)
  const [generatedPersona, setGeneratedPersona] = useState<GeneratedPersona | null>(null)
  const [personalizedOffers, setPersonalizedOffers] = useState<Offer[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (passenger && !generatedPersona) {
      generatePersonaFromAPI()
    }
  }, [passenger, generatedPersona])

  useEffect(() => {
    if (!passenger) {
      setGeneratedPersona(null)
      setPersonalizedOffers([])
      setIsCreatingPersona(false)
      setError(null)
    }
  }, [passenger])

  const generatePersonaFromAPI = async () => {
    if (!passenger) return

    setIsCreatingPersona(true)
    setError(null)

    try {
      const response = await fetch(`${API_BASE_URL}/api/generate-persona`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          passenger_id: passenger.id,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Failed to generate persona')
      }

      const data = await response.json()

      const persona: GeneratedPersona = {
        id: `gen-${passenger.id}`,
        name: `${passenger.name.split(" ")[0]}'s Digital Twin`,
        traits: data.traits,
        summary: data.summary,
        top_features: data.top_features || [],
        matched_offers: data.matched_offers || [],
        rawFeatures: data.raw_features,
      }

      setGeneratedPersona(persona)
      setPersonalizedOffers(data.matched_offers || [])
      setIsCreatingPersona(false)
    } catch (err) {
      console.error('Persona generation failed:', err)
      setError(err instanceof Error ? err.message : 'Failed to generate persona')
      setIsCreatingPersona(false)
    }
  }

  if (!passenger) {
    return <EmptyState onNavigateHome={onNavigateHome} />
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight text-primary">OFFER_LAB</h1>
          </div>
          <p className="text-muted-foreground text-sm font-mono">
            <span className="text-primary">$</span> persona.generate({passenger.name.split(" ")[0].toLowerCase()}) |
            offers.match
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={onNavigateHome} className="font-mono text-xs bg-transparent">
          <Home className="w-3.5 h-3.5 mr-1.5" />
          Back to 360
        </Button>
      </div>

      <div className="flex items-center gap-4 p-4 rounded border border-border bg-card/50">
        <div className="w-12 h-12 rounded bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-base font-bold font-mono border border-primary/20 text-foreground">
          {passenger.name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </div>
        <div className="flex-1">
          <p className="font-bold text-foreground">{passenger.name}</p>
          <p className="text-xs text-muted-foreground font-mono">
            {passenger.tier} | Risk: {passenger.riskScore}% | LTV: ${passenger.ltv.toLocaleString()}
          </p>
        </div>
        <Badge
          variant="outline"
          className={cn(
            "font-mono text-xs",
            passenger.riskScore >= 70
              ? "text-destructive border-destructive/30"
              : passenger.riskScore >= 40
                ? "text-accent border-accent/30"
                : "text-chart-4 border-chart-4/30",
          )}
        >
          {passenger.riskScore >= 70 ? "HIGH RISK" : passenger.riskScore >= 40 ? "MEDIUM RISK" : "LOW RISK"}
        </Badge>
      </div>

      {error && (
        <Card className="bg-destructive/10 border-destructive/30">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-destructive" />
              <div>
                <p className="text-sm font-bold text-destructive">Persona Generation Failed</p>
                <p className="text-xs text-muted-foreground mt-1">{error}</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={generatePersonaFromAPI}
                className="ml-auto font-mono text-xs"
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {isCreatingPersona ? (
        <PersonaCreationLoader passenger={passenger} />
      ) : generatedPersona ? (
        <PersonaAndOffers
          passenger={passenger}
          persona={generatedPersona}
          shortlistedOffers={personalizedOffers}
          onSendOffer={onSendOffer}
          onRunSimulation={() => onRunSimulation(generatedPersona, personalizedOffers)}
        />
      ) : null}
    </div>
  )
}