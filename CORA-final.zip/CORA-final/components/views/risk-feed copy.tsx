"use client"

import { useState, useMemo } from "react"
import { motion } from "framer-motion"
import {
  ArrowRight,
  Mail,
  MessageCircle,
  Smartphone,
  Search,
  Filter,
  ChevronDown,
  Terminal,
  SortAsc,
  SortDesc,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu"
import { passengers, type Passenger } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

interface RiskFeedProps {
  onSelectPassenger: (passenger: Passenger) => void
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.03 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0 },
}

const channelIcons = {
  Email: Mail,
  WhatsApp: MessageCircle,
  App: Smartphone,
}

function getRiskLevel(score: number) {
  if (score >= 70) return { label: "HIGH", color: "bg-destructive/20 text-destructive border-destructive/30" }
  if (score >= 40) return { label: "MED", color: "bg-accent/20 text-accent border-accent/30" }
  return { label: "LOW", color: "bg-chart-4/20 text-chart-4 border-chart-4/30" }
}

function getTierColor(tier: string) {
  switch (tier) {
    case "Platinum":
      return "bg-gradient-to-r from-slate-500/20 to-slate-400/20 text-slate-600 dark:text-slate-300 border-slate-400/30"
    case "Gold":
      return "bg-gradient-to-r from-amber-500/20 to-amber-400/20 text-amber-600 dark:text-amber-400 border-amber-500/30"
    case "Silver":
      return "bg-gradient-to-r from-zinc-500/20 to-zinc-400/20 text-zinc-600 dark:text-zinc-300 border-zinc-400/30"
    default:
      return "bg-gradient-to-r from-orange-600/20 to-orange-500/20 text-orange-600 dark:text-orange-400 border-orange-600/30"
  }
}

export function RiskFeed({ onSelectPassenger }: RiskFeedProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTiers, setSelectedTiers] = useState<string[]>([])
  const [selectedRiskLevels, setSelectedRiskLevels] = useState<string[]>([])
  const [selectedChannels, setSelectedChannels] = useState<string[]>([])
  const [sortField, setSortField] = useState<"riskScore" | "ltv" | "name">("riskScore")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  const filteredPassengers = useMemo(() => {
    let result = [...passengers]

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.id.toLowerCase().includes(query) ||
          p.email.toLowerCase().includes(query),
      )
    }

    // Tier filter
    if (selectedTiers.length > 0) {
      result = result.filter((p) => selectedTiers.includes(p.tier))
    }

    // Risk level filter
    if (selectedRiskLevels.length > 0) {
      result = result.filter((p) => {
        const level = getRiskLevel(p.riskScore).label
        return selectedRiskLevels.includes(level)
      })
    }

    // Channel filter
    if (selectedChannels.length > 0) {
      result = result.filter((p) => selectedChannels.includes(p.commChannel))
    }

    // Sorting
    result.sort((a, b) => {
      let comparison = 0
      if (sortField === "riskScore") {
        comparison = a.riskScore - b.riskScore
      } else if (sortField === "ltv") {
        comparison = a.ltv - b.ltv
      } else if (sortField === "name") {
        comparison = a.name.localeCompare(b.name)
      }
      return sortDirection === "desc" ? -comparison : comparison
    })

    return result
  }, [searchQuery, selectedTiers, selectedRiskLevels, selectedChannels, sortField, sortDirection])

  const toggleTier = (tier: string) => {
    setSelectedTiers((prev) => (prev.includes(tier) ? prev.filter((t) => t !== tier) : [...prev, tier]))
  }

  const toggleRiskLevel = (level: string) => {
    setSelectedRiskLevels((prev) => (prev.includes(level) ? prev.filter((l) => l !== level) : [...prev, level]))
  }

  const toggleChannel = (channel: string) => {
    setSelectedChannels((prev) => (prev.includes(channel) ? prev.filter((c) => c !== channel) : [...prev, channel]))
  }

  const toggleSort = (field: "riskScore" | "ltv" | "name") => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === "asc" ? "desc" : "asc"))
    } else {
      setSortField(field)
      setSortDirection("desc")
    }
  }

  const activeFiltersCount = selectedTiers.length + selectedRiskLevels.length + selectedChannels.length

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="p-6 space-y-6">
      {/* Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight text-primary">RISK_FEED</h1>
          </div>
          <p className="text-muted-foreground text-sm font-mono">
            <span className="text-primary">$</span> passengers.sort(churn_probability) | head -n{" "}
            {filteredPassengers.length}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-mono">
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-destructive/10 border border-destructive/20">
              <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
              <span className="text-destructive">{passengers.filter((p) => p.riskScore >= 70).length} HIGH</span>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-accent/10 border border-accent/20">
              <div className="w-2 h-2 rounded-full bg-accent" />
              <span className="text-accent">
                {passengers.filter((p) => p.riskScore >= 40 && p.riskScore < 70).length} MED
              </span>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-chart-4/10 border border-chart-4/20">
              <div className="w-2 h-2 rounded-full bg-chart-4" />
              <span className="text-chart-4">{passengers.filter((p) => p.riskScore < 40).length} LOW</span>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search passengers..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-card border-border font-mono text-sm"
          />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2 font-mono bg-transparent">
              <Filter className="w-4 h-4" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge className="ml-1 h-5 w-5 p-0 flex items-center justify-center bg-primary text-primary-foreground text-[10px]">
                  {activeFiltersCount}
                </Badge>
              )}
              <ChevronDown className="w-3 h-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            <DropdownMenuLabel className="font-mono text-xs text-muted-foreground">TIER</DropdownMenuLabel>
            {["Platinum", "Gold", "Silver", "Bronze"].map((tier) => (
              <DropdownMenuCheckboxItem
                key={tier}
                checked={selectedTiers.includes(tier)}
                onCheckedChange={() => toggleTier(tier)}
                className="font-mono text-sm"
              >
                {tier}
              </DropdownMenuCheckboxItem>
            ))}
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="font-mono text-xs text-muted-foreground">RISK LEVEL</DropdownMenuLabel>
            {["HIGH", "MED", "LOW"].map((level) => (
              <DropdownMenuCheckboxItem
                key={level}
                checked={selectedRiskLevels.includes(level)}
                onCheckedChange={() => toggleRiskLevel(level)}
                className="font-mono text-sm"
              >
                {level}
              </DropdownMenuCheckboxItem>
            ))}
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="font-mono text-xs text-muted-foreground">CHANNEL</DropdownMenuLabel>
            {["Email", "WhatsApp", "App"].map((channel) => (
              <DropdownMenuCheckboxItem
                key={channel}
                checked={selectedChannels.includes(channel)}
                onCheckedChange={() => toggleChannel(channel)}
                className="font-mono text-sm"
              >
                {channel}
              </DropdownMenuCheckboxItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {activeFiltersCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setSelectedTiers([])
              setSelectedRiskLevels([])
              setSelectedChannels([])
            }}
            className="text-muted-foreground hover:text-foreground font-mono text-xs"
          >
            Clear all
          </Button>
        )}
      </motion.div>

      {/* Table */}
      <motion.div variants={itemVariants}>
        <Card className="bg-card border-border overflow-hidden corner-brackets">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/30">
                    <th className="text-left p-4 text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
                      Passenger
                    </th>
                    <th
                      className="text-left p-4 text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono cursor-pointer hover:text-primary transition-colors"
                      onClick={() => toggleSort("riskScore")}
                    >
                      <span className="flex items-center gap-1">
                        Risk Score
                        {sortField === "riskScore" &&
                          (sortDirection === "desc" ? (
                            <SortDesc className="w-3 h-3" />
                          ) : (
                            <SortAsc className="w-3 h-3" />
                          ))}
                      </span>
                    </th>
                    <th
                      className="text-left p-4 text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono cursor-pointer hover:text-primary transition-colors"
                      onClick={() => toggleSort("ltv")}
                    >
                      <span className="flex items-center gap-1">
                        LTV
                        {sortField === "ltv" &&
                          (sortDirection === "desc" ? (
                            <SortDesc className="w-3 h-3" />
                          ) : (
                            <SortAsc className="w-3 h-3" />
                          ))}
                      </span>
                    </th>
                    <th className="text-left p-4 text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
                      Channel
                    </th>
                    <th className="text-left p-4 text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
                      Tier
                    </th>
                    <th className="text-right p-4 text-[10px] font-bold uppercase tracking-wider text-muted-foreground font-mono">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPassengers.map((passenger) => {
                    const risk = getRiskLevel(passenger.riskScore)
                    const ChannelIcon = channelIcons[passenger.commChannel]

                    return (
                      <motion.tr
                        key={passenger.id}
                        variants={itemVariants}
                        className="border-b border-border hover:bg-primary/5 transition-colors cursor-pointer group"
                        onClick={() => onSelectPassenger(passenger)}
                      >
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-xs font-bold font-mono border border-primary/20 text-foreground">
                              {passenger.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div>
                              <p className="font-medium text-sm text-foreground group-hover:text-primary transition-colors">
                                {passenger.name}
                              </p>
                              <p className="text-[10px] text-muted-foreground font-mono">{passenger.id}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${passenger.riskScore}%` }}
                                transition={{ duration: 0.5, delay: 0.2 }}
                                className={cn(
                                  "h-full rounded-full",
                                  passenger.riskScore >= 70
                                    ? "bg-destructive"
                                    : passenger.riskScore >= 40
                                      ? "bg-accent"
                                      : "bg-chart-4",
                                )}
                              />
                            </div>
                            <Badge variant="outline" className={cn("text-[10px] font-mono font-bold", risk.color)}>
                              {passenger.riskScore}%
                            </Badge>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="font-mono text-sm font-medium text-foreground">
                            ${(passenger.ltv / 1000).toFixed(0)}K
                          </span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <ChannelIcon className="w-4 h-4 text-muted-foreground" />
                            <span className="text-xs font-mono text-foreground">{passenger.commChannel}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge
                            variant="outline"
                            className={cn("text-[10px] font-mono", getTierColor(passenger.tier))}
                          >
                            {passenger.tier}
                          </Badge>
                        </td>
                        <td className="p-4 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-primary hover:text-primary hover:bg-primary/10 font-mono text-xs"
                            onClick={(e) => {
                              e.stopPropagation()
                              onSelectPassenger(passenger)
                            }}
                          >
                            ANALYZE
                            <ArrowRight className="w-3 h-3 ml-1" />
                          </Button>
                        </td>
                      </motion.tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            {filteredPassengers.length === 0 && (
              <div className="p-12 text-center">
                <p className="text-muted-foreground font-mono text-sm">No passengers match your filters</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}
