// overview.tsx
"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import {
  AlertTriangle,
  TrendingDown,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  RefreshCw,
  Clock,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { analyticsData, campaigns } from "@/lib/mock-data"
import { useToast } from "@/hooks/use-toast"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

const RISK_COLORS = {
  high: "#ef4444",
  medium: "#f59e0b",
  low: "#22c55e",
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'

// Added a new prop type to show how the key would be passed up/down
interface OverviewProps {
    onSuccessfulRefresh: () => void; 
}

// MODIFIED: Removed empty function body and use it in the export
export function Overview({ onSuccessfulRefresh }: OverviewProps) {
  const { toast } = useToast()
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastRefresh, setLastRefresh] = useState<Date>(() => {
    const now = new Date()
    return new Date(now.getTime() - 14 * 60 * 1000)
  })
  const [atRiskCount, setAtRiskCount] = useState(0)
  const [highRiskCount, setHighRiskCount] = useState(0)
  const [mediumRiskCount, setMediumRiskCount] = useState(0)
  const [lowRiskCount, setLowRiskCount] = useState(0)

  const getNextRefresh = () => {
    const now = new Date()
    return new Date(now.getTime() + 16 * 60 * 1000)
  }

  const [nextRefresh, setNextRefresh] = useState<Date>(getNextRefresh)

  const fetchStatistics = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/statistics`)
      if (!response.ok) throw new Error('Failed to fetch statistics')
      
      const data = await response.json()
      setAtRiskCount(data.at_risk)
      setHighRiskCount(data.high_risk)
      setMediumRiskCount(data.medium_risk)
      setLowRiskCount(data.low_risk)
    } catch (error) {
      console.error('Error fetching statistics:', error)
    }
  }

  useEffect(() => {
    fetchStatistics()
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setNextRefresh(getNextRefresh())
    }, 60000)
    return () => clearInterval(interval)
  }, [])

  const formatDateTime = (date: Date) => {
    return date.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })
  }

  const handleRefresh = async () => {
  setIsRefreshing(true)

  try {
    const response = await fetch(`${API_BASE_URL}/api/refresh-predictions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    })

    if (!response.ok) {
      throw new Error('Failed to refresh predictions')
    }

    const result = await response.json()

    setAtRiskCount(result.statistics.at_risk)
    setHighRiskCount(result.statistics.high_risk)
    setMediumRiskCount(result.statistics.medium_risk)
    setLowRiskCount(result.statistics.low_risk)

    setLastRefresh(new Date())
    setNextRefresh(getNextRefresh())
    
    onSuccessfulRefresh()  // ← ADDED: Notify parent component

    toast({
      title: "Predictions Updated",
      description: `Risk scores recalculated. ${result.statistics.at_risk} customers at risk.`,
    })
  } catch (error) {
    toast({
      title: "Refresh Failed",
      description: "Unable to update predictions. Please try again.",
      variant: "destructive",
    })
  } finally {
    setIsRefreshing(false)
  }
}

  const stats = [
    {
      title: "At-Risk Customers",
      value: atRiskCount.toString(),
      change: -12.3,
      icon: AlertTriangle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
    },
    {
      title: "Revenue at Risk",
      value: "$2.4M",
      change: -8.7,
      icon: DollarSign,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "Revenue Saved",
      value: "$879K",
      change: 23.4,
      icon: TrendingDown,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Active Campaigns",
      value: "12",
      change: 4,
      icon: Target,
      color: "text-chart-3",
      bgColor: "bg-chart-3/10",
    },
  ]

  const riskDistribution = [
    { name: "High Risk", value: highRiskCount, color: RISK_COLORS.high },
    { name: "Medium Risk", value: mediumRiskCount, color: RISK_COLORS.medium },
    { name: "Low Risk", value: lowRiskCount, color: RISK_COLORS.low },
  ]

  const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }: any) => {
    const RADIAN = Math.PI / 180
    const radius = innerRadius + (outerRadius - innerRadius) * 1.4
    const x = cx + radius * Math.cos(-midAngle * RADIAN)
    const y = cy + radius * Math.sin(-midAngle * RADIAN)

    return (
      <text
        x={x}
        y={y}
        fill="currentColor"
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
        className="text-xs font-mono fill-muted-foreground"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    )
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="text-sm font-medium text-foreground mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-xs text-muted-foreground">
              <span style={{ color: entry.color }}>{entry.name}:</span> {entry.value}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="p-6 space-y-6">
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Mission Control</h1>
          <p className="text-muted-foreground mt-1">Real-time retention intelligence overview</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end gap-1 px-4 py-2 rounded-lg bg-muted/50 border border-border">
            <div className="flex items-center gap-2 text-xs">
              <Clock className="w-3 h-3 text-muted-foreground" />
              <span className="text-muted-foreground">Last Refresh:</span>
              <span className="font-medium text-foreground">{formatDateTime(lastRefresh)}</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Clock className="w-3 h-3 text-primary" />
              <span className="text-muted-foreground">Next Scheduled:</span>
              <span className="font-medium text-primary">{formatDateTime(nextRefresh)}</span>
            </div>
          </div>
          <Button onClick={handleRefresh} disabled={isRefreshing} size="sm" className="font-mono">
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            {isRefreshing ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
      </motion.div>

      <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={stat.title} className="bg-card border-border overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`w-5 h-5 ${stat.color}`} />
                </div>
                <div
                  className={`flex items-center gap-1 text-xs font-medium ${
                    stat.change > 0 ? "text-chart-4" : "text-destructive"
                  }`}
                >
                  {stat.change > 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {Math.abs(stat.change)}%
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold tracking-tight">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div variants={itemVariants} className="lg:col-span-2">
          <Card className="bg-card border-border h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold">Risk Level Trend</CardTitle>
              <p className="text-sm text-muted-foreground">Customer risk distribution over time</p>
            </CardHeader>
            <CardContent>
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={analyticsData.riskTrend}>
                    <defs>
                      <linearGradient id="highRiskGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={RISK_COLORS.high} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={RISK_COLORS.high} stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="medRiskGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={RISK_COLORS.medium} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={RISK_COLORS.medium} stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="lowRiskGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={RISK_COLORS.low} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={RISK_COLORS.low} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis
                      dataKey="month"
                      className="text-muted-foreground"
                      fontSize={12}
                      tick={{ fill: "currentColor" }}
                    />
                    <YAxis className="text-muted-foreground" fontSize={12} tick={{ fill: "currentColor" }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area
                      type="monotone"
                      dataKey="highRisk"
                      name="High Risk"
                      stroke={RISK_COLORS.high}
                      fill="url(#highRiskGrad)"
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="mediumRisk"
                      name="Medium Risk"
                      stroke={RISK_COLORS.medium}
                      fill="url(#medRiskGrad)"
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="lowRisk"
                      name="Low Risk"
                      stroke={RISK_COLORS.low}
                      fill="url(#lowRiskGrad)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-card border-border h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold">Risk Distribution</CardTitle>
              <p className="text-sm text-muted-foreground">Current customer segments</p>
            </CardHeader>
            <CardContent>
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={70}
                      paddingAngle={4}
                      dataKey="value"
                      label={renderCustomLabel}
                      labelLine={{ stroke: "currentColor", strokeWidth: 1, className: "stroke-muted-foreground" }}
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke={entry.color} strokeWidth={2} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-4 mt-3 pt-3 border-t border-border">
                {riskDistribution.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-sm border"
                      style={{ backgroundColor: item.color, borderColor: item.color }}
                    />
                    <span className="text-xs text-foreground font-medium">{item.name}</span>
                    <span className="text-xs text-muted-foreground font-mono">({item.value})</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div variants={itemVariants}>
          <Card className="bg-card border-border h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold">Offer Performance</CardTitle>
              <p className="text-sm text-muted-foreground">Acceptance vs Retention by offer type</p>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analyticsData.offerPerformance} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
                    <XAxis
                      type="number"
                      className="text-muted-foreground"
                      fontSize={12}
                      tick={{ fill: "currentColor" }}
                    />
                    <YAxis
                      dataKey="offer"
                      type="category"
                      className="text-muted-foreground"
                      fontSize={11}
                      width={90}
                      tick={{ fill: "currentColor" }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      wrapperStyle={{ paddingTop: "10px" }}
                      formatter={(value) => <span className="text-foreground text-xs">{value}</span>}
                    />
                    <Bar dataKey="acceptance" name="Acceptance %" fill="#2dd4bf" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="retention" name="Retention %" fill="#f59e0b" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-card border-border h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-semibold">Churn Driver Distribution</CardTitle>
              <p className="text-sm text-muted-foreground">Primary reasons for customer churn</p>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={analyticsData.churnDrivers}>
                    <PolarGrid className="stroke-border" />
                    <PolarAngleAxis
                      dataKey="driver"
                      className="text-muted-foreground"
                      fontSize={11}
                      tick={{ fill: "currentColor" }}
                    />
                    <PolarRadiusAxis className="text-muted-foreground" fontSize={10} tick={{ fill: "currentColor" }} />
                    <Radar name="Cases" dataKey="count" stroke="#2dd4bf" fill="#2dd4bf" fillOpacity={0.3} />
                    <Tooltip content={<CustomTooltip />} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div variants={itemVariants}>
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg font-semibold">Active Campaigns</CardTitle>
                <p className="text-sm text-muted-foreground">Ongoing retention interventions</p>
              </div>
              <div className="px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
                {campaigns.filter((c) => c.status === "active").length} Running
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {campaigns.slice(0, 3).map((campaign) => (
                <div
                  key={campaign.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border border-border hover:border-primary/30 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        campaign.status === "active" ? "bg-primary animate-pulse" : "bg-muted-foreground"
                      }`}
                    />
                    <div>
                      <p className="font-medium text-foreground">{campaign.name}</p>
                      <p className="text-sm text-muted-foreground">{campaign.targetSegment}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-8">
                    <div className="text-right">
                      <p className="text-sm font-medium text-foreground">
                        {campaign.customersReached.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">Reached</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-primary">{campaign.conversionRate}%</p>
                      <p className="text-xs text-muted-foreground">Conversion</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-chart-4">${(campaign.revenueSaved / 1000).toFixed(0)}K</p>
                      <p className="text-xs text-muted-foreground">Saved</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}