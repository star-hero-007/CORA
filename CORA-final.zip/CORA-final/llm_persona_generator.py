import json
from openai import OpenAI

client = OpenAI(api_key="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")

def llm_generate_persona_traits(persona_features):
    prompt = f"""Analyze this airline passenger's behavioral data and generate 5-6 unique persona traits.

Passenger Features:
- Average fare per km: {persona_features.get('avg_fare_per_km', 0):.2f}
- Cabin class mix ratio: {persona_features.get('cabin_class_mix_ratio', 0):.2f}
- Upgrade acceptance rate: {persona_features.get('upgrade_acceptance_rate', 0):.2f}
- Price comparison behavior: {persona_features.get('price_comparison_behavior_score', 0):.2f}
- Mobile-first engagement: {persona_features.get('mobile_first_engagement_score', 0):.2f}
- Spontaneous booking rate: {persona_features.get('spontaneous_booking_rate', 0):.2f}
- Meal preference intensity: {persona_features.get('meal_preference_intensity', 0):.2f}
- Lounge usage frequency: {persona_features.get('lounge_usage_frequency', 0):.2f}
- Complaint rate: {persona_features.get('complaint_rate', 0):.2f}
- Support sentiment score: {persona_features.get('support_sentiment_score', 0):.2f}
- Disruption rebooking rate: {persona_features.get('disruption_rebooking_rate', 0):.2f}
- Loyalty engagement score: {persona_features.get('loyalty_engagement_score', 0):.2f}
- Competitor search frequency: {persona_features.get('competitor_search_frequency', 0):.2f}

Generate 5-6 behavioral traits as percentages (0-100) that describe this passenger's travel preferences and behaviors.

Examples of traits: price_sensitive, comfort_preferred, genz_traveller, food_focused, lounge_enthusiast, low_frustration_tolerance, loyalty_oriented, spontaneous_traveler, mobile_native, premium_seeker

Also identify the top 5 most impactful features from the list above that define this persona's behavior.

Provide JSON:
{{
  "traits": {{
    "trait_name_1": percentage_value,
    "trait_name_2": percentage_value,
    ...
  }},
  "summary": "brief 1-2 sentence description of passenger archetype",
  "top_features": ["feature_name_1", "feature_name_2", "feature_name_3", "feature_name_4", "feature_name_5"]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline behavioral analyst. Generate passenger persona traits as JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=600
        )
        
        raw_text = response.choices[0].message.content
        result = json.loads(raw_text)
        return result
    except Exception as e:
        print(f"LLM persona generation failed: {e}")
        return generate_fallback_persona(persona_features)

def generate_fallback_persona(features):
    traits = {
        "price_sensitive": min(100, int(features.get('price_comparison_behavior_score', 50) * 100)),
        "comfort_preferred": min(100, int(features.get('cabin_class_mix_ratio', 0.3) * 100)),
        "mobile_native": min(100, int(features.get('mobile_first_engagement_score', 0.5) * 100)),
        "loyalty_oriented": min(100, int(features.get('loyalty_engagement_score', 0.5) * 100)),
        "low_frustration_tolerance": min(100, int(features.get('complaint_rate', 0) * 20))
    }
    
    top_features = sorted(features.items(), key=lambda x: abs(x[1]), reverse=True)[:5]
    
    return {
        "traits": traits,
        "summary": "Behavioral profile generated from travel patterns",
        "top_features": [f[0] for f in top_features]
    }