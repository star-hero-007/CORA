import openai
from openai import OpenAI
import numpy as np
from typing import List, Dict, Any
import json
import os

client = OpenAI(api_key="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")

def get_agent_system_prompt(agent_type: str) -> str:
    prompts = {
        'emotional': """You are an emotional decision-making agent. You prioritize feelings, gut instincts, and emotional connections. 
You're highly attuned to frustration, satisfaction, and emotional triggers. You care about how offers make customers feel 
and whether they address emotional needs. Consider past negative experiences and opportunities for positive emotional impact.""",
        
        'rational': """You are a rational analytical agent. You focus on logic, data, and long-term value calculations.
You analyze customer lifetime value, behavioral patterns, and make decisions based on objective metrics. 
You weigh costs against benefits systematically and consider historical data trends.""",
        
        'financial': """You are a financial optimization agent. You're laser-focused on monetary value, pricing, and budget constraints.
You evaluate offers through the lens of price sensitivity, discount impact, and spending patterns. 
You calculate whether the financial proposition makes sense for this customer's economic profile.""",
        
        'convenience': """You are a convenience-focused agent. You prioritize ease of use, friction reduction, and seamless experiences.
You evaluate how effortless an offer is to redeem and whether it fits the customer's lifestyle patterns.
Mobile accessibility and simplicity are your key considerations.""",
        
        'experience': """You are an experience-oriented agent. You focus on brand relationships, loyalty history, and experiential value.
You consider how offers enhance the customer journey and strengthen brand affinity.
Past interaction quality and relationship depth guide your decisions."""
    }
    return prompts.get(agent_type, prompts['rational'])

def generate_mood(variability: float) -> Dict[str, Any]:
    mood_intensity = variability * 100
    
    if mood_intensity < 20:
        moods = ['calm', 'neutral', 'balanced']
        intensity_level = 'low'
    elif mood_intensity < 50:
        moods = ['curious', 'cautious', 'thoughtful']
        intensity_level = 'moderate'
    elif mood_intensity < 75:
        moods = ['energetic', 'skeptical', 'enthusiastic']
        intensity_level = 'high'
    else:
        moods = ['intense', 'urgent', 'passionate']
        intensity_level = 'very_high'
    
    selected_mood = np.random.choice(moods)
    
    return {
        'mood': selected_mood,
        'intensity': intensity_level,
        'factor': round(mood_intensity / 100, 2)
    }

def call_llm_for_decision(agent: Dict, persona_data: Dict, offers: List[Dict], 
                          mood: Dict, temperature: float) -> Dict:
    
    system_prompt = get_agent_system_prompt(agent['type'])
    
    user_prompt = f"""You are currently in a {mood['mood']} mood with {mood['intensity']} intensity (factor: {mood['factor']}).
This mood affects your decision-making process.

Customer Persona Data:
{json.dumps(persona_data, indent=2)}

Available Offers:
{json.dumps(offers, indent=2)}

Analyze each offer and select the ONE best offer for this customer. Consider:
1. How well the offer matches the customer's traits and behavior patterns
2. Your agent type's specific priorities ({agent['type']} perspective)
3. Your current mood state and how it influences your judgment

Respond in this exact JSON format:
{{
    "selected_offer_id": "offer_id_here",
    "probability": 75,
    "reasoning": "Your detailed reasoning here",
    "mood_influence": "How your {mood['mood']} mood affected this decision"
}}

Probability should be between 15-95."""

    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=temperature,
            max_tokens=500
        )
        
        content = response.choices[0].message.content.strip()
        
        if content.startswith('```json'):
            content = content[7:]
        if content.endswith('```'):
            content = content[:-3]
        content = content.strip()
        
        decision = json.loads(content)
        
        return decision
        
    except Exception as e:
        print(f"LLM call failed for {agent['name']}: {str(e)}")
        fallback_offer = offers[0]
        return {
            "selected_offer_id": fallback_offer['id'],
            "probability": 50,
            "reasoning": f"Fallback decision due to error: {str(e)}",
            "mood_influence": "Unable to process mood influence"
        }

def simulate_multi_agent_debate(persona_data: Dict, offers: List[Dict], 
                                agents: List[Dict], iterations: int, 
                                variability: float) -> List[Dict]:
    
    offer_vote_counts = {offer['id']: [] for offer in offers}
    offer_agent_details = {offer['id']: [] for offer in offers}
    
    for iteration in range(iterations):
        temperature = 0.3 + (variability * 0.7)
        mood = generate_mood(variability)
        
        print(f"Iteration {iteration + 1}/{iterations} - Temp: {temperature:.2f}, Mood: {mood['mood']} ({mood['intensity']})")
        
        for agent in agents:
            decision = call_llm_for_decision(agent, persona_data, offers, mood, temperature)
            
            selected_offer_id = decision['selected_offer_id']
            probability = decision['probability']
            
            mood_adjusted_prob = probability * (1 + (mood['factor'] - 0.5) * 0.3)
            mood_adjusted_prob = np.clip(mood_adjusted_prob, 15, 95)
            
            offer_vote_counts[selected_offer_id].append({
                'agent': agent['name'],
                'agent_type': agent['type'],
                'probability': int(mood_adjusted_prob),
                'iteration': iteration + 1,
                'mood': mood['mood'],
                'temperature': temperature
            })
            
            if iteration == 0:
                offer_agent_details[selected_offer_id].append({
                    'agent_id': agent['id'],
                    'agent_name': agent['name'],
                    'agent_type': agent['type'],
                    'probability': int(mood_adjusted_prob),
                    'reasoning': decision['reasoning'],
                    'mood_influence': decision.get('mood_influence', 'N/A'),
                    'decision': 'accept' if mood_adjusted_prob > 65 else ('reject' if mood_adjusted_prob < 35 else 'neutral')
                })
    
    results = []
    
    for offer in offers:
        offer_id = offer['id']
        votes = offer_vote_counts[offer_id]
        
        if len(votes) == 0:
            avg_likelihood = 0
            std_dev = 0
            vote_count = 0
        else:
            probabilities = [v['probability'] for v in votes]
            avg_likelihood = int(np.mean(probabilities))
            std_dev = np.std(probabilities)
            vote_count = len(votes)
        
        confidence = max(60, int(100 - std_dev * 2)) if std_dev > 0 else 60
        
        recommendation = 'highly_recommended' if avg_likelihood >= 75 else (
            'recommended' if avg_likelihood >= 55 else (
                'neutral' if avg_likelihood >= 40 else 'not_recommended'
            )
        )
        
        agent_details = offer_agent_details[offer_id]
        top_agents = sorted(agent_details, key=lambda x: x['probability'], reverse=True)[:2] if agent_details else []
        
        results.append({
            'offer_id': offer_id,
            'offer_title': offer['title'],
            'acceptance_likelihood': avg_likelihood,
            'confidence': confidence,
            'variance': round(std_dev, 1),
            'vote_count': vote_count,
            'agent_results': agent_details,
            'top_influencing_arguments': [a['reasoning'] for a in top_agents],
            'recommendation': recommendation,
            'voting_breakdown': votes
        })
    
    results.sort(key=lambda x: x['acceptance_likelihood'], reverse=True)
    
    return results