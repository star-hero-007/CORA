import json
from openai import OpenAI

client = OpenAI(api_key="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")

def llm_get_churn_driver_and_insights(features_dict, risk_score):
    prompt = f"""Analyze this airline passenger's churn risk and determine the PRIMARY churn driver.

Risk Score: {risk_score}%

Feature Values:
- Booking frequency change: {features_dict['booking_freq_change']:.2f}
- Fare downgrade trend: {features_dict['fare_downgrade_trend']:.2f}
- Booking abandon rate: {features_dict['booking_abandon_rate']:.2f}
- Recent disruptions: {features_dict['recent_disruption_count']:.0f}
- Service issues: {features_dict['recent_service_issues']:.0f}
- Lounge access issues: {features_dict['lounge_access_issues']:.0f}
- App usage drop: {features_dict['app_usage_drop']:.2f}
- Email engagement drop: {features_dict['email_engagement_drop']:.2f}
- Loyalty inactivity days: {features_dict['loyalty_inactivity_days']:.0f}
- Ancillary spend drop: {features_dict['ancillary_spend_drop']:.2f}
- Upgrade acceptance drop: {features_dict['upgrade_acceptance_drop']:.2f}
- Spend per trip decline: {features_dict['spend_per_trip_decline']:.2f}
- Frustration score: {features_dict['frustration_score_llm']:.2f}
- Complaint frequency change: {features_dict['complaint_frequency_change']:.2f}
- Churn intent signal: {features_dict['churn_intent_signal_llm']:.2f}

Determine the PRIMARY churn driver from: "Frequent Delays", "Service Failure", "Price Sensitivity", "Loyalty Neglect", "Route Changes", "Inactivity"

Provide JSON with:
{{
  "churn_driver": "one of the six categories",
  "insight": "brief explanation based on feature analysis",
  "top_contributing_features": ["feature1", "feature2", "feature3"]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline customer retention analyst. Provide ONLY valid JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500
        )
        
        raw_text = response.choices[0].message.content
        
        try:
            result = json.loads(raw_text)
            return result.get('churn_driver', 'Service Failure'), result
        except json.JSONDecodeError:
            start = raw_text.find('{')
            end = raw_text.rfind('}') + 1
            if start != -1 and end > start:
                result = json.loads(raw_text[start:end])
                return result.get('churn_driver', 'Service Failure'), result
            raise ValueError("Invalid JSON from LLM")
    except Exception as e:
        print(f"LLM analysis failed: {e}")
        return get_churn_driver_fallback(features_dict), {
            "churn_driver": get_churn_driver_fallback(features_dict),
            "insight": "Using rule-based analysis",
            "top_contributing_features": []
        }

def get_churn_driver_fallback(features_dict):
    drivers = {
        'Frequent Delays': features_dict.get('recent_disruption_count', 0),
        'Service Failure': features_dict.get('recent_service_issues', 0) + features_dict.get('lounge_access_issues', 0),
        'Price Sensitivity': features_dict.get('fare_downgrade_trend', 0),
        'Loyalty Neglect': features_dict.get('loyalty_inactivity_days', 0) / 100,
        'Route Changes': features_dict.get('booking_abandon_rate', 0),
        'Inactivity': features_dict.get('app_usage_drop', 0) + features_dict.get('email_engagement_drop', 0)
    }
    return max(drivers, key=drivers.get)