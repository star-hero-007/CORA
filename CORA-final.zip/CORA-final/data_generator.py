import random
from datetime import datetime, timedelta

def generate_mock_passenger_data(passenger_id, row, features_dict, churn_driver, llm_insights):
    first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Avery", "Quinn", "Skylar", "Reese",
                   "Cameron", "Blake", "Parker", "Sage", "Dakota", "Phoenix", "River", "Rowan", "Emerson", "Finley"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
                  "Anderson", "Taylor", "Thomas", "Moore", "Jackson", "Martin", "Lee", "Thompson", "White", "Harris"]
    
    random.seed(hash(passenger_id))
    name = f"{random.choice(first_names)} {random.choice(last_names)}"
    
    email = f"{name.lower().replace(' ', '.')}.{passenger_id.lower()}@email.com"
    
    if row['risk_score'] >= 70:
        tier = random.choice(["Platinum", "Gold"])
    elif row['risk_score'] >= 40:
        tier = random.choice(["Gold", "Silver"])
    else:
        tier = random.choice(["Silver", "Bronze"])
    
    tier_ltv = {"Platinum": (50000, 80000), "Gold": (30000, 50000), "Silver": (15000, 30000), "Bronze": (5000, 15000)}
    ltv = random.randint(*tier_ltv[tier])
    
    comm_channel = random.choice(["Email", "WhatsApp", "App"])
    
    tier_flights = {"Platinum": (150, 250), "Gold": (80, 150), "Silver": (30, 80), "Bronze": (10, 30)}
    total_flights = random.randint(*tier_flights[tier])
    
    miles_balance = total_flights * random.randint(800, 1500)
    
    days_ago = random.randint(1, 90)
    last_flight = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
    
    sentiment_score = max(10, min(90, int(100 - row['risk_score'] + random.randint(-15, 15))))
    
    if row['risk_score'] >= 70:
        open_tickets = random.randint(2, 5)
    elif row['risk_score'] >= 40:
        open_tickets = random.randint(0, 2)
    else:
        open_tickets = 0
    
    timeline = generate_timeline(churn_driver, row['risk_score'], days_ago, features_dict, llm_insights)
    
    return {
        "id": passenger_id,
        "name": name,
        "email": email,
        "riskScore": int(row['risk_score']),
        "churnDriver": churn_driver,
        "ltv": ltv,
        "tier": tier,
        "commChannel": comm_channel,
        "lastFlight": last_flight,
        "totalFlights": total_flights,
        "milesBalance": miles_balance,
        "sentimentScore": sentiment_score,
        "openTickets": open_tickets,
        "timeline": timeline,
        "llmInsight": llm_insights.get('insight', ''),
        "topFeatures": llm_insights.get('top_contributing_features', [])
    }

def generate_timeline(churn_driver, risk_score, days_since_last_flight, features_dict, llm_insights):
    timeline = []
    
    last_flight_date = (datetime.now() - timedelta(days=days_since_last_flight)).strftime("%Y-%m-%d")
    
    recent_disruptions = int(features_dict.get('recent_disruption_count', 0))
    service_issues = int(features_dict.get('recent_service_issues', 0))
    inactivity_days = int(features_dict.get('loyalty_inactivity_days', 0))
    
    if churn_driver == "Frequent Delays":
        timeline = [
            {"date": last_flight_date, "event": f"Flight delayed {min(recent_disruptions, 4)} hours", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 15)).strftime("%Y-%m-%d"), 
             "event": "Previous flight delayed 2 hours", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 30)).strftime("%Y-%m-%d"), 
             "event": "Complained about delays", "type": "neg"},
        ]
    elif churn_driver == "Service Failure":
        events = []
        if service_issues > 0:
            events.append({"date": last_flight_date, "event": "Service issue - Request not fulfilled", "type": "neg"})
        if features_dict.get('lounge_access_issues', 0) > 0:
            events.append({"date": (datetime.now() - timedelta(days=days_since_last_flight + 10)).strftime("%Y-%m-%d"), 
                          "event": "Lounge access denied", "type": "neg"})
        events.append({"date": (datetime.now() - timedelta(days=days_since_last_flight + 25)).strftime("%Y-%m-%d"), 
                      "event": "Complaint escalated", "type": "neg"})
        timeline = events
    elif churn_driver == "Loyalty Neglect":
        timeline = [
            {"date": last_flight_date, "event": "Regular flight - No issues", "type": "neu"},
            {"date": (datetime.now() - timedelta(days=max(30, inactivity_days//2))).strftime("%Y-%m-%d"), 
             "event": "Miles expiration notice", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 35)).strftime("%Y-%m-%d"), 
             "event": "Competitor offer received", "type": "neg"},
        ]
    elif churn_driver == "Route Changes":
        timeline = [
            {"date": last_flight_date, "event": "Preferred route discontinued", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 15)).strftime("%Y-%m-%d"), 
             "event": "Had to use connecting flight", "type": "neg"},
        ]
    elif churn_driver == "Inactivity":
        timeline = [
            {"date": last_flight_date, "event": f"Last flight - {days_since_last_flight} days ago", "type": "neu"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 20)).strftime("%Y-%m-%d"), 
             "event": "Ignored promotional email", "type": "neg"},
        ]
    else:
        timeline = [
            {"date": last_flight_date, "event": "Regular flight completed", "type": "neu"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 15)).strftime("%Y-%m-%d"), 
             "event": "Searched for cheaper alternatives", "type": "neg"},
        ]
    
    return timeline