"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import type { Slide, SlideElement } from "@/lib/slides"

interface SlideRendererProps {
  slide: Slide
  direction: number
}

function TypingTitle({ text, delay }: { text: string; delay: number }) {
  const [displayedText, setDisplayedText] = useState("")
  const [isDone, setIsDone] = useState(false)

  useEffect(() => {
    setDisplayedText("")
    setIsDone(false)

    const startTimeout = setTimeout(() => {
      let index = 0
      const interval = setInterval(() => {
        if (index < text.length) {
          setDisplayedText(text.slice(0, index + 1))
          index++
        } else {
          clearInterval(interval)
          setTimeout(() => setIsDone(true), 500)
        }
      }, 80)

      return () => clearInterval(interval)
    }, delay * 1000)

    return () => clearTimeout(startTimeout)
  }, [text, delay])

  return (
    <span className={isDone ? "" : "border-r-2 border-primary"}>
      {displayedText}
      {!isDone && <span className="cursor-blink">_</span>}
    </span>
  )
}

function RiskFeedAnimation() {
  const [activeSource, setActiveSource] = useState(0)
  const sources = ["PSS", "CRM", "CSP", "NDC"]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSource((prev) => (prev + 1) % sources.length)
    }, 1500)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="my-4 p-4 border border-border bg-card/50">
      <div className="text-xs text-muted-foreground mb-3 uppercase">DATA FLOW PIPELINE</div>
      <div className="flex items-center justify-between gap-2 text-xs">
        {/* Data Sources */}
        <div className="flex flex-col gap-1">
          {sources.map((src, i) => (
            <motion.div
              key={src}
              className={`process-block ${activeSource === i ? "active" : ""}`}
              animate={{
                scale: activeSource === i ? 1.05 : 1,
                borderColor: activeSource === i ? "var(--primary)" : "var(--border)",
              }}
            >
              {src}
            </motion.div>
          ))}
        </div>

        {/* Flow Arrow */}
        <div className="flex-1 flex items-center justify-center relative h-16">
          <svg className="w-full h-full" viewBox="0 0 100 40">
            <line x1="0" y1="20" x2="100" y2="20" className="flow-line" strokeDasharray="4,4" />
            <motion.circle
              cx="0"
              cy="20"
              r="4"
              fill="var(--primary)"
              animate={{ cx: [0, 100] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            />
          </svg>
        </div>

        {/* Feature Engineering */}
        <div className="process-block active flex flex-col items-center py-2">
          <span>FEATURE</span>
          <span>ENG + LLM</span>
        </div>

        {/* Flow Arrow */}
        <div className="flex-1 flex items-center justify-center relative h-16">
          <svg className="w-full h-full" viewBox="0 0 100 40">
            <line x1="0" y1="20" x2="100" y2="20" className="flow-line" strokeDasharray="4,4" />
            <motion.circle
              cx="0"
              cy="20"
              r="4"
              fill="var(--secondary)"
              animate={{ cx: [0, 100] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear", delay: 0.5 }}
            />
          </svg>
        </div>

        {/* Churn Model */}
        <div className="process-block active flex flex-col items-center py-2">
          <span>CHURN</span>
          <span>MODEL</span>
        </div>

        {/* Flow Arrow */}
        <div className="flex-1 flex items-center justify-center relative h-16">
          <svg className="w-full h-full" viewBox="0 0 100 40">
            <line x1="0" y1="20" x2="100" y2="20" className="flow-line" strokeDasharray="4,4" />
            <motion.circle
              cx="0"
              cy="20"
              r="4"
              fill="var(--primary)"
              animate={{ cx: [0, 100] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, ease: "linear", delay: 1 }}
            />
          </svg>
        </div>

        {/* Risk Score Output */}
        <div className="flex flex-col gap-1">
          <motion.div
            className="text-primary font-bold"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            RISK: 78%
          </motion.div>
          <div className="text-destructive text-sm font-semibold">HIGH</div>
        </div>
      </div>
    </div>
  )
}

function Customer360Animation() {
  const dataTypes = ["BEHAVIORAL", "ENGAGEMENT", "SENTIMENT"]
  const outputs = ["Missed upgrades", "Competitor interest", "Service friction"]
  const [activeOutput, setActiveOutput] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveOutput((prev) => (prev + 1) % outputs.length)
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="my-4 p-4 border border-border bg-card/50">
      <div className="text-xs text-muted-foreground mb-3 uppercase">REASONING AGENT ANALYSIS</div>
      <div className="flex items-center gap-4">
        {/* Input Data */}
        <div className="flex flex-col gap-2">
          {dataTypes.map((type, i) => (
            <motion.div
              key={type}
              className="process-block text-xs"
              animate={{ borderColor: ["var(--border)", "var(--primary)", "var(--border)"] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: i * 0.3 }}
            >
              {type}
            </motion.div>
          ))}
        </div>

        {/* Neural Network Visualization */}
        <div className="flex-1 flex items-center justify-center">
          <svg width="120" height="80" viewBox="0 0 120 80">
            {/* Input nodes */}
            {[15, 40, 65].map((y, i) => (
              <motion.circle
                key={`in-${i}`}
                cx="10"
                cy={y}
                r="5"
                fill="var(--primary)"
                className="neural-node"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
            {/* Hidden layer */}
            {[20, 40, 60].map((y, i) => (
              <motion.circle
                key={`h-${i}`}
                cx="60"
                cy={y}
                r="6"
                fill="var(--accent)"
                className="neural-node"
                style={{ animationDelay: `${i * 0.3 + 0.5}s` }}
              />
            ))}
            {/* Output node */}
            <motion.circle
              cx="110"
              cy="40"
              r="8"
              fill="var(--secondary)"
              animate={{ scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
            />
            {/* Connections */}
            {[15, 40, 65].map((y1, i) =>
              [20, 40, 60].map((y2, j) => (
                <motion.line
                  key={`l1-${i}-${j}`}
                  x1="15"
                  y1={y1}
                  x2="54"
                  y2={y2}
                  stroke="var(--primary)"
                  strokeWidth="1"
                  opacity="0.3"
                  animate={{ opacity: [0.1, 0.5, 0.1] }}
                  transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: (i + j) * 0.1 }}
                />
              )),
            )}
            {[20, 40, 60].map((y, i) => (
              <motion.line
                key={`l2-${i}`}
                x1="66"
                y1={y}
                x2="102"
                y2="40"
                stroke="var(--accent)"
                strokeWidth="1"
                opacity="0.3"
                animate={{ opacity: [0.1, 0.6, 0.1] }}
                transition={{ duration: 1.2, repeat: Number.POSITIVE_INFINITY, delay: i * 0.2 }}
              />
            ))}
            <text x="60" y="78" textAnchor="middle" fill="var(--muted-foreground)" fontSize="8">
              LLM AGENT
            </text>
          </svg>
        </div>

        {/* Output Insights */}
        <div className="flex flex-col gap-1">
          <div className="text-xs text-muted-foreground mb-1">CHURN DRIVERS:</div>
          {outputs.map((output, i) => (
            <motion.div
              key={output}
              className={`text-xs ${i === activeOutput ? "text-secondary font-semibold" : "text-muted-foreground"}`}
              animate={{ opacity: i === activeOutput ? 1 : 0.4 }}
            >
              {i === activeOutput ? "▶ " : "  "}
              {output}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

function OfferLabAnimation() {
  const offers = [
    { name: "Bonus Miles 5K", match: true },
    { name: "Lounge Pass x2", match: true },
    { name: "Free Baggage", match: false },
    { name: "Upgrade Voucher", match: true },
    { name: "10% Discount", match: false },
    { name: "Priority Board", match: true },
    { name: "Seat Selection", match: false },
    { name: "Status Match", match: true },
  ]
  const [currentOffer, setCurrentOffer] = useState(0)
  const [swipeState, setSwipeState] = useState<"idle" | "match" | "reject">("idle")
  const [matches, setMatches] = useState(0)
  const [rejects, setRejects] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      const offer = offers[currentOffer % offers.length]
      setSwipeState(offer.match ? "match" : "reject")

      setTimeout(() => {
        if (offer.match) setMatches((prev) => prev + 1)
        else setRejects((prev) => prev + 1)
        setSwipeState("idle")
        setCurrentOffer((prev) => (prev + 1) % offers.length)
      }, 600)
    }, 1800)

    return () => clearInterval(interval)
  }, [currentOffer])

  const offer = offers[currentOffer % offers.length]

  return (
    <div className="my-4 p-4 border border-border bg-card/50">
      <div className="text-xs text-muted-foreground mb-3 uppercase">DIGITAL TWIN OFFER MATCHING</div>
      <div className="flex items-center gap-6">
        {/* Digital Twin */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-16 h-16 border-2 border-primary flex items-center justify-center">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
              className="text-2xl"
            >
              👤
            </motion.div>
          </div>
          <div className="text-xs text-primary font-semibold">DIGITAL TWIN</div>
        </div>

        {/* Offer Card with Swipe */}
        <div className="flex-1 flex flex-col items-center relative h-24">
          <motion.div
            className={`absolute p-3 border-2 ${
              swipeState === "match"
                ? "border-primary bg-primary/10"
                : swipeState === "reject"
                  ? "border-destructive bg-destructive/10"
                  : "border-border bg-card"
            }`}
            animate={
              swipeState === "match"
                ? { x: 80, rotate: 10, opacity: 0 }
                : swipeState === "reject"
                  ? { x: -80, rotate: -10, opacity: 0 }
                  : { x: 0, rotate: 0, opacity: 1 }
            }
            transition={{ duration: 0.5 }}
          >
            <div className="text-sm font-bold">{offer.name}</div>
            <div className="text-xs text-muted-foreground">OFFER #{currentOffer + 1}</div>
          </motion.div>

          {/* Match/Reject indicators */}
          <div className="absolute left-0 top-1/2 -translate-y-1/2 text-destructive text-xl font-bold">✗</div>
          <div className="absolute right-0 top-1/2 -translate-y-1/2 text-primary text-xl font-bold">✓</div>
        </div>

        {/* Results Tally */}
        <div className="flex flex-col gap-2">
          <div className="text-xs text-muted-foreground">RESULTS:</div>
          <div className="flex items-center gap-2">
            <span className="text-primary font-bold">✓</span>
            <span className="text-primary font-bold">{matches}</span>
            <span className="text-muted-foreground">matched</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-destructive font-bold">✗</span>
            <span className="text-destructive font-bold">{rejects}</span>
            <span className="text-muted-foreground">rejected</span>
          </div>
        </div>
      </div>
    </div>
  )
}

function SimulationEngineAnimation() {
  return (
    <div className="my-4 p-4 border border-border bg-card/50">
      <div className="text-xs text-muted-foreground mb-3 uppercase">SIMULATING HUMAN UNPREDICTABILITY</div>
      <div className="flex items-center gap-6">
        {/* Animated Brain */}
        <div className="flex flex-col items-center">
          <svg width="100" height="80" viewBox="0 0 100 80">
            {/* Brain outline */}
            <motion.path
              d="M50 10 C20 10 10 30 15 45 C10 55 15 70 35 70 C40 75 60 75 65 70 C85 70 90 55 85 45 C90 30 80 10 50 10"
              fill="none"
              stroke="var(--primary)"
              strokeWidth="2"
              className="brain-region"
            />
            {/* Brain folds */}
            <motion.path
              d="M30 30 Q40 35 50 30 Q60 35 70 30"
              fill="none"
              stroke="var(--primary)"
              strokeWidth="1.5"
              opacity="0.6"
              animate={{ opacity: [0.3, 0.8, 0.3] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: 0.2 }}
            />
            <motion.path
              d="M25 45 Q40 50 50 45 Q60 50 75 45"
              fill="none"
              stroke="var(--primary)"
              strokeWidth="1.5"
              opacity="0.6"
              animate={{ opacity: [0.3, 0.8, 0.3] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: 0.5 }}
            />
            <motion.path
              d="M35 55 Q45 60 55 55 Q65 60 70 55"
              fill="none"
              stroke="var(--primary)"
              strokeWidth="1.5"
              opacity="0.6"
              animate={{ opacity: [0.3, 0.8, 0.3] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, delay: 0.8 }}
            />
            {/* Synapses firing */}
            {[
              { cx: 35, cy: 25 },
              { cx: 55, cy: 35 },
              { cx: 40, cy: 50 },
              { cx: 65, cy: 45 },
              { cx: 45, cy: 60 },
            ].map((pos, i) => (
              <motion.circle
                key={i}
                cx={pos.cx}
                cy={pos.cy}
                r="3"
                fill="var(--secondary)"
                animate={{
                  scale: [0, 1.5, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Number.POSITIVE_INFINITY,
                  delay: i * 0.4,
                }}
              />
            ))}
          </svg>
          <div className="text-xs text-primary mt-1 font-semibold">NEURAL SIM</div>
        </div>

        {/* Components */}
        <div className="flex-1 flex flex-col gap-2">
          <motion.div
            className="process-block active text-xs"
            animate={{ borderColor: ["var(--primary)", "var(--secondary)", "var(--primary)"] }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
          >
            DIGITAL TWIN + BEHAVIORAL DATA
          </motion.div>
          <motion.div
            className="process-block active text-xs"
            animate={{ borderColor: ["var(--primary)", "var(--accent)", "var(--primary)"] }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: 1 }}
          >
            LLM COUNCIL (DEBATE + VOTE)
          </motion.div>
          <motion.div
            className="process-block active text-xs"
            animate={{ borderColor: ["var(--primary)", "var(--secondary)", "var(--primary)"] }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, delay: 2 }}
          >
            MONTE CARLO SIMULATION
          </motion.div>
        </div>

        {/* Output */}
        <div className="flex flex-col items-center gap-1">
          <motion.div
            className="text-lg font-bold text-secondary"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            87%
          </motion.div>
          <div className="text-xs text-muted-foreground text-center">
            ACCEPTANCE
            <br />
            PROBABILITY
          </div>
        </div>
      </div>
    </div>
  )
}

function ImagePlaceholderRow({
  images,
  delay,
}: {
  images: { placeholder: string; imageUrl?: string; imageAlt?: string }[]
  delay: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="my-6 grid grid-cols-3 gap-4"
    >
      {images.map((img, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + i * 0.2, duration: 0.3 }}
          className="aspect-video border border-dashed border-primary/50 flex items-center justify-center bg-primary/5 p-2 overflow-hidden"
        >
          {img.imageUrl ? (
            <img
              src={img.imageUrl}
              alt={img.imageAlt || "Slide image"}
              className="w-full h-full object-cover rounded"
              onLoad={() => console.log("✅ Image loaded:", img.imageUrl)}
              onError={(e) => {
                console.error("❌ Image failed to load:", img.imageUrl)
                e.currentTarget.style.display = "none"
                // Show placeholder text on error
                const parent = e.currentTarget.parentElement
                if (parent) {
                  const fallback = document.createElement("pre")
                  fallback.className = "text-primary/60 text-center text-xs whitespace-pre-line"
                  fallback.textContent = img.placeholder
                  parent.appendChild(fallback)
                }
              }}
            />
          ) : (
            <pre className="text-primary/60 text-center text-xs whitespace-pre-line">{img.placeholder}</pre>
          )}
        </motion.div>
      ))}
    </motion.div>
  )
}

function RoadmapFlow({
  steps,
  delay,
}: { steps: { label: string; description: string; status: "past" | "current" | "future" }[]; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay, duration: 0.4 }}
      className="my-6"
    >
      <div className="relative flex items-stretch gap-0">
        {/* Connection line */}
        <div className="absolute top-8 left-0 right-0 h-1 bg-border z-0" />

        {steps.map((step, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: delay + i * 0.2, duration: 0.3 }}
            className="flex-1 relative z-10"
          >
            {/* Node */}
            <div className="flex flex-col items-center">
              <div
                className={`w-16 h-16 rounded-full flex items-center justify-center border-2 ${
                  step.status === "past"
                    ? "bg-muted border-muted-foreground"
                    : step.status === "current"
                      ? "bg-primary/20 border-primary"
                      : "bg-card border-dashed border-muted-foreground"
                }`}
              >
                {step.status === "past" && <span className="text-muted-foreground text-xl">✓</span>}
                {step.status === "current" && (
                  <motion.span
                    className="text-primary text-xl"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                  >
                    ●
                  </motion.span>
                )}
                {step.status === "future" && <span className="text-muted-foreground text-xl">○</span>}
              </div>

              {/* Arrow */}
              {i < steps.length - 1 && <div className="absolute top-8 -right-2 text-primary z-20">→</div>}

              {/* Label */}
              <div
                className={`mt-3 text-xs font-bold text-center ${
                  step.status === "current" ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {step.label}
              </div>

              {/* Description */}
              <div
                className={`mt-2 text-xs text-center whitespace-pre-line px-2 ${
                  step.status === "current" ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                {step.description}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function QuadrantGrid({
  quadrants,
  delay,
}: { quadrants: { title: string; content: string; icon: string }[]; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay, duration: 0.4 }}
      className="my-6"
    >
      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">CHURN PREDICTION FRAMEWORK</div>
      <div className="grid grid-cols-2 gap-3">
        {quadrants.map((q, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: delay + i * 0.15, duration: 0.3 }}
            className="p-4 border border-border bg-card/50 hover:border-primary transition-colors"
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{q.icon}</span>
              <span className="text-primary font-bold">{q.title}</span>
            </div>
            <div className="text-sm text-muted-foreground">{q.content}</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function SourcesList({
  sources,
  delay,
}: { sources: { title: string; description: string; url: string }[]; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay, duration: 0.4 }}
      className="my-6"
    >
      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">INDUSTRY SOURCES</div>
      <div className="space-y-3">
        {sources.map((src, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: delay + i * 0.15, duration: 0.3 }}
            className="p-3 border border-border bg-card/30"
          >
            <div className="flex items-start gap-2">
              <span className="text-primary">▸</span>
              <div className="flex-1">
                <div className="text-sm font-semibold text-foreground">{src.title}</div>
                <div className="text-xs text-muted-foreground mt-1">{src.description}</div>
                <a
                  href={src.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-accent hover:underline mt-1 inline-block truncate max-w-full"
                >
                  {src.url.length > 60 ? src.url.substring(0, 60) + "..." : src.url}
                </a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function renderElement(element: SlideElement, index: number) {
  const delay = element.delay || 0

  switch (element.type) {
    case "boot-sequence":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.3 }}
          className="space-y-2 text-left"
        >
          <div className="text-xs text-muted-foreground mb-4">BOOTING STAR-OPS SYSTEM...</div>
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.4, duration: 0.3 }}
              className="flex items-center gap-3 text-sm"
            >
              <span className="text-muted-foreground">{item.label}</span>
              <span className="flex-1 text-muted-foreground/30">{"."}</span>
              <span className={item.status === "ok" ? "text-primary font-semibold" : "text-secondary font-semibold"}>
                {item.value}
              </span>
            </motion.div>
          ))}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: delay + (element.items?.length || 0) * 0.4 + 0.3, duration: 0.3 }}
            className="text-primary font-bold mt-4 text-sm"
          >
            ACCESS GRANTED
          </motion.div>
        </motion.div>
      )

    case "ascii-title":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay, duration: 0.5 }}
          className="text-center my-6"
        >
          <h1 className="text-5xl md:text-7xl font-bold text-primary tracking-widest">
            <TypingTitle text={element.content || ""} delay={delay} />
          </h1>
        </motion.div>
      )

    case "command":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.3 }}
          className="mb-4"
        >
          <span className="text-primary font-semibold">{element.command}</span>
          <span className="cursor-blink text-primary">█</span>
        </motion.div>
      )

    case "output":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay, duration: 0.4 }}
          className="text-muted-foreground whitespace-pre-line leading-relaxed text-base md:text-lg"
        >
          {element.content}
        </motion.div>
      )

    case "alert":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.3 }}
          className="my-4 p-4 border border-destructive bg-destructive/10"
        >
          <pre className="text-destructive whitespace-pre-line text-sm md:text-base font-bold">{element.content}</pre>
        </motion.div>
      )

    case "telemetry":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 space-y-3"
        >
          {element.content && (
            <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">{element.content}</div>
          )}
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.15, duration: 0.3 }}
              className="flex items-center gap-4"
            >
              <span
                className={`text-sm w-28 font-semibold ${
                  item.status === "ok"
                    ? "text-primary"
                    : item.status === "warn"
                      ? "text-secondary"
                      : item.status === "error"
                        ? "text-destructive"
                        : "text-accent"
                }`}
              >
                {item.label}
              </span>
              <span
                className={`font-mono text-sm ${
                  item.status === "ok"
                    ? "text-primary"
                    : item.status === "warn"
                      ? "text-secondary"
                      : item.status === "error"
                        ? "text-destructive"
                        : "text-accent"
                }`}
              >
                {item.value}
              </span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "system-status":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-4 space-y-2"
        >
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: delay + i * 0.1, duration: 0.3 }}
              className="flex items-start gap-3 text-sm md:text-base"
            >
              <span
                className={`font-bold ${
                  item.status === "ok"
                    ? "text-primary"
                    : item.status === "warn"
                      ? "text-secondary"
                      : item.status === "error"
                        ? "text-destructive"
                        : "text-accent"
                }`}
              >
                {item.status === "ok"
                  ? "[✓]"
                  : item.status === "warn"
                    ? "[!]"
                    : item.status === "error"
                      ? "[✗]"
                      : "[i]"}
              </span>
              <span className="text-muted-foreground">{item.label}:</span>
              <span className="text-foreground">{item.value}</span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "module-grid":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          {element.modules?.map((mod, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: delay + i * 0.15, duration: 0.3 }}
              className="p-4 border border-border hover:border-primary transition-colors pulse-glow"
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-primary font-bold">{mod.name}</span>
                <span
                  className={`text-xs px-2 py-0.5 ${
                    mod.status === "ACTIVE"
                      ? "bg-primary/20 text-primary"
                      : mod.status === "HIGH"
                        ? "bg-primary/20 text-primary"
                        : "bg-muted text-muted-foreground"
                  }`}
                >
                  {mod.status}
                </span>
              </div>
              <div className="text-xs text-muted-foreground mb-1">{mod.path}</div>
              <div className="text-sm text-foreground">{mod.description}</div>
            </motion.div>
          ))}
        </motion.div>
      )

    case "comparison-terminal":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          {element.columns?.map((col, i) => (
            <div key={i} className={`p-4 border ${col.highlight ? "border-primary bg-primary/5" : "border-border"}`}>
              <div className={`text-sm font-bold mb-3 ${col.highlight ? "text-primary" : "text-muted-foreground"}`}>
                {col.title}
              </div>
              <ul className="space-y-2">
                {col.items.map((item, j) => (
                  <li key={j} className="flex items-start gap-2 text-sm">
                    <span className={col.highlight ? "text-primary" : "text-muted-foreground"}>▸</span>
                    <span className={col.highlight ? "text-foreground" : "text-muted-foreground"}>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </motion.div>
      )

    case "table-terminal":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 overflow-x-auto"
        >
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-primary">
                {element.tableHeaders?.map((header, i) => (
                  <th key={i} className="text-left py-2 px-3 text-primary font-bold">
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {element.tableRows?.map((row, i) => (
                <tr key={i} className="border-b border-border">
                  {row.cells.map((cell, j) => (
                    <td
                      key={j}
                      className={`py-2 px-3 ${j === 0 ? "text-accent font-semibold" : "text-muted-foreground"}`}
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )

    case "kpi-readout":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 space-y-2"
        >
          {element.kpis?.map((kpi, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.1, duration: 0.3 }}
              className="flex items-center gap-4 text-sm border-b border-border py-2"
            >
              <span className="text-primary w-32 font-semibold">{kpi.component}</span>
              <span className="text-foreground flex-1">{kpi.kpi}</span>
              <span className="text-muted-foreground">{kpi.value}</span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "progress-list":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-4 space-y-2"
        >
          {element.items?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + i * 0.15, duration: 0.3 }}
              className="flex items-center gap-3 text-sm md:text-base"
            >
              <span
                className={`text-xs px-2 py-0.5 font-semibold ${
                  item.status === "ok" || item.status === "info"
                    ? "bg-primary/20 text-primary"
                    : item.status === "warn"
                      ? "bg-secondary/20 text-secondary"
                      : "bg-destructive/20 text-destructive"
                }`}
              >
                {item.value}
              </span>
              <span className="text-muted-foreground">{item.label}</span>
            </motion.div>
          ))}
        </motion.div>
      )

    case "quote-terminal":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-4 p-4 border-l-2 border-accent bg-accent/5"
        >
          <pre className="text-accent whitespace-pre-line text-sm md:text-base font-semibold">{element.content}</pre>
        </motion.div>
      )

    case "image-placeholder":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 w-full max-w-2xl mx-auto aspect-video border border-dashed border-primary/50 flex items-center justify-center bg-primary/5 overflow-hidden"
        >
          {element.imageUrl ? (
            <img
              src={element.imageUrl}
              alt={element.imageAlt || "Slide image"}
              className="w-full h-full object-contain"
              onLoad={() => console.log("✅ Image loaded:", element.imageUrl)}
              onError={(e) => {
                console.error("❌ Image failed to load:", element.imageUrl)
                console.error("Full URL:", e.currentTarget.src)
                e.currentTarget.style.display = "none"
                // Show placeholder text on error
                const parent = e.currentTarget.parentElement
                if (parent) {
                  const fallback = document.createElement("pre")
                  fallback.className = "text-primary/60 text-center text-sm whitespace-pre-line p-4"
                  fallback.textContent = element.content || "Image failed to load"
                  parent.appendChild(fallback)
                }
              }}
            />
          ) : (
            <pre className="text-primary/60 text-center text-sm whitespace-pre-line">{element.content}</pre>
          )}
        </motion.div>
      )

    case "clean-image":
      return (
        <motion.div
          key={index}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay, duration: 0.4 }}
          className="my-6 w-full max-w-3xl mx-auto"
        >
          <div className="aspect-video border border-border flex items-center justify-center bg-background overflow-hidden">
            {element.imageUrl ? (
              <img
                src={element.imageUrl}
                alt={element.imageAlt || "Architecture diagram"}
                className="w-full h-full object-contain"
                onLoad={() => console.log("✅ Image loaded:", element.imageUrl)}
                onError={(e) => {
                  console.error("❌ Image failed to load:", element.imageUrl)
                  console.error("Full URL:", e.currentTarget.src)
                  e.currentTarget.style.display = "none"
                  // Show placeholder text on error
                  const parent = e.currentTarget.parentElement
                  if (parent) {
                    const fallback = document.createElement("pre")
                    fallback.className = "text-muted-foreground text-center text-sm whitespace-pre-line p-4"
                    fallback.textContent = element.content || "Image failed to load"
                    parent.appendChild(fallback)
                  }
                }}
              />
            ) : (
              <pre className="text-muted-foreground text-center text-sm whitespace-pre-line">{element.content}</pre>
            )}
          </div>
        </motion.div>
      )

    case "image-placeholder-row":
      return element.images ? <ImagePlaceholderRow key={index} images={element.images} delay={delay} /> : null

    case "roadmap-flow":
      return element.roadmapSteps ? <RoadmapFlow key={index} steps={element.roadmapSteps} delay={delay} /> : null

    case "quadrant-grid":
      return element.quadrants ? <QuadrantGrid key={index} quadrants={element.quadrants} delay={delay} /> : null

    case "sources-list":
      return element.sources ? <SourcesList key={index} sources={element.sources} delay={delay} /> : null

    case "risk-feed-animation":
      return (
        <motion.div key={index} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay, duration: 0.4 }}>
          <RiskFeedAnimation />
        </motion.div>
      )

    case "customer-360-animation":
      return (
        <motion.div key={index} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay, duration: 0.4 }}>
          <Customer360Animation />
        </motion.div>
      )

    case "offer-lab-animation":
      return (
        <motion.div key={index} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay, duration: 0.4 }}>
          <OfferLabAnimation />
        </motion.div>
      )

    case "simulation-engine-animation":
      return (
        <motion.div key={index} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay, duration: 0.4 }}>
          <SimulationEngineAnimation />
        </motion.div>
      )

    default:
      return null
  }
}

export default function SlideRenderer({ slide }: SlideRendererProps) {
  const layoutClasses = {
    default: "items-start justify-start text-left",
    title: "items-center justify-center text-center",
    centered: "items-center justify-center text-center",
    "two-column": "items-start justify-start text-left",
    command: "items-start justify-start text-left",
  }

  return (
    <motion.div
      className={`absolute inset-0 flex flex-col p-6 md:p-10 overflow-y-auto ${layoutClasses[slide.layout || "default"]}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className={`w-full ${slide.layout === "title" || slide.layout === "centered" ? "max-w-3xl" : "max-w-5xl"}`}>
        {slide.elements.map((element, index) => renderElement(element, index))}
      </div>
    </motion.div>
  )
}