import Presentation from "@/components/presentation"

export default function Home() {
  return (
    <main className="min-h-screen bg-background overflow-hidden">
      <Presentation />
    </main>
  )
}
