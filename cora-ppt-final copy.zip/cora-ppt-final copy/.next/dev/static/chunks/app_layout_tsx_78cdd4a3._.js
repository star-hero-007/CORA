(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__1bc92fad._.css",
  "static/chunks/node_modules_901137b7._.js"
],
    source: "dynamic"
});
