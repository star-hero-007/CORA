export type SlideLayout = "default" | "title" | "centered" | "two-column" | "command"

export interface SlideElement {
  type:
    | "ascii-title"
    | "command"
    | "output"
    | "telemetry"
    | "radar"
    | "system-status"
    | "module-grid"
    | "comparison-terminal"
    | "table-terminal"
    | "alert"
    | "quote-terminal"
    | "progress-list"
    | "kpi-readout"
    | "boot-sequence"
    | "image-placeholder"
    | "risk-feed-animation"
    | "customer-360-animation"
    | "offer-lab-animation"
    | "simulation-engine-animation"
    | "image-placeholder-row"
    | "roadmap-flow"
    | "quadrant-grid"
    | "sources-list"
    | "clean-image"
  content?: string
  command?: string
  imageUrl?: string  // Added for image URLs
  imageAlt?: string  // Added for accessibility
  items?: { label: string; value: string; status?: "ok" | "warn" | "error" | "info" }[]
  modules?: { name: string; path: string; status: string; description: string }[]
  columns?: { title: string; items: string[]; highlight?: boolean }[]
  tableHeaders?: string[]
  tableRows?: { cells: string[] }[]
  kpis?: { component: string; kpi: string; value: string }[]
  delay?: number
  images?: { placeholder: string; imageUrl?: string; imageAlt?: string }[]  // Updated
  roadmapSteps?: { label: string; description: string; status: "past" | "current" | "future" }[]
  quadrants?: { title: string; content: string; icon: string }[]
  sources?: { title: string; description: string; url: string }[]
}

export interface Slide {
  id: number
  layout?: SlideLayout
  command?: string
  elements: SlideElement[]
}

export const slides: Slide[] = [
  // Slide 1 - Boot Sequence
  {
    id: 1,
    layout: "title",
    command: "boot --system cora",
    elements: [
      {
        type: "boot-sequence",
        items: [
          { label: "Initializing kernel", value: "OK", status: "ok" },
          { label: "Loading ML modules", value: "OK", status: "ok" },
          { label: "Connecting to CRM", value: "OK", status: "ok" },
          { label: "Starting RAG engine", value: "OK", status: "ok" },
          { label: "Team: StarOverflow", value: "LOADED", status: "ok" },
          { label: "Launching cockpit UI", value: "OK", status: "ok" },
        ],
        delay: 0,
      },
      {
        type: "ascii-title",
        content: "CoRA",
        delay: 3.0,
      },
      {
        type: "output",
        content: "CustOmer Retention Agent\nTurning Airline Churn Prevention Into a Proactive Intelligence System",
        delay: 3.7,
      },
    ],
  },
  // Slide 2 - Meme Placeholder
  {
    id: 2,
    layout: "centered",
    command: "load meme --tactical",
    elements: [
      {
        type: "command",
        command: "> load tactical_meme.png",
        delay: 0,
      },
      {
        type: "image-placeholder",
        content: "[ TACTICAL MEME LOADING... ]",
        imageUrl: "/images/1000147937.jpg", 
        imageAlt: "Tactical meme about churn prevention",
        delay: 0.5,
      },
    ],
  },
  {
    id: 3,
    command: "analyze --churn-pattern",
    elements: [
      {
        type: "command",
        command: "> analyze passenger_churn --mode=behavioral",
        delay: 0,
      },
      {
        type: "alert",
        content: "!! INSIGHT ALERT !!\nAirlines treat churn as an EVENT... but it's a PROCESS",
        delay: 0.3,
      },
      {
        type: "telemetry",
        content: "CHURN PROGRESSION DETECTED",
        items: [
          { label: "NORMAL", value: "██████████████░░░░░░", status: "ok" },
          { label: "DRIFT", value: "████████░░░░░░░░░░░░", status: "warn" },
          { label: "CHURN", value: "████░░░░░░░░░░░░░░░░", status: "error" },
        ],
        delay: 0.8,
      },
      {
        type: "image-placeholder-row",
        images: [
          { 
            placeholder: "NORMAL STATE\n[Engaged Customer]",
            imageUrl: "/images/baggage_lost.jpeg", // ADD YOUR IMAGE PATH HERE
            imageAlt: "Normal engaged customer state"
          },
          { 
            placeholder: "DRIFT SIGNALS\n[Early Warning]",
            imageUrl: "/images/flight_disruption_image.jpeg", // ADD YOUR IMAGE PATH HERE
            imageAlt: "Customer drift warning signals"
          },
          { 
            placeholder: "CHURN EVENT\n[Lost Customer]",
            imageUrl: "/images/frustrated_pass.jpg", // ADD YOUR IMAGE PATH HERE
            imageAlt: "Customer churn event"
          },
        ],
        delay: 1.2,
      },
    ],
  },
  {
    id: 4,
    layout: "default",
    command: "compare --models static dynamic",
    elements: [
      {
        type: "command",
        command: "> diff /models/static /models/dynamic --roadmap",
        delay: 0,
      },
      {
        type: "output",
        content: "EVOLUTION: STATIC → DYNAMIC CHURN MODELING",
        delay: 0.3,
      },
      {
        type: "roadmap-flow",
        roadmapSteps: [
          {
            label: "STATIC MODEL",
            description:
              "Historical flights, tier, demographics\nBackward-looking snapshots\nToo slow for early detection",
            status: "past",
          },
          {
            label: "HYBRID APPROACH",
            description: "Adding behavioral features\nBasic drift detection\nImproved but limited",
            status: "past",
          },
          {
            label: "DYNAMIC MODEL (CoRA)",
            description:
              "Behavioral drift + emotional signals\nReal-time baseline deviation\nDetects churn 15-40 days earlier",
            status: "current",
          },
          {
            label: "FUTURE STATE",
            description: "Autonomous retention agents\nPredictive offer optimization\nFull lifecycle management",
            status: "future",
          },
        ],
        delay: 0.5,
      },
      {
        type: "alert",
        content: "!! INDUSTRY INSIGHTS !!\nAcross telecom, banking, and travel sectors:",
        delay: 1.0,
      },
      {
        type: "system-status",
        items: [
          { label: "Churn behavior begins", value: "30-90 days before final churn", status: "warn" },
          { label: "Dynamic drift features", value: "Detect 15-40 days earlier than static", status: "ok" },
          { label: "Early interventions", value: "Increase retention by 20-35%", status: "ok" },
          { label: "Emotional drift", value: "Appears earlier than behavioral drift", status: "info" },
        ],
        delay: 1.3,
      },
    ],
  },
  {
    id: 5,
    command: "list --modules core",
    elements: [
      {
        type: "command",
        command: "> ls /cora/modules --core",
        delay: 0,
      },
      {
        type: "output",
        content: "FOUNDATIONAL MODULES DETECTED: 4",
        delay: 0.3,
      },
      {
        type: "module-grid",
        modules: [
          { name: "RISK_FEED", path: "/modules/risk_feed", status: "ACTIVE", description: "WHO is likely to churn" },
          { name: "CUST_360", path: "/modules/customer_360", status: "ACTIVE", description: "WHY churn happens" },
          { name: "OFFER_LAB", path: "/modules/offer_lab", status: "ACTIVE", description: "WHAT intervention fits" },
          { name: "SIM_ENGINE", path: "/modules/simulation", status: "ACTIVE", description: "HOW they may react" },
        ],
        delay: 0.5,
      },
      {
        type: "quadrant-grid",
        quadrants: [
          { title: "WHO", content: "Identify at-risk passengers using ML-driven risk scoring", icon: "👤" },
          { title: "WHY", content: "Understand churn drivers through LLM-powered analysis", icon: "🔍" },
          { title: "WHAT", content: "Match personalized offers via digital twin simulation", icon: "🎯" },
          { title: "WHEN", content: "Act early with real-time behavioral drift detection", icon: "⏱" },
        ],
        delay: 1.0,
      },
    ],
  },
  {
    id: 6,
    layout: "centered",
    command: "show --architecture",
    elements: [
      {
        type: "command",
        command: "> cat /docs/architecture.diagram",
        delay: 0,
      },
      {
        type: "clean-image",
        content: "[ SYSTEM ARCHITECTURE DIAGRAM ]\n\nUpload your diagram here",
        imageUrl: "/images/1000147914.jpg", // ADD YOUR IMAGE PATH HERE
        imageAlt: "CoRA system architecture diagram",
        delay: 0.4,
      },
    ],
  },
  // Slide 7 - Risk Feed with Animation
  {
    id: 7,
    command: "open module --risk_feed",
    elements: [
      {
        type: "command",
        command: "> open /modules/risk_feed --describe",
        delay: 0,
      },
      {
        type: "ascii-title",
        content: "RISK_FEED",
        delay: 0.3,
      },
      {
        type: "output",
        content: "MODULE: Early Risk Detection System",
        delay: 0.5,
      },
      {
        type: "risk-feed-animation",
        delay: 0.7,
      },
      {
        type: "system-status",
        items: [
          { label: "Behavioral monitoring", value: "CONTINUOUS", status: "ok" },
          { label: "ML engine", value: "XGBoost + SHAP analysis", status: "ok" },
          { label: "Risk score update", value: "DAILY / EVENT-TRIGGERED", status: "ok" },
        ],
        delay: 1.5,
      },
    ],
  },
  // Slide 8 - Customer 360 with Animation
  {
    id: 8,
    command: "open module --customer_360",
    elements: [
      {
        type: "command",
        command: "> open /modules/customer_360 --describe",
        delay: 0,
      },
      {
        type: "ascii-title",
        content: "CUST_360",
        delay: 0.3,
      },
      {
        type: "output",
        content: "MODULE: Churn Driver Analysis with Reasoning Agent",
        delay: 0.5,
      },
      {
        type: "customer-360-animation",
        delay: 0.7,
      },
      {
        type: "system-status",
        items: [
          { label: "LLM summarization", value: "Customer interactions parsed", status: "ok" },
          { label: "Friction detection", value: "Churn drivers highlighted", status: "warn" },
        ],
        delay: 1.8,
      },
    ],
  },
  // Slide 9 - Offer Lab with Animation
  {
    id: 9,
    command: "open module --offer_lab",
    elements: [
      {
        type: "command",
        command: "> open /modules/offer_lab --describe",
        delay: 0,
      },
      {
        type: "ascii-title",
        content: "OFFER_LAB",
        delay: 0.3,
      },
      {
        type: "output",
        content: "MODULE: Personalized Intervention Engine",
        delay: 0.5,
      },
      {
        type: "offer-lab-animation",
        delay: 0.7,
      },
      {
        type: "system-status",
        items: [
          { label: "Digital Twin", value: "Behavioral clone generated", status: "ok" },
          { label: "Offer shortlist", value: "Top interventions ranked", status: "ok" },
        ],
        delay: 2.0,
      },
    ],
  },
  // Slide 10 - Simulation Engine with Brain Animation
  {
    id: 10,
    command: "run simulation --offer_test",
    elements: [
      {
        type: "command",
        command: "> run /modules/simulation --monte-carlo",
        delay: 0,
      },
      {
        type: "ascii-title",
        content: "SIM_ENGINE",
        delay: 0.3,
      },
      {
        type: "output",
        content: "MODULE: Human Behavior Stress Testing",
        delay: 0.5,
      },
      {
        type: "alert",
        content: "!! KEY INSIGHT !!\nOptimal offer on paper ≠ what humans actually choose",
        delay: 0.7,
      },
      {
        type: "simulation-engine-animation",
        delay: 1.0,
      },
      {
        type: "quote-terminal",
        content:
          "CORE: Digital Twin + Council of LLMs + Monte Carlo\n> Can this offer withstand human unpredictability?",
        delay: 2.0,
      },
    ],
  },
  {
    id: 11,
    command: "show roadmap --phases",
    elements: [
      {
        type: "command",
        command: "> cat /docs/roadmap.md",
        delay: 0,
      },
      {
        type: "output",
        content: "CoRA DEPLOYMENT ROADMAP",
        delay: 0.3,
      },
      {
        type: "table-terminal",
        tableHeaders: ["PHASE", "DELIVERABLES"],
        tableRows: [
          { cells: ["PHASE_1", "MVP churn model, SHAP analysis, basic offer engine"] },
          { cells: ["PHASE_2", "Dynamic offer matching, persona engine, simulation"] },
          { cells: ["PHASE_3", "Multi-market deploy, autonomous housekeeping agent"] },
        ],
        delay: 0.5,
      },
      {
        type: "telemetry",
        content: "PROGRESS",
        items: [
          { label: "PHASE_1", value: "████████████████████ 100%", status: "ok" },
          { label: "PHASE_2", value: "████████████░░░░░░░░  60%", status: "warn" },
          { label: "PHASE_3", value: "░░░░░░░░░░░░░░░░░░░░   0%", status: "info" },
        ],
        delay: 0.9,
      },
      {
        type: "quote-terminal",
        content:
          "⚡ ARCHITECTURE NOTE: Loosely coupled system design\n→ Each component can be deployed and scaled independently\n→ No tight dependencies between modules\n→ Enables phased rollout without system-wide changes",
        delay: 1.3,
      },
    ],
  },
  // Slide 12 - Challenges
  {
    id: 12,
    command: "list --risks",
    elements: [
      {
        type: "command",
        command: "> cat /docs/risk_matrix.md",
        delay: 0,
      },
      {
        type: "output",
        content: "KEY CHALLENGES & MITIGATION",
        delay: 0.3,
      },
      {
        type: "table-terminal",
        tableHeaders: ["RISK", "MITIGATION"],
        tableRows: [
          { cells: ["Model degradation", "Drift detection + fallback models"] },
          { cells: ["LLM variability", "Guardrails + SME review loops"] },
          { cells: ["Legacy integration", "Decoupled real-time architecture"] },
          { cells: ["Fairness/compliance", "Fairness audits + transparency"] },
          { cells: ["LLM cost/latency", "Distillation, caching, batching"] },
        ],
        delay: 0.5,
      },
    ],
  },
  // Slide 13 - Quantitative Impact
  {
    id: 13,
    command: "report --impact quantitative",
    elements: [
      {
        type: "command",
        command: "> generate_report --type=quantitative",
        delay: 0,
      },
      {
        type: "output",
        content: "QUANTITATIVE IMPACT (INDUSTRY BENCHMARKS)",
        delay: 0.3,
      },
      {
        type: "telemetry",
        content: "PROJECTED METRICS",
        items: [
          { label: "Churn Reduction", value: "████████████████░░░░ ~20%", status: "ok" },
          { label: "Conversion Uplift", value: "██████████████████░░ 50%+", status: "ok" },
          { label: "Engagement (CTR)", value: "████████████████████ 158%", status: "ok" },
          { label: "Ops Productivity", value: "████████████████░░░░ 30-50%", status: "ok" },
        ],
        delay: 0.5,
      },
      {
        type: "sources-list",
        sources: [
          {
            title: "Churn Rate Drop",
            description: "Reduced monthly churn by ~20% within 6 months",
            url: "https://s3-eu-west-1.amazonaws.com/landingi-editor-uploads/ckbMOiif/SaaS_Manager_case_study.pdf",
          },
          {
            title: "Conversion & Engagement Uplift",
            description: "Personalization engine can lift conversion-to-purchase by 50% and email CTR by 158%",
            url: "https://www.sitecore.com/solutions/customers/airlines/low-cost-airline-lands-10-million-visitors",
          },
          {
            title: "Operational Efficiency Gains",
            description: "Intelligent automation boosts overall productivity by 30-50%",
            url: "https://masterofcode.com/blog/generative-ai-in-travel",
          },
        ],
        delay: 1.0,
      },
    ],
  },
  // Slide 14 - Qualitative Impact
  {
    id: 14,
    command: "report --impact qualitative",
    elements: [
      {
        type: "command",
        command: "> generate_report --type=qualitative",
        delay: 0,
      },
      {
        type: "output",
        content: "QUALITATIVE BUSINESS IMPACT",
        delay: 0.3,
      },
      {
        type: "module-grid",
        modules: [
          {
            name: "BETTER_CX",
            path: "/impact/cx",
            status: "HIGH",
            description: "Relevant, timely, personalized experiences",
          },
          {
            name: "PROACTIVE",
            path: "/impact/retention",
            status: "HIGH",
            description: "Prevention > reactive firefighting",
          },
          { name: "FASTER_OPS", path: "/impact/ops", status: "HIGH", description: "Data-driven marketing operations" },
          {
            name: "VISIBILITY",
            path: "/impact/insights",
            status: "HIGH",
            description: "Deep behavioral change insight",
          },
        ],
        delay: 0.5,
      },
    ],
  },
  // Slide 15 - KPIs
  {
    id: 15,
    command: "show kpis --all",
    elements: [
      {
        type: "command",
        command: "> cat /metrics/kpis.json | format",
        delay: 0,
      },
      {
        type: "output",
        content: "SUCCESS METRICS DASHBOARD",
        delay: 0.3,
      },
      {
        type: "kpi-readout",
        kpis: [
          { component: "Dynamic ML", kpi: "AUC Improvement", value: "vs static" },
          { component: "Churn Drivers", kpi: "Interpretability", value: "SME validated" },
          { component: "Offer Engine", kpi: "Acceptance Uplift", value: "% vs baseline" },
          { component: "Persona Engine", kpi: "Targeting Efficiency", value: "conversion %" },
          { component: "Simulation", kpi: "Forecast Accuracy", value: "vs outcomes" },
          { component: "Feedback Loop", kpi: "Drift Reduction", value: "post-retrain" },
        ],
        delay: 0.5,
      },
    ],
  },
  // Slide 16 - Closing
  {
    id: 16,
    layout: "centered",
    command: "exit --message",
    elements: [
      {
        type: "command",
        command: "> echo $CLOSING_MESSAGE",
        delay: 0,
      },
      {
        type: "output",
        content:
          "Airlines don't lose customers at the moment they leave...\nThey lose them when they miss the early signs.",
        delay: 0.5,
      },
      {
        type: "ascii-title",
        content: "CoRA",
        delay: 1.5,
      },
      {
        type: "output",
        content: "Not a churn model.\nA Retention Intelligence Platform.",
        delay: 2.2,
      },
      {
        type: "quote-terminal",
        content:
          "A multi-agent system built to detect signals early,\nact intelligently, and learn continuously.\n\n[ SESSION COMPLETE ]",
        delay: 2.8,
      },
    ],
  },
]