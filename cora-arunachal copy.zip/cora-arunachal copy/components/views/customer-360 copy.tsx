"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Plane,
  CreditCard,
  Clock,
  CheckCircle,
  XCircle,
  Mail,
  MessageCircle,
  Smartphone,
  TrendingDown,
  Sparkles,
  Brain,
  Loader2,
  Terminal,
  Scan,
  Database,
  Activity,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { Passenger } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

interface Customer360Props {
  passenger: Passenger | null
  onShortlistOffers: (passenger: Passenger) => void
}

const channelIcons = {
  Email: Mail,
  WhatsApp: MessageCircle,
  App: Smartphone,
}

const eventIcons = {
  neg: XCircle,
  pos: CheckCircle,
  neu: Clock,
}

const eventColors = {
  neg: "text-destructive border-destructive/30 bg-destructive/10",
  pos: "text-chart-4 border-chart-4/30 bg-chart-4/10",
  neu: "text-muted-foreground border-border bg-muted/30",
}

function SkeletonLoader() {
  const [loadingStep, setLoadingStep] = useState(0)
  const steps = [
    "Initializing analysis engine...",
    "Loading travel history...",
    "Processing sentiment data...",
    "Analyzing churn patterns...",
    "Generating insights...",
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setLoadingStep((prev) => (prev + 1) % steps.length)
    }, 400)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <div className="w-14 h-14 rounded bg-primary/10 border border-primary/30 animate-pulse flex items-center justify-center">
          <Scan className="w-6 h-6 text-primary animate-pulse" />
        </div>
        <div className="space-y-2">
          <div className="h-5 w-48 bg-muted rounded animate-pulse" />
          <div className="h-3 w-32 bg-muted rounded animate-pulse" />
        </div>
      </div>

      <div className="p-4 rounded border border-primary/30 bg-primary/5 corner-brackets">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Loader2 className="w-5 h-5 text-primary animate-spin" />
            <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-mono text-primary">
              <span className="text-muted-foreground">$</span> agent.analyze(passenger)
            </p>
            <p className="text-xs text-muted-foreground font-mono mt-1">
              {steps[loadingStep]}
              <span className="cursor-blink">_</span>
            </p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-4 gap-2">
          {["Profile", "History", "Sentiment", "Patterns"].map((step, i) => (
            <div
              key={step}
              className={cn(
                "text-center p-2 rounded border text-[10px] font-mono transition-all",
                loadingStep >= i
                  ? "border-primary/50 bg-primary/10 text-primary"
                  : "border-border bg-muted/30 text-muted-foreground",
              )}
            >
              {step}
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="h-24 bg-muted/30 rounded border border-border animate-pulse" />
        ))}
      </div>
    </div>
  )
}

function EmptyState() {
  const [cursorVisible, setCursorVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setCursorVisible((prev) => !prev)
    }, 530)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="p-6 flex flex-col items-center justify-center h-full min-h-[600px]">
      <div className="w-full max-w-lg">
        {/* Terminal window */}
        <div className="rounded-lg border border-border bg-card overflow-hidden corner-brackets">
          {/* Terminal header */}
          <div className="px-4 py-2 bg-muted/50 border-b border-border flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-destructive/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-accent/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-chart-4/60" />
            </div>
            <span className="text-[10px] font-mono text-muted-foreground ml-2">customer_360.exe</span>
          </div>

          {/* Terminal content */}
          <div className="p-6 font-mono text-sm space-y-3">
            <div className="flex items-center gap-2 text-muted-foreground">
              <span className="text-primary">CORA</span>
              <span>::</span>
              <span className="text-chart-4">customer_360</span>
              <span className="text-muted-foreground/50">$</span>
            </div>

            <div className="text-foreground">
              <span className="text-accent">await</span> passenger.select()
            </div>

            <div className="flex items-start gap-2 text-destructive mt-4">
              <span>[!]</span>
              <span>No passenger selected</span>
            </div>

            <div className="text-foreground mt-2">
              Navigate to <span className="text-primary">Risk Feed</span> to select a passenger
              <span className={cn("ml-1", cursorVisible ? "opacity-100" : "opacity-0")}>_</span>
            </div>

            <div className="mt-6 pt-4 border-t border-border">
              <div className="text-[10px] text-muted-foreground space-y-1">
                <div>// Available commands:</div>
                <div className="text-primary"> risk-feed - View at-risk passengers</div>
                <div className="text-primary"> analyze - Deep dive analysis</div>
                <div className="text-primary"> shortlist - Generate retention offers</div>
              </div>
            </div>
          </div>
        </div>

        {/* Quick stats */}
        <div className="mt-6 grid grid-cols-3 gap-3">
          <div className="p-3 rounded border border-border bg-card/50 text-center">
            <Database className="w-4 h-4 mx-auto text-primary mb-1" />
            <div className="text-lg font-bold font-mono text-foreground">6</div>
            <div className="text-[10px] text-muted-foreground">Passengers</div>
          </div>
          <div className="p-3 rounded border border-border bg-card/50 text-center">
            <Activity className="w-4 h-4 mx-auto text-destructive mb-1" />
            <div className="text-lg font-bold font-mono text-destructive">3</div>
            <div className="text-[10px] text-muted-foreground">High Risk</div>
          </div>
          <div className="p-3 rounded border border-border bg-card/50 text-center">
            <Brain className="w-4 h-4 mx-auto text-chart-4 mb-1" />
            <div className="text-lg font-bold font-mono text-chart-4">Ready</div>
            <div className="text-[10px] text-muted-foreground">AI Agent</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export function Customer360({ passenger, onShortlistOffers }: Customer360Props) {
  const [isLoading, setIsLoading] = useState(true)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    if (passenger) {
      setIsLoading(true)
      setShowContent(false)
      const timer = setTimeout(() => {
        setIsLoading(false)
        setTimeout(() => setShowContent(true), 100)
      }, 2000)
      return () => clearTimeout(timer)
    }
  }, [passenger])

  if (!passenger) {
    return <EmptyState />
  }

  if (isLoading) {
    return <SkeletonLoader />
  }

  const ChannelIcon = channelIcons[passenger.commChannel]

  const churnInsights = [
    {
      factor: "Flight Disruptions",
      impact: "High",
      detail: `${passenger.timeline.filter((t) => t.type === "neg" && t.event.includes("delay")).length} delays in last 90 days`,
    },
    {
      factor: "Sentiment Score",
      impact: passenger.sentimentScore < 40 ? "High" : "Medium",
      detail: `${passenger.sentimentScore}% satisfaction based on surveys`,
    },
    {
      factor: "Open Tickets",
      impact: passenger.openTickets > 2 ? "High" : passenger.openTickets > 0 ? "Medium" : "Low",
      detail: `${passenger.openTickets} unresolved support issues`,
    },
    {
      factor: "Engagement Drop",
      impact: "Medium",
      detail: "40% decrease in app opens this quarter",
    },
  ]

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={passenger.id}
        initial={{ opacity: 0 }}
        animate={{ opacity: showContent ? 1 : 0 }}
        exit={{ opacity: 0 }}
        className="p-6 space-y-6"
      >
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center text-xl font-bold font-mono border-2 border-primary/30 glow-primary text-foreground">
              {passenger.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Terminal className="w-4 h-4 text-primary" />
                <h1 className="text-xl font-bold tracking-tight text-foreground">{passenger.name}</h1>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="outline" className="text-[10px] font-mono text-foreground">
                  {passenger.id}
                </Badge>
                <Badge
                  variant="outline"
                  className={cn(
                    "text-[10px] font-mono",
                    passenger.tier === "Platinum"
                      ? "bg-slate-400/10 text-slate-600 dark:text-slate-300 border-slate-400/30"
                      : passenger.tier === "Gold"
                        ? "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30"
                        : "bg-zinc-400/10 text-zinc-600 dark:text-zinc-300 border-zinc-400/30",
                  )}
                >
                  {passenger.tier}
                </Badge>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono">
                  <ChannelIcon className="w-3.5 h-3.5" />
                  {passenger.commChannel}
                </div>
              </div>
            </div>
          </div>
          <div className="text-right p-3 rounded border border-border bg-card/50">
            <div className="flex items-center gap-2 justify-end">
              <span className="text-[10px] text-muted-foreground font-mono uppercase">Risk Score</span>
            </div>
            <div
              className={cn(
                "text-3xl font-bold font-mono",
                passenger.riskScore >= 70
                  ? "text-destructive glow-text"
                  : passenger.riskScore >= 40
                    ? "text-accent"
                    : "text-chart-4",
              )}
            >
              {passenger.riskScore}%
            </div>
            <Badge
              variant="outline"
              className={cn(
                "mt-1 text-[10px] font-mono",
                passenger.riskScore >= 70
                  ? "bg-destructive/10 text-destructive border-destructive/30"
                  : passenger.riskScore >= 40
                    ? "bg-accent/10 text-accent border-accent/30"
                    : "bg-chart-4/10 text-chart-4 border-chart-4/30",
              )}
            >
              {passenger.riskScore >= 70 ? "HIGH RISK" : passenger.riskScore >= 40 ? "MEDIUM RISK" : "LOW RISK"}
            </Badge>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Stats */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            <Card className="bg-card border-border corner-brackets">
              <CardHeader className="pb-3">
                <CardTitle className="text-[10px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Customer Value
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-primary" />
                    <span className="text-xs font-mono text-foreground">Lifetime Value</span>
                  </div>
                  <span className="font-mono font-bold text-lg text-primary">${passenger.ltv.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Plane className="w-4 h-4 text-primary" />
                    <span className="text-xs font-mono text-foreground">Total Flights</span>
                  </div>
                  <span className="font-mono font-bold text-foreground">{passenger.totalFlights}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="w-4 h-4 text-accent" />
                    <span className="text-xs font-mono text-foreground">Miles Balance</span>
                  </div>
                  <span className="font-mono font-bold text-foreground">{passenger.milesBalance.toLocaleString()}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border corner-brackets">
              <CardHeader className="pb-3">
                <CardTitle className="text-[10px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Engagement Signals
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1 font-mono">
                    <span className="text-foreground">Sentiment Score</span>
                    <span
                      className={cn(
                        "font-bold",
                        passenger.sentimentScore < 40 ? "text-destructive" : "text-foreground",
                      )}
                    >
                      {passenger.sentimentScore}%
                    </span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${passenger.sentimentScore}%` }}
                      transition={{ duration: 0.5, delay: 0.3 }}
                      className={cn(
                        "h-full rounded-full",
                        passenger.sentimentScore < 40
                          ? "bg-destructive"
                          : passenger.sentimentScore < 60
                            ? "bg-accent"
                            : "bg-chart-4",
                      )}
                    />
                  </div>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs font-mono text-foreground">Open Tickets</span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "font-mono text-[10px]",
                      passenger.openTickets > 0 ? "text-destructive border-destructive/30" : "text-muted-foreground",
                    )}
                  >
                    {passenger.openTickets}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-foreground">Last Flight</span>
                  <span className="text-xs font-mono text-muted-foreground">{passenger.lastFlight}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Center Column - Timeline */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="bg-card border-border h-full corner-brackets">
              <CardHeader className="pb-3">
                <CardTitle className="text-[10px] font-mono font-bold text-muted-foreground uppercase tracking-wider">
                  Journey Timeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {passenger.timeline.map((event, index) => {
                    const Icon = eventIcons[event.type]
                    return (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 + index * 0.08 }}
                        className={cn("flex gap-3 p-3 rounded border text-xs", eventColors[event.type])}
                      >
                        <Icon className="w-4 h-4 mt-0.5 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-mono">{event.event}</p>
                          <p className="text-[10px] text-muted-foreground mt-1 font-mono">{event.date}</p>
                        </div>
                      </motion.div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Right Column - Insights */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-4"
          >
            <Card className="bg-gradient-to-br from-destructive/10 to-destructive/5 border-destructive/20 corner-brackets">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-primary" />
                  <CardTitle className="text-[10px] font-mono font-bold uppercase tracking-wider text-foreground">
                    Churn Insights
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 rounded bg-background/50 border border-border">
                  <p className="text-[10px] font-mono font-bold text-destructive uppercase">Primary Driver</p>
                  <p className="text-base font-bold mt-1 text-foreground">{passenger.churnDriver}</p>
                </div>
                {churnInsights.map((insight, index) => (
                  <div key={index} className="flex items-center justify-between p-2 rounded bg-background/30 text-xs">
                    <span className="font-mono text-foreground">{insight.factor}</span>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px] font-mono",
                        insight.impact === "High"
                          ? "border-destructive/50 text-destructive"
                          : insight.impact === "Medium"
                            ? "border-accent/50 text-accent"
                            : "border-chart-4/50 text-chart-4",
                      )}
                    >
                      {insight.impact}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Button
              className="w-full h-12 text-sm font-bold font-mono bg-primary hover:bg-primary/90 glow-primary uppercase tracking-wider"
              onClick={() => onShortlistOffers(passenger)}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Show Personalised Offer
            </Button>
          </motion.div>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}
