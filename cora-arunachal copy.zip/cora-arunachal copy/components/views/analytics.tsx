"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  TrendingUp,
  DollarSign,
  Users,
  Target,
  ArrowUpRight,
  Terminal,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  Brain,
  Sparkles,
  Mail,
  MessageSquare,
  Smartphone,
  ChevronRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend,
  AreaChart,
  Area,
} from "recharts"
import { analyticsData, interventionHistory, feedbackMetrics } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

const kpis = [
  {
    label: "Total Revenue Saved",
    value: "$879K",
    change: "+23.4%",
    icon: DollarSign,
  },
  {
    label: "Customers Retained",
    value: "2,341",
    change: "+18.2%",
    icon: Users,
  },
  {
    label: "Avg. Conversion Rate",
    value: "34.5%",
    change: "+5.7%",
    icon: Target,
  },
  {
    label: "ROI on Campaigns",
    value: "4.2x",
    change: "+0.8x",
    icon: TrendingUp,
  },
]

const channelIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Email: Mail,
  WhatsApp: MessageSquare,
  App: Smartphone,
}

const statusConfig = {
  sent: { icon: Clock, color: "text-muted-foreground", bg: "bg-muted/30" },
  opened: { icon: Clock, color: "text-accent", bg: "bg-accent/10" },
  accepted: { icon: CheckCircle2, color: "text-chart-4", bg: "bg-chart-4/10" },
  rejected: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/10" },
  expired: { icon: Clock, color: "text-muted-foreground", bg: "bg-muted/30" },
}

export function Analytics() {
  const [selectedTab, setSelectedTab] = useState("overview")

  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="p-6 space-y-6">
      {/* Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight text-primary">ANALYTICS_HUB</h1>
          </div>
          <p className="text-muted-foreground text-sm font-mono">
            <span className="text-primary">$</span> insights.feedback_loop | continuous_optimization
          </p>
        </div>
        <Button variant="outline" className="font-mono text-xs bg-transparent">
          <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
          Refresh Data
        </Button>
      </motion.div>

      {/* KPI Cards */}
      <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label} className="bg-card border-border">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <kpi.icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex items-center gap-1 text-chart-4 text-xs font-medium">
                  <ArrowUpRight className="w-3 h-3" />
                  {kpi.change}
                </div>
              </div>
              <p className="text-2xl font-bold">{kpi.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{kpi.label}</p>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      {/* Main Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="space-y-6">
        <TabsList className="bg-muted/50 border border-border">
          <TabsTrigger
            value="overview"
            className="font-mono text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
          >
            PERFORMANCE
          </TabsTrigger>
          <TabsTrigger
            value="interventions"
            className="font-mono text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
          >
            INTERVENTION HISTORY
          </TabsTrigger>
          <TabsTrigger
            value="feedback"
            className="font-mono text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
          >
            FEEDBACK LOOP
          </TabsTrigger>
          <TabsTrigger
            value="optimization"
            className="font-mono text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary"
          >
            AI OPTIMIZATION
          </TabsTrigger>
        </TabsList>

        {/* Performance Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <motion.div variants={itemVariants}>
              <Card className="bg-card border-border h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">Offer Performance</CardTitle>
                  <p className="text-sm text-muted-foreground">Acceptance vs Retention by offer type</p>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analyticsData.offerPerformance} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={false} />
                        <XAxis type="number" stroke="#71717a" fontSize={12} />
                        <YAxis dataKey="offer" type="category" stroke="#71717a" fontSize={11} width={90} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#18181b",
                            border: "1px solid #27272a",
                            borderRadius: "8px",
                            color: "#fafafa",
                          }}
                        />
                        <Legend />
                        <Bar dataKey="acceptance" name="Acceptance %" fill="#2dd4bf" radius={[0, 4, 4, 0]} />
                        <Bar dataKey="retention" name="Retention %" fill="#f59e0b" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Card className="bg-card border-border h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">Churn Driver Distribution</CardTitle>
                  <p className="text-sm text-muted-foreground">Primary reasons for customer churn</p>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={analyticsData.churnDrivers}>
                        <PolarGrid stroke="#27272a" />
                        <PolarAngleAxis dataKey="driver" stroke="#71717a" fontSize={11} />
                        <PolarRadiusAxis stroke="#71717a" fontSize={10} />
                        <Radar name="Cases" dataKey="count" stroke="#2dd4bf" fill="#2dd4bf" fillOpacity={0.3} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#18181b",
                            border: "1px solid #27272a",
                            borderRadius: "8px",
                            color: "#fafafa",
                          }}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Segment Heatmap */}
          <motion.div variants={itemVariants}>
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-semibold">Offer Effectiveness Heatmap</CardTitle>
                <p className="text-sm text-muted-foreground">Which offers work best for which risk segments</p>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left p-3 font-medium text-muted-foreground">Offer / Segment</th>
                        <th className="text-center p-3 font-medium text-muted-foreground">High Risk</th>
                        <th className="text-center p-3 font-medium text-muted-foreground">Medium Risk</th>
                        <th className="text-center p-3 font-medium text-muted-foreground">Low Risk</th>
                        <th className="text-center p-3 font-medium text-muted-foreground">Platinum</th>
                        <th className="text-center p-3 font-medium text-muted-foreground">Gold</th>
                        <th className="text-center p-3 font-medium text-muted-foreground">Silver</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { offer: "Priority Lounge Pass", values: [92, 78, 45, 95, 82, 58] },
                        { offer: "Double Miles Boost", values: [85, 88, 72, 78, 92, 85] },
                        { offer: "Complimentary Upgrade", values: [88, 72, 38, 92, 75, 42] },
                        { offer: "Loyalty Bonus Miles", values: [78, 82, 68, 72, 88, 78] },
                        { offer: "Price Match Guarantee", values: [62, 75, 88, 45, 68, 92] },
                      ].map((row) => (
                        <tr key={row.offer} className="border-b border-border">
                          <td className="p-3 font-medium">{row.offer}</td>
                          {row.values.map((val, i) => (
                            <td key={i} className="p-3 text-center">
                              <div
                                className="w-full py-2 rounded text-xs font-mono font-medium"
                                style={{
                                  backgroundColor: `oklch(${0.4 + (val / 100) * 0.35} ${0.15 + (val / 100) * 0.05} ${180 - (val / 100) * 30} / ${0.15 + (val / 100) * 0.2})`,
                                  color: val >= 70 ? "#2dd4bf" : val >= 50 ? "#f59e0b" : "#ef4444",
                                }}
                              >
                                {val}%
                              </div>
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Intervention History Tab */}
        <TabsContent value="interventions" className="space-y-6">
          <motion.div variants={itemVariants}>
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg font-semibold">Recent Interventions</CardTitle>
                    <p className="text-sm text-muted-foreground">Track all retention offers and their outcomes</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs text-chart-4 border-chart-4/30">
                      {interventionHistory.filter((i) => i.status === "accepted").length} Accepted
                    </Badge>
                    <Badge variant="outline" className="font-mono text-xs text-destructive border-destructive/30">
                      {interventionHistory.filter((i) => i.retentionOutcome === "churned").length} Churned
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {interventionHistory.map((intervention, index) => {
                    const statusInfo = statusConfig[intervention.status]
                    const StatusIcon = statusInfo.icon
                    const ChannelIcon = channelIcons[intervention.channel]

                    return (
                      <motion.div
                        key={intervention.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-center gap-4 p-4 rounded-lg bg-muted/30 border border-border hover:border-primary/30 transition-colors"
                      >
                        <div className={cn("w-10 h-10 rounded flex items-center justify-center", statusInfo.bg)}>
                          <StatusIcon className={cn("w-5 h-5", statusInfo.color)} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm truncate">{intervention.passengerName}</span>
                            <Badge variant="outline" className="text-[10px] font-mono">
                              {intervention.offerTitle}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <ChannelIcon className="w-3 h-3" />
                              {intervention.channel}
                            </span>
                            <span>{new Date(intervention.sentAt).toLocaleDateString()}</span>
                            {intervention.notes && (
                              <span className="text-accent truncate max-w-[200px]">{intervention.notes}</span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <Badge
                            variant="outline"
                            className={cn(
                              "font-mono text-xs",
                              intervention.status === "accepted"
                                ? "text-chart-4 border-chart-4/30"
                                : intervention.status === "rejected"
                                  ? "text-destructive border-destructive/30"
                                  : "text-muted-foreground",
                            )}
                          >
                            {intervention.status.toUpperCase()}
                          </Badge>
                          {intervention.revenueImpact && (
                            <div className="text-right min-w-[80px]">
                              <p
                                className={cn(
                                  "text-sm font-bold font-mono",
                                  intervention.revenueImpact > 0 ? "text-chart-4" : "text-destructive",
                                )}
                              >
                                {intervention.revenueImpact > 0 ? "+" : ""}$
                                {Math.abs(intervention.revenueImpact / 1000).toFixed(1)}K
                              </p>
                              <p className="text-[10px] text-muted-foreground">Revenue Impact</p>
                            </div>
                          )}
                          {intervention.retentionOutcome && (
                            <Badge
                              className={cn(
                                "font-mono text-[10px]",
                                intervention.retentionOutcome === "retained"
                                  ? "bg-chart-4/20 text-chart-4 border-chart-4/30"
                                  : intervention.retentionOutcome === "churned"
                                    ? "bg-destructive/20 text-destructive border-destructive/30"
                                    : "bg-accent/20 text-accent border-accent/30",
                              )}
                            >
                              {intervention.retentionOutcome.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                      </motion.div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Feedback Loop Tab */}
        <TabsContent value="feedback" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Metrics Summary */}
            <motion.div variants={itemVariants} className="lg:col-span-1">
              <Card className="bg-card border-border h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">Feedback Metrics</CardTitle>
                  <p className="text-sm text-muted-foreground">Key performance indicators</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Total Interventions</span>
                      <span className="text-lg font-bold font-mono">{feedbackMetrics.totalInterventions}</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Acceptance Rate</span>
                        <span className="text-sm font-mono text-primary">{feedbackMetrics.acceptanceRate}%</span>
                      </div>
                      <Progress value={feedbackMetrics.acceptanceRate} className="h-2" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Retention Rate</span>
                        <span className="text-sm font-mono text-chart-4">{feedbackMetrics.retentionRate}%</span>
                      </div>
                      <Progress value={feedbackMetrics.retentionRate} className="h-2" />
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-border">
                      <span className="text-sm text-muted-foreground">Avg. Revenue/Intervention</span>
                      <span className="text-lg font-bold font-mono text-chart-4">
                        ${(feedbackMetrics.avgRevenuePerIntervention / 1000).toFixed(1)}K
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Weekly Trend */}
            <motion.div variants={itemVariants} className="lg:col-span-2">
              <Card className="bg-card border-border h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-semibold">Weekly Performance Trend</CardTitle>
                  <p className="text-sm text-muted-foreground">Interventions sent, accepted, and retained</p>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={feedbackMetrics.weeklyTrend}>
                        <defs>
                          <linearGradient id="sentGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#71717a" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#71717a" stopOpacity={0} />
                          </linearGradient>
                          <linearGradient id="acceptedGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0} />
                          </linearGradient>
                          <linearGradient id="retainedGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                        <XAxis dataKey="week" stroke="#71717a" fontSize={12} />
                        <YAxis stroke="#71717a" fontSize={12} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "#18181b",
                            border: "1px solid #27272a",
                            borderRadius: "8px",
                            color: "#fafafa",
                          }}
                        />
                        <Legend />
                        <Area
                          type="monotone"
                          dataKey="sent"
                          name="Sent"
                          stroke="#71717a"
                          fill="url(#sentGrad)"
                          strokeWidth={2}
                        />
                        <Area
                          type="monotone"
                          dataKey="accepted"
                          name="Accepted"
                          stroke="#2dd4bf"
                          fill="url(#acceptedGrad)"
                          strokeWidth={2}
                        />
                        <Area
                          type="monotone"
                          dataKey="retained"
                          name="Retained"
                          stroke="#22c55e"
                          fill="url(#retainedGrad)"
                          strokeWidth={2}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Best Offers by Segment */}
          <motion.div variants={itemVariants}>
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-semibold">Best Performing Offers by Segment</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Optimized offer recommendations based on historical data
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {feedbackMetrics.offersBySegment.map((segment, index) => (
                    <motion.div
                      key={segment.segment}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="p-4 rounded-lg bg-muted/30 border border-border"
                    >
                      <p className="text-xs text-muted-foreground font-mono mb-2">{segment.segment}</p>
                      <p className="font-bold text-sm mb-1">{segment.bestOffer}</p>
                      <div className="flex items-center gap-2">
                        <Progress value={segment.successRate} className="h-1.5 flex-1" />
                        <span className="text-xs font-mono text-chart-4">{segment.successRate}%</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* AI Optimization Tab */}
        <TabsContent value="optimization" className="space-y-6">
          <motion.div variants={itemVariants}>
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded bg-accent/10 flex items-center justify-center border border-accent/30">
                    <Brain className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-semibold">Continuous Optimization Engine</CardTitle>
                    <p className="text-sm text-muted-foreground">AI-driven strategy improvements based on feedback</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Learning Insights */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Sparkles className="w-4 h-4 text-accent" />
                        <span className="text-xs font-mono font-bold text-accent">INSIGHT #1</span>
                      </div>
                      <p className="text-sm mb-2 font-medium text-foreground">
                        Upgrade offers underperform for price-sensitive segments
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Recommendation: Route price-sensitive customers to discount or miles-based offers instead.
                      </p>
                      <Badge variant="outline" className="mt-3 text-[10px] font-mono text-foreground">
                        +23% expected improvement
                      </Badge>
                    </CardContent>
                  </Card>

                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Sparkles className="w-4 h-4 text-accent" />
                        <span className="text-xs font-mono font-bold text-accent">INSIGHT #2</span>
                      </div>
                      <p className="text-sm mb-2 font-medium text-foreground">
                        WhatsApp shows 34% higher acceptance than email
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Recommendation: Prioritize WhatsApp for high-risk customers when available.
                      </p>
                      <Badge variant="outline" className="mt-3 text-[10px] font-mono text-foreground">
                        +18% expected improvement
                      </Badge>
                    </CardContent>
                  </Card>

                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Sparkles className="w-4 h-4 text-accent" />
                        <span className="text-xs font-mono font-bold text-accent">INSIGHT #3</span>
                      </div>
                      <p className="text-sm mb-2 font-medium text-foreground">
                        Response time correlates with retention success
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Customers who accept within 24h have 89% retention vs 62% for 48h+.
                      </p>
                      <Badge variant="outline" className="mt-3 text-[10px] font-mono text-foreground">
                        +27% retention impact
                      </Badge>
                    </CardContent>
                  </Card>
                </div>

                {/* Strategy Updates */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-primary" />
                    <span className="text-sm font-mono font-bold text-foreground">STRATEGY UPDATES</span>
                    <span className="text-xs text-muted-foreground font-mono">// Auto-applied optimizations</span>
                  </div>
                  <div className="space-y-2">
                    {[
                      {
                        update: "Adjusted offer matching weights for delay-affected segment",
                        impact: "+12% acceptance",
                        date: "2 hours ago",
                      },
                      {
                        update: "Increased simulation iterations for high-LTV customers",
                        impact: "+8% precision",
                        date: "1 day ago",
                      },
                      {
                        update: "Updated persona behavioral traits based on Q4 data",
                        impact: "+15% accuracy",
                        date: "3 days ago",
                      },
                      {
                        update: "Rebalanced agent weights in multi-agent simulation",
                        impact: "+6% confidence",
                        date: "1 week ago",
                      },
                    ].map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 rounded bg-muted/20 border border-border"
                      >
                        <div className="flex items-center gap-3">
                          <ChevronRight className="w-4 h-4 text-primary" />
                          <span className="text-sm text-foreground">{item.update}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge className="bg-chart-4/20 text-chart-4 border-chart-4/30 text-[10px] font-mono">
                            {item.impact}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{item.date}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Model Performance */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-border">
                  <div className="p-4 rounded bg-primary/5 border border-primary/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-mono font-bold text-foreground">Model Accuracy</span>
                      <span className="text-lg font-bold font-mono text-primary">94.2%</span>
                    </div>
                    <Progress value={94.2} className="h-2 mb-2" />
                    <p className="text-xs text-muted-foreground">Churn prediction accuracy over last 30 days</p>
                  </div>
                  <div className="p-4 rounded bg-accent/5 border border-accent/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-mono font-bold text-foreground">Simulation Accuracy</span>
                      <span className="text-lg font-bold font-mono text-accent">87.6%</span>
                    </div>
                    <Progress value={87.6} className="h-2 mb-2" />
                    <p className="text-xs text-muted-foreground">Offer acceptance prediction vs actual outcomes</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </motion.div>
  )
}
