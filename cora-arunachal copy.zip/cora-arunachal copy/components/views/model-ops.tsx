"use client"

import { motion } from "framer-motion"
import { Cpu, Activity, Clock, Database, CheckCircle2, Layers, RefreshCw, Zap } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
}

const models = [
  {
    name: "Churn Prediction Model",
    version: "v2.4.1",
    status: "active",
    accuracy: 94.2,
    lastTrained: "2024-11-28",
    predictions: "12,450",
    type: "XGBoost",
  },
  {
    name: "Sentiment Analysis Engine",
    version: "v1.8.0",
    status: "active",
    accuracy: 91.7,
    lastTrained: "2024-11-25",
    predictions: "8,234",
    type: "LLM (GPT-4)",
  },
  {
    name: "Offer Recommender",
    version: "v3.1.2",
    status: "active",
    accuracy: 87.3,
    lastTrained: "2024-11-30",
    predictions: "5,672",
    type: "Hybrid ML+LLM",
  },
  {
    name: "Simulation Engine",
    version: "v1.2.0",
    status: "training",
    accuracy: 82.1,
    lastTrained: "Training...",
    predictions: "2,341",
    type: "Agent-based",
  },
]

const performanceData = [
  { day: "Mon", accuracy: 93.2, latency: 45 },
  { day: "Tue", accuracy: 93.8, latency: 42 },
  { day: "Wed", accuracy: 94.1, latency: 38 },
  { day: "Thu", accuracy: 93.9, latency: 41 },
  { day: "Fri", accuracy: 94.5, latency: 35 },
  { day: "Sat", accuracy: 94.2, latency: 36 },
  { day: "Sun", accuracy: 94.6, latency: 33 },
]

export function ModelOps() {
  return (
    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="p-6 space-y-6">
      {/* Header */}
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Model Operations</h1>
          <p className="text-muted-foreground mt-1">Monitor and manage AI model health</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90">
          <RefreshCw className="w-4 h-4 mr-2" />
          Retrain All
        </Button>
      </motion.div>

      {/* Quick Stats */}
      <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-chart-4/10 flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-chart-4" />
              </div>
              <div>
                <p className="text-2xl font-bold">4/4</p>
                <p className="text-xs text-muted-foreground">Models Online</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold font-mono">94.2%</p>
                <p className="text-xs text-muted-foreground">Avg Accuracy</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                <Clock className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold font-mono">38ms</p>
                <p className="text-xs text-muted-foreground">Avg Latency</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-chart-3/10 flex items-center justify-center">
                <Database className="w-5 h-5 text-chart-3" />
              </div>
              <div>
                <p className="text-2xl font-bold">28.7K</p>
                <p className="text-xs text-muted-foreground">Predictions Today</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Models Grid */}
      <motion.div variants={itemVariants}>
        <h2 className="text-lg font-semibold mb-4">Active Models</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {models.map((model) => (
            <Card key={model.name} className="bg-card border-border">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center">
                      {model.type.includes("LLM") ? (
                        <Zap className="w-5 h-5 text-primary" />
                      ) : model.type.includes("Agent") ? (
                        <Layers className="w-5 h-5 text-primary" />
                      ) : (
                        <Cpu className="w-5 h-5 text-primary" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold">{model.name}</h3>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Badge variant="outline" className="text-[10px] font-mono">
                          {model.version}
                        </Badge>
                        <Badge
                          className={
                            model.status === "active"
                              ? "bg-chart-4/20 text-chart-4 text-[10px]"
                              : "bg-accent/20 text-accent text-[10px]"
                          }
                        >
                          {model.status === "active" ? (
                            <>
                              <span className="w-1.5 h-1.5 rounded-full bg-chart-4 mr-1" />
                              Active
                            </>
                          ) : (
                            <>
                              <RefreshCw className="w-2.5 h-2.5 mr-1 animate-spin" />
                              Training
                            </>
                          )}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-[10px]">
                    {model.type}
                  </Badge>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-muted-foreground">Accuracy</span>
                      <span className="font-mono font-medium">{model.accuracy}%</span>
                    </div>
                    <Progress value={model.accuracy} className="h-1.5" />
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border">
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Last Trained</p>
                      <p className="text-sm font-mono mt-1">{model.lastTrained}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Predictions</p>
                      <p className="text-sm font-mono mt-1">{model.predictions}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </motion.div>

      {/* Performance Chart */}
      <motion.div variants={itemVariants}>
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold">Weekly Performance</CardTitle>
            <p className="text-sm text-muted-foreground">Model accuracy and response latency trends</p>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis dataKey="day" stroke="#71717a" fontSize={12} />
                  <YAxis yAxisId="left" stroke="#71717a" fontSize={12} domain={[90, 100]} />
                  <YAxis yAxisId="right" orientation="right" stroke="#71717a" fontSize={12} domain={[0, 60]} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#18181b",
                      border: "1px solid #27272a",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="accuracy"
                    stroke="#2dd4bf"
                    strokeWidth={2}
                    dot={{ fill: "#2dd4bf", strokeWidth: 0 }}
                    name="Accuracy %"
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="latency"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    dot={{ fill: "#f59e0b", strokeWidth: 0 }}
                    name="Latency (ms)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}
