"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  FlaskConical,
  Users,
  Send,
  Sparkles,
  DollarSign,
  Terminal,
  Brain,
  Gift,
  Heart,
  Zap,
  Star,
  Settings2,
  X,
  Check,
  ChevronDown,
  ChevronUp,
  Mail,
  MessageSquare,
  Smartphone,
  Copy,
  Home,
  Loader2,
  User,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { type Passenger, type Offer, simulationAgents, type SimulationAgent } from "@/lib/mock-data"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

interface GeneratedPersona {
  id: string
  name: string
  behavioralTraits: {
    valueSensitivity: number
    frustrationTolerance: number
    loyaltyOrientation: number
    conveniencePreference: number
    serviceRecoveryExpectation: number
    priceElasticity: number
  }
  derivedFrom: string[]
  summary: string
}

interface SimulationConfig {
  iterations: number
  variabilityWeight: number
  selectedAgents: string[]
  persona: GeneratedPersona | null
}

interface AgentDebateResult {
  agentId: string
  agentName: string
  decision: "accept" | "reject" | "neutral"
  probability: number
  reasoning: string
  finalStance: string
}

interface OfferSimulationResult {
  offerId: string
  offerTitle: string
  acceptanceLikelihood: number
  confidence: number
  variance: number
  agentResults: AgentDebateResult[]
  topInfluencingArguments: string[]
  recommendation: "highly_recommended" | "recommended" | "neutral" | "not_recommended"
}

interface GeneratedMessage {
  subject: string
  greeting: string
  body: string
  offerDetails: string
  couponCode: string
  callToAction: string
  footer: string
  channel: "Email" | "WhatsApp" | "App"
}

interface SimulationProps {
  passenger: Passenger | null
  shortlistedOffers: Offer[]
  persona: GeneratedPersona | null
  onSendOffer: (offer: Offer) => void
  onNavigateHome: () => void
}

const agentIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Heart: Heart,
  Brain: Brain,
  DollarSign: DollarSign,
  Zap: Zap,
  Star: Star,
}

const channelIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Email: Mail,
  WhatsApp: MessageSquare,
  App: Smartphone,
}

const traitLabels: Record<string, string> = {
  valueSensitivity: "Value Sensitivity",
  frustrationTolerance: "Frustration Tolerance",
  loyaltyOrientation: "Loyalty Orientation",
  conveniencePreference: "Convenience Preference",
  serviceRecoveryExpectation: "Recovery Expectation",
  priceElasticity: "Price Elasticity",
}

function simulateAgentDebate(
  offer: Offer,
  persona: GeneratedPersona,
  agents: SimulationAgent[],
  iterations: number,
  variability: number,
): OfferSimulationResult {
  const agentResults: AgentDebateResult[] = agents.map((agent) => {
    let baseProb = offer.fitScore / 100

    switch (agent.type) {
      case "emotional":
        baseProb *= persona.behavioralTraits.frustrationTolerance / 100
        baseProb *= 1.2
        break
      case "rational":
        baseProb *= persona.behavioralTraits.loyaltyOrientation / 100
        break
      case "financial":
        baseProb *= 1 - persona.behavioralTraits.priceElasticity / 200
        if (offer.category === "Discount") baseProb *= 1.3
        break
      case "convenience":
        baseProb *= persona.behavioralTraits.conveniencePreference / 100
        break
      case "experience":
        baseProb *= persona.behavioralTraits.loyaltyOrientation / 100
        if (offer.category === "Experience") baseProb *= 1.2
        break
    }

    const variance = (Math.random() - 0.5) * variability * 0.4
    const finalProb = Math.min(0.95, Math.max(0.15, baseProb + variance))

    const decision: "accept" | "reject" | "neutral" =
      finalProb > 0.65 ? "accept" : finalProb < 0.35 ? "reject" : "neutral"

    const reasonings: Record<string, string[]> = {
      emotional: [
        "Recent frustrations suggest high receptivity to service recovery offers.",
        "Emotional state indicates need for immediate positive reinforcement.",
        "Past negative experiences create opportunity for redemption narrative.",
      ],
      rational: [
        "LTV analysis supports investment in retention offer.",
        "Long-term value proposition aligns with customer profile.",
        "Cost-benefit calculation favors offer acceptance.",
      ],
      financial: [
        "Price sensitivity profile matches offer value proposition.",
        "Budget constraints suggest moderate acceptance likelihood.",
        "Monetary value of offer aligns with spending patterns.",
      ],
      convenience: [
        "Convenience factors strongly influence this customer segment.",
        "Seamless experience delivery is a key driver.",
        "Friction reduction in offer appeals to preferences.",
      ],
      experience: [
        "Brand relationship history supports positive reception.",
        "Past interactions indicate receptivity to experience-based offers.",
        "Loyalty patterns suggest alignment with offer type.",
      ],
    }

    return {
      agentId: agent.id,
      agentName: agent.name,
      decision,
      probability: Math.round(finalProb * 100),
      reasoning: reasonings[agent.type][Math.floor(Math.random() * 3)],
      finalStance:
        decision === "accept"
          ? "Recommends proceeding with offer."
          : decision === "reject"
            ? "Suggests alternative approach."
            : "Neutral stance, additional factors needed.",
    }
  })

  let totalProb = 0
  const probabilities: number[] = []

  for (let i = 0; i < iterations; i++) {
    let iterProb = 0
    let totalWeight = 0

    agentResults.forEach((result, idx) => {
      const agent = agents[idx]
      const iterVariance = (Math.random() - 0.5) * variability * 20
      iterProb += (result.probability + iterVariance) * agent.weight
      totalWeight += agent.weight
    })

    const normalizedProb = Math.min(95, Math.max(15, iterProb / totalWeight))
    probabilities.push(normalizedProb)
    totalProb += normalizedProb
  }

  const avgProb = totalProb / iterations
  const variance = probabilities.reduce((sum, p) => sum + Math.pow(p - avgProb, 2), 0) / iterations
  const stdDev = Math.sqrt(variance)

  return {
    offerId: offer.id,
    offerTitle: offer.title,
    acceptanceLikelihood: Math.round(avgProb),
    confidence: Math.max(60, Math.round(100 - stdDev * 2)),
    variance: Math.round(stdDev * 10) / 10,
    agentResults,
    topInfluencingArguments: agentResults
      .sort((a, b) => b.probability - a.probability)
      .slice(0, 2)
      .map((r) => r.reasoning),
    recommendation:
      avgProb >= 75
        ? "highly_recommended"
        : avgProb >= 55
          ? "recommended"
          : avgProb >= 40
            ? "neutral"
            : "not_recommended",
  }
}

function generateMarketingMessage(passenger: Passenger, offer: Offer): GeneratedMessage {
  const couponCode = `CORA-${passenger.id.split("-")[1]}-${offer.id.split("-")[1]}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`

  const greetings: Record<string, string> = {
    Email: `Dear ${passenger.name},`,
    WhatsApp: `Hi ${passenger.name.split(" ")[0]}!`,
    App: `Hey ${passenger.name.split(" ")[0]},`,
  }

  const bodies: Record<string, string> = {
    "Frequent Delays": `We know your recent travels haven't gone as smoothly as you—or we—would have liked. Flight delays are frustrating, and we truly appreciate your patience and loyalty as a ${passenger.tier} member.`,
    "Loyalty Neglect": `As one of our valued ${passenger.tier} members with ${passenger.totalFlights} flights, we want to make sure you know just how much we appreciate your continued loyalty to our airline.`,
    "Price Sensitivity": `We understand that value matters, and we want to ensure you're getting the best experience for your investment. As a loyal customer, you deserve special recognition.`,
    "Service Failure": `We've heard your feedback, and we're committed to making things right. Your experience matters deeply to us, and we want to show you that we're taking action.`,
    Inactivity: `We've missed seeing you on board! It's been a while since your last flight, and we wanted to reach out with something special to welcome you back.`,
    "Route Changes": `We know recent changes to your preferred routes may have caused some inconvenience. We're working to serve you better, and we have something special to offer.`,
  }

  const offerDetails: Record<string, string> = {
    Miles: `Earn ${offer.title} - ${offer.desc}. This exclusive benefit is valued at $${offer.value} and is our way of saying thank you.`,
    Upgrade: `We're offering you ${offer.title} - ${offer.desc}. Experience the comfort and service you deserve on your next journey with us.`,
    Experience: `Enjoy ${offer.title} - ${offer.desc}. This premium experience is reserved for our most valued travelers like yourself.`,
    Discount: `Take advantage of our ${offer.title} - ${offer.desc}. We want to ensure you always get the best value when flying with us.`,
  }

  const callToActions: Record<string, string> = {
    Email: `To redeem this exclusive offer, simply use the code below when booking your next flight or present it at check-in.`,
    WhatsApp: `Ready to claim your offer? Just reply "YES" or tap the button below!`,
    App: `Tap below to activate this offer in your account instantly.`,
  }

  return {
    subject: `${passenger.name.split(" ")[0]}, a special offer just for you`,
    greeting: greetings[passenger.commChannel],
    body: bodies[passenger.churnDriver] || bodies["Loyalty Neglect"],
    offerDetails: offerDetails[offer.category],
    couponCode,
    callToAction: callToActions[passenger.commChannel],
    footer:
      passenger.commChannel === "Email"
        ? `This offer expires in 14 days. Terms and conditions apply.\n\nWith warm regards,\nYour Airline Team`
        : passenger.commChannel === "WhatsApp"
          ? `Offer valid for 14 days. T&C apply. Reply STOP to unsubscribe.`
          : `Valid for 14 days. Tap for full terms.`,
    channel: passenger.commChannel,
  }
}

function EmptyState({ onNavigateHome }: { onNavigateHome: () => void }) {
  const [cursorVisible, setCursorVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setCursorVisible((prev) => !prev)
    }, 530)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight text-primary">SIMULATION_ENGINE</h1>
          </div>
          <p className="text-muted-foreground text-sm font-mono">
            <span className="text-primary">$</span> simulation.awaiting_input
          </p>
        </div>
      </div>

      <div className="p-4 rounded border border-accent/30 bg-accent/5 corner-brackets">
        <div className="flex items-center gap-3">
          <Brain className="w-5 h-5 text-accent" />
          <div>
            <p className="text-sm font-mono text-accent">No simulation data available</p>
            <p className="text-xs text-muted-foreground font-mono mt-1">
              Go to <span className="text-primary">Customer 360</span> →{" "}
              <span className="text-primary">Show Personalised Offer</span> →{" "}
              <span className="text-primary">Run Simulation</span>
              <span className={cn("ml-1", cursorVisible ? "opacity-100" : "opacity-0")}>_</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function SimulationConfigOverlay({
  isOpen,
  onClose,
  passenger,
  persona,
  offers,
  onStartSimulation,
}: {
  isOpen: boolean
  onClose: () => void
  passenger: Passenger
  persona: GeneratedPersona
  offers: Offer[]
  onStartSimulation: (config: SimulationConfig) => void
}) {
  const [selectedAgents, setSelectedAgents] = useState<string[]>(simulationAgents.map((a) => a.id))
  const [iterations, setIterations] = useState(50)
  const [variabilityWeight, setVariabilityWeight] = useState(0.3)

  const toggleAgent = (agentId: string) => {
    setSelectedAgents((prev) => (prev.includes(agentId) ? prev.filter((id) => id !== agentId) : [...prev, agentId]))
  }

  const handleStartSimulation = () => {
    onStartSimulation({
      iterations,
      variabilityWeight,
      selectedAgents,
      persona,
    })
  }

  if (!isOpen) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-4xl max-h-[90vh] overflow-y-auto m-4"
      >
        <Card className="bg-card border-primary/30 corner-brackets shadow-2xl">
          <CardContent className="p-0">
            {/* Header */}
            <div className="p-6 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center border border-primary/30">
                  <Settings2 className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h2 className="text-lg font-bold font-mono text-primary">SIMULATION_CONFIG</h2>
                  <p className="text-xs text-muted-foreground font-mono">
                    Configure multi-agent deliberation parameters
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-muted">
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="p-6 space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-primary" />
                  <h3 className="font-bold text-sm font-mono">PERSONA TRAITS</h3>
                  <span className="text-xs text-muted-foreground font-mono">// {persona.name}</span>
                </div>

                <Card className="bg-muted/30 border-border">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center border border-primary/30">
                        <User className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-sm">{persona.name}</h4>
                        <p className="text-xs text-muted-foreground mt-1">{persona.summary}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {Object.entries(persona.behavioralTraits).map(([key, value]) => (
                        <div key={key} className="space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-muted-foreground">{traitLabels[key]}</span>
                            <span className="text-[10px] font-mono text-primary">{value}%</span>
                          </div>
                          <Progress value={value} className="h-1" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Agent Selection */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-accent" />
                  <h3 className="font-bold text-sm font-mono">COGNITIVE AGENTS</h3>
                  <span className="text-xs text-muted-foreground font-mono">
                    // Select agents for deliberation ({selectedAgents.length}/5)
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {simulationAgents.map((agent) => {
                    const IconComponent = agentIcons[agent.icon] || Brain
                    const isSelected = selectedAgents.includes(agent.id)
                    return (
                      <Card
                        key={agent.id}
                        className={cn(
                          "cursor-pointer transition-all",
                          isSelected
                            ? "border-accent bg-accent/5"
                            : "border-border hover:border-muted-foreground/50 opacity-60",
                        )}
                        onClick={() => toggleAgent(agent.id)}
                      >
                        <CardContent className="p-3">
                          <div className="flex items-center gap-3">
                            <div
                              className={cn(
                                "w-8 h-8 rounded flex items-center justify-center border",
                                isSelected ? "bg-accent/20 border-accent/30" : "bg-muted/30 border-border",
                              )}
                            >
                              <IconComponent
                                className={cn("w-4 h-4", isSelected ? "text-accent" : "text-muted-foreground")}
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-xs truncate">{agent.name}</h4>
                              <p className="text-[10px] text-muted-foreground truncate">{agent.priority[0]}</p>
                            </div>
                            {isSelected && <Check className="w-4 h-4 text-accent flex-shrink-0" />}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>

              {/* Simulation Parameters */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-mono font-bold">Iterations</label>
                    <span className="text-sm font-mono text-primary">{iterations}</span>
                  </div>
                  <Slider
                    value={[iterations]}
                    onValueChange={([v]) => setIterations(v)}
                    min={10}
                    max={200}
                    step={10}
                    className="w-full"
                  />
                  <p className="text-[10px] text-muted-foreground font-mono">
                    Monte Carlo iterations for probability estimation
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-mono font-bold">Variability Weight</label>
                    <span className="text-sm font-mono text-primary">{variabilityWeight.toFixed(2)}</span>
                  </div>
                  <Slider
                    value={[variabilityWeight * 100]}
                    onValueChange={([v]) => setVariabilityWeight(v / 100)}
                    min={0}
                    max={100}
                    step={5}
                    className="w-full"
                  />
                  <p className="text-[10px] text-muted-foreground font-mono">
                    Randomness factor in agent deliberation (0 = deterministic)
                  </p>
                </div>
              </div>

              {/* Offers to simulate */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Gift className="w-4 h-4 text-primary" />
                  <h3 className="font-bold text-sm font-mono">OFFERS TO SIMULATE</h3>
                  <span className="text-xs text-muted-foreground font-mono">// {offers.length} shortlisted</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {offers.map((offer) => (
                    <Badge key={offer.id} variant="outline" className="font-mono text-xs">
                      {offer.title}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-border">
                <Button
                  onClick={handleStartSimulation}
                  disabled={selectedAgents.length === 0}
                  className="w-full font-mono bg-primary hover:bg-primary/90 glow-primary"
                >
                  <FlaskConical className="w-4 h-4 mr-2" />
                  Run Multi-Agent Simulation
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

function SendOfferOverlay({
  isOpen,
  onClose,
  passenger,
  offer,
  onConfirmSend,
}: {
  isOpen: boolean
  onClose: () => void
  passenger: Passenger
  offer: Offer
  onConfirmSend: () => void
}) {
  const [isGenerating, setIsGenerating] = useState(true)
  const [message, setMessage] = useState<GeneratedMessage | null>(null)
  const [isSending, setIsSending] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (isOpen && passenger && offer) {
      setIsGenerating(true)
      setMessage(null)
      const timer = setTimeout(() => {
        setMessage(generateMarketingMessage(passenger, offer))
        setIsGenerating(false)
      }, 2000)
      return () => clearTimeout(timer)
    }
  }, [isOpen, passenger, offer])

  const handleSend = () => {
    setIsSending(true)
    setTimeout(() => {
      toast({
        title: "Offer Sent Successfully",
        description: `${offer.title} sent to ${passenger.name} via ${passenger.commChannel}`,
      })
      setIsSending(false)
      onConfirmSend()
      onClose()
    }, 1500)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "Copied to clipboard",
      description: "Message content copied",
    })
  }

  if (!isOpen) return null

  const ChannelIcon = channelIcons[passenger.commChannel] || Mail

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto m-4"
      >
        <Card className="bg-card border-primary/30 corner-brackets shadow-2xl">
          <CardContent className="p-0">
            {/* Header */}
            <div className="p-6 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded bg-accent/10 flex items-center justify-center border border-accent/30">
                  <ChannelIcon className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <h2 className="text-lg font-bold font-mono text-primary">SEND_OFFER</h2>
                  <p className="text-xs text-muted-foreground font-mono">
                    AI-generated {passenger.commChannel.toLowerCase()} message
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-muted">
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="p-6 space-y-4">
              {isGenerating ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="w-16 h-16 rounded bg-accent/10 flex items-center justify-center border border-accent/30 mb-4">
                    <Sparkles className="w-8 h-8 text-accent animate-pulse" />
                  </div>
                  <p className="text-sm font-mono text-accent">Generating personalized message...</p>
                  <p className="text-xs text-muted-foreground font-mono mt-2">
                    Crafting {passenger.commChannel} content for {passenger.name}
                  </p>
                </div>
              ) : message ? (
                <>
                  {/* Recipient info */}
                  <div className="flex items-center gap-3 p-3 rounded bg-muted/30 border border-border">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                      <Users className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{passenger.name}</p>
                      <p className="text-xs text-muted-foreground font-mono">{passenger.email}</p>
                    </div>
                    <Badge variant="outline" className="font-mono text-xs">
                      <ChannelIcon className="w-3 h-3 mr-1" />
                      {passenger.commChannel}
                    </Badge>
                  </div>

                  {/* Message preview */}
                  <Card className="bg-background border-border">
                    <CardContent className="p-4 space-y-4">
                      {message.channel === "Email" && (
                        <div className="pb-3 border-b border-border">
                          <p className="text-xs text-muted-foreground font-mono mb-1">Subject:</p>
                          <p className="text-sm font-medium">{message.subject}</p>
                        </div>
                      )}

                      <div className="space-y-3 text-sm">
                        <p className="font-medium">{message.greeting}</p>
                        <p className="text-muted-foreground leading-relaxed">{message.body}</p>
                        <div className="p-3 rounded bg-primary/5 border border-primary/20">
                          <p className="text-foreground">{message.offerDetails}</p>
                        </div>
                        <p className="text-muted-foreground">{message.callToAction}</p>
                      </div>

                      {/* Coupon code */}
                      <div className="flex items-center justify-between p-3 rounded bg-accent/10 border border-accent/30">
                        <div>
                          <p className="text-[10px] font-mono text-accent uppercase tracking-wider mb-1">
                            Your Exclusive Code
                          </p>
                          <p className="text-lg font-bold font-mono tracking-widest text-accent">
                            {message.couponCode}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(message.couponCode)}
                          className="text-accent hover:bg-accent/10"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>

                      <p className="text-xs text-muted-foreground whitespace-pre-line">{message.footer}</p>
                    </CardContent>
                  </Card>

                  {/* Actions */}
                  <div className="flex items-center gap-3 pt-4 border-t border-border">
                    <Button variant="outline" onClick={onClose} className="flex-1 font-mono bg-transparent">
                      Cancel
                    </Button>
                    <Button
                      onClick={handleSend}
                      disabled={isSending}
                      className="flex-1 font-mono bg-primary hover:bg-primary/90 glow-primary"
                    >
                      {isSending ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send via {passenger.commChannel}
                        </>
                      )}
                    </Button>
                  </div>
                </>
              ) : null}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

export function Simulation({ passenger, shortlistedOffers, persona, onSendOffer, onNavigateHome }: SimulationProps) {
  const [showConfig, setShowConfig] = useState(false)
  const [isSimulating, setIsSimulating] = useState(false)
  const [simulationProgress, setSimulationProgress] = useState(0)
  const [results, setResults] = useState<OfferSimulationResult[]>([])
  const [expandedResults, setExpandedResults] = useState<string[]>([])
  const [selectedOfferForSend, setSelectedOfferForSend] = useState<Offer | null>(null)
  const [showSendOverlay, setShowSendOverlay] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    if (passenger && shortlistedOffers.length > 0 && persona && results.length === 0) {
      setShowConfig(true)
    }
  }, [passenger, shortlistedOffers, persona, results.length])

  const handleStartSimulation = (config: SimulationConfig) => {
    setShowConfig(false)
    setIsSimulating(true)
    setSimulationProgress(0)

    const selectedAgentObjects = simulationAgents.filter((a) => config.selectedAgents.includes(a.id))

    const interval = setInterval(() => {
      setSimulationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 2
      })
    }, 50)

    setTimeout(() => {
      clearInterval(interval)
      setSimulationProgress(100)

      const simulationResults = shortlistedOffers.map((offer) =>
        simulateAgentDebate(offer, config.persona!, selectedAgentObjects, config.iterations, config.variabilityWeight),
      )

      simulationResults.sort((a, b) => b.acceptanceLikelihood - a.acceptanceLikelihood)

      setTimeout(() => {
        setResults(simulationResults)
        setIsSimulating(false)
      }, 500)
    }, 3000)
  }

  const toggleResultExpansion = (offerId: string) => {
    setExpandedResults((prev) => (prev.includes(offerId) ? prev.filter((id) => id !== offerId) : [...prev, offerId]))
  }

  const handleSendOffer = (offer: Offer) => {
    setSelectedOfferForSend(offer)
    setShowSendOverlay(true)
  }

  const handleConfirmSend = () => {
    if (selectedOfferForSend) {
      onSendOffer(selectedOfferForSend)
    }
  }

  if (!passenger || shortlistedOffers.length === 0 || !persona) {
    return <EmptyState onNavigateHome={onNavigateHome} />
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <Terminal className="w-5 h-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight text-primary">SIMULATION_ENGINE</h1>
          </div>
          <p className="text-muted-foreground text-sm font-mono">
            <span className="text-primary">$</span> simulate --passenger="{passenger.name}" --offers=
            {shortlistedOffers.length}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={onNavigateHome} className="font-mono text-xs bg-transparent">
            <Home className="w-3.5 h-3.5 mr-1.5" />
            Back to Overview
          </Button>
          <Badge variant="outline" className="font-mono text-xs">
            {passenger.tier}
          </Badge>
          <Badge className="bg-primary/20 text-primary border-primary/30 font-mono text-xs">
            LTV: ${(passenger.ltv / 1000).toFixed(0)}K
          </Badge>
        </div>
      </div>

      {/* Simulation in progress */}
      <AnimatePresence>
        {isSimulating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center py-16"
          >
            <div className="relative mb-6">
              <div className="w-24 h-24 rounded bg-primary/10 flex items-center justify-center border border-primary/30">
                <FlaskConical className="w-12 h-12 text-primary" />
              </div>
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                className="absolute inset-0 rounded border-2 border-dashed border-primary/30"
              />
            </div>
            <p className="text-lg font-bold font-mono text-primary mb-2">Running Multi-Agent Simulation...</p>
            <p className="text-sm text-muted-foreground font-mono mb-6">
              Monte Carlo iterations across {shortlistedOffers.length} offers
            </p>
            <div className="w-64">
              <Progress value={simulationProgress} className="h-2" />
              <p className="text-xs text-muted-foreground font-mono text-center mt-2">{simulationProgress}% complete</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results */}
      <AnimatePresence>
        {results.length > 0 && !isSimulating && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-mono font-bold">SIMULATION RESULTS</span>
              <span className="text-xs text-muted-foreground font-mono">// Ranked by acceptance likelihood</span>
            </div>

            {results.map((result, index) => {
              const offer = shortlistedOffers.find((o) => o.id === result.offerId)!
              const isExpanded = expandedResults.includes(result.offerId)
              const recommendationColors = {
                highly_recommended: "text-chart-4 border-chart-4/30 bg-chart-4/10",
                recommended: "text-primary border-primary/30 bg-primary/10",
                neutral: "text-accent border-accent/30 bg-accent/10",
                not_recommended: "text-destructive border-destructive/30 bg-destructive/10",
              }

              return (
                <motion.div
                  key={result.offerId}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={cn("bg-card border-border", index === 0 && "border-chart-4/50 glow-primary")}>
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-4">
                          <div
                            className={cn(
                              "w-14 h-14 rounded flex items-center justify-center text-2xl font-bold font-mono border",
                              result.acceptanceLikelihood >= 75
                                ? "bg-chart-4/10 border-chart-4/30 text-chart-4"
                                : result.acceptanceLikelihood >= 55
                                  ? "bg-primary/10 border-primary/30 text-primary"
                                  : result.acceptanceLikelihood >= 40
                                    ? "bg-accent/10 border-accent/30 text-accent"
                                    : "bg-destructive/10 border-destructive/30 text-destructive",
                            )}
                          >
                            {result.acceptanceLikelihood}%
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              {index === 0 && (
                                <Badge className="bg-chart-4/20 text-chart-4 border-chart-4/30 text-[10px] font-mono">
                                  TOP PICK
                                </Badge>
                              )}
                              <h3 className="font-bold text-lg">{result.offerTitle}</h3>
                            </div>
                            <p className="text-xs text-muted-foreground">{offer.desc}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge
                            variant="outline"
                            className={cn("font-mono text-xs", recommendationColors[result.recommendation])}
                          >
                            {result.recommendation.replace("_", " ").toUpperCase()}
                          </Badge>
                          <Button
                            onClick={() => handleSendOffer(offer)}
                            className="font-mono bg-primary hover:bg-primary/90"
                          >
                            <Send className="w-4 h-4 mr-2" />
                            Send to {passenger.commChannel}
                          </Button>
                        </div>
                      </div>

                      {/* Stats row */}
                      <div className="grid grid-cols-3 gap-4 mb-4 p-3 rounded bg-muted/30 border border-border">
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground font-mono">Confidence</p>
                          <p className="text-lg font-bold font-mono text-primary">{result.confidence}%</p>
                        </div>
                        <div className="text-center border-x border-border">
                          <p className="text-xs text-muted-foreground font-mono">Variance</p>
                          <p className="text-lg font-bold font-mono text-accent">±{result.variance}%</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-muted-foreground font-mono">Fit Score</p>
                          <p className="text-lg font-bold font-mono text-foreground">{offer.fitScore}%</p>
                        </div>
                      </div>

                      {/* Expand toggle */}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleResultExpansion(result.offerId)}
                        className="w-full font-mono text-xs"
                      >
                        {isExpanded ? (
                          <>
                            <ChevronUp className="w-4 h-4 mr-2" />
                            Hide Agent Reasoning
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-4 h-4 mr-2" />
                            Show Agent Reasoning
                          </>
                        )}
                      </Button>

                      {/* Agent details */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4 pt-4 border-t border-border">
                              {result.agentResults.map((agentResult) => {
                                const agent = simulationAgents.find((a) => a.id === agentResult.agentId)
                                const IconComponent = agent ? agentIcons[agent.icon] || Brain : Brain
                                return (
                                  <div
                                    key={agentResult.agentId}
                                    className="p-3 rounded bg-muted/20 border border-border"
                                  >
                                    <div className="flex items-center gap-2 mb-2">
                                      <IconComponent className="w-4 h-4 text-accent" />
                                      <span className="text-xs font-mono font-bold">{agentResult.agentName}</span>
                                      <Badge
                                        variant="outline"
                                        className={cn(
                                          "ml-auto text-[9px] font-mono",
                                          agentResult.decision === "accept"
                                            ? "text-chart-4 border-chart-4/30"
                                            : agentResult.decision === "reject"
                                              ? "text-destructive border-destructive/30"
                                              : "text-accent border-accent/30",
                                        )}
                                      >
                                        {agentResult.probability}% {agentResult.decision}
                                      </Badge>
                                    </div>
                                    <p className="text-[11px] text-muted-foreground">{agentResult.reasoning}</p>
                                  </div>
                                )
                              })}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}

            {/* Re-run simulation button */}
            <div className="flex justify-center pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setResults([])
                  setShowConfig(true)
                }}
                className="font-mono"
              >
                <Settings2 className="w-4 h-4 mr-2" />
                Reconfigure & Re-run Simulation
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Config overlay */}
      <AnimatePresence>
        {showConfig && passenger && persona && (
          <SimulationConfigOverlay
            isOpen={showConfig}
            onClose={() => setShowConfig(false)}
            passenger={passenger}
            persona={persona}
            offers={shortlistedOffers}
            onStartSimulation={handleStartSimulation}
          />
        )}
      </AnimatePresence>

      {/* Send offer overlay */}
      <AnimatePresence>
        {showSendOverlay && passenger && selectedOfferForSend && (
          <SendOfferOverlay
            isOpen={showSendOverlay}
            onClose={() => {
              setShowSendOverlay(false)
              setSelectedOfferForSend(null)
            }}
            passenger={passenger}
            offer={selectedOfferForSend}
            onConfirmSend={handleConfirmSend}
          />
        )}
      </AnimatePresence>
    </motion.div>
  )
}
