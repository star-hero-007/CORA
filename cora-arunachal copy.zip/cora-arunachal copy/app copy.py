from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd
import numpy as np
import xgboost as xgb
import json
from datetime import datetime, timedelta
import os
from openai import OpenAI

app = Flask(__name__)
CORS(app)

PASSENGERS_JSON = 'passengers.json'
CSV_FILE = 'churn_predictions_enriched.csv'
MODEL_FILE = 'xgb_churn_model.json'

FEATURE_COLUMNS = [
    'booking_freq_change',
    'fare_downgrade_trend',
    'booking_abandon_rate',
    'recent_disruption_count',
    'recent_service_issues',
    'lounge_access_issues',
    'app_usage_drop',
    'email_engagement_drop',
    'loyalty_inactivity_days',
    'ancillary_spend_drop',
    'upgrade_acceptance_drop',
    'spend_per_trip_decline',
    'frustration_score_llm',
    'complaint_frequency_change',
    'churn_intent_signal_llm'
]

PERSONA_FEATURE_COLUMNS = [
    'avg_fare_per_km',
    'cabin_class_mix_ratio',
    'upgrade_acceptance_rate',
    'price_comparison_behavior_score',
    'mobile_first_engagement_score',
    'spontaneous_booking_rate',
    'meal_preference_intensity',
    'lounge_usage_frequency',
    'complaint_rate',
    'support_sentiment_score',
    'disruption_rebooking_rate',
    'loyalty_engagement_score',
    'competitor_search_frequency'
]

client = OpenAI(api_key="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")

def load_model():
    model = xgb.Booster()
    model.load_model(MODEL_FILE)
    return model

def calculate_risk_score(probability):
    return int(probability * 100)

def adjust_medium_risk(df, churn_mask):
    churn_indices = df[churn_mask].index.tolist()
    num_to_adjust = int(len(churn_indices) * 0.5)

    if num_to_adjust > 0:
        medium_risk_indices = np.random.choice(churn_indices, size=num_to_adjust, replace=False)
        for idx in medium_risk_indices:
            new_prob = np.random.uniform(0.4, 0.69)
            df.loc[idx, 'churn_probability'] = new_prob
            df.loc[idx, 'risk_score'] = calculate_risk_score(new_prob)

    return df

def llm_get_churn_driver_and_insights(features_dict, risk_score):
    prompt = f"""Analyze this airline passenger's churn risk and determine the PRIMARY churn driver.

Risk Score: {risk_score}%

Feature Values:
- Booking frequency change: {features_dict['booking_freq_change']:.2f}
- Fare downgrade trend: {features_dict['fare_downgrade_trend']:.2f}
- Booking abandon rate: {features_dict['booking_abandon_rate']:.2f}
- Recent disruptions: {features_dict['recent_disruption_count']:.0f}
- Service issues: {features_dict['recent_service_issues']:.0f}
- Lounge access issues: {features_dict['lounge_access_issues']:.0f}
- App usage drop: {features_dict['app_usage_drop']:.2f}
- Email engagement drop: {features_dict['email_engagement_drop']:.2f}
- Loyalty inactivity days: {features_dict['loyalty_inactivity_days']:.0f}
- Ancillary spend drop: {features_dict['ancillary_spend_drop']:.2f}
- Upgrade acceptance drop: {features_dict['upgrade_acceptance_drop']:.2f}
- Spend per trip decline: {features_dict['spend_per_trip_decline']:.2f}
- Frustration score: {features_dict['frustration_score_llm']:.2f}
- Complaint frequency change: {features_dict['complaint_frequency_change']:.2f}
- Churn intent signal: {features_dict['churn_intent_signal_llm']:.2f}

Determine the PRIMARY churn driver from: "Frequent Delays", "Service Failure", "Price Sensitivity", "Loyalty Neglect", "Route Changes", "Inactivity"

Provide JSON with:
{{
  "churn_driver": "one of the six categories",
  "insight": "brief explanation based on feature analysis",
  "top_contributing_features": ["feature1", "feature2", "feature3"]
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline customer retention analyst. Provide ONLY valid JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=500
        )
        
        raw_text = response.choices[0].message.content
        
        try:
            result = json.loads(raw_text)
            return result.get('churn_driver', 'Service Failure'), result
        except json.JSONDecodeError:
            start = raw_text.find('{')
            end = raw_text.rfind('}') + 1
            if start != -1 and end > start:
                result = json.loads(raw_text[start:end])
                return result.get('churn_driver', 'Service Failure'), result
            raise ValueError("Invalid JSON from LLM")
    except Exception as e:
        print(f"LLM analysis failed: {e}")
        return get_churn_driver_fallback(features_dict), {
            "churn_driver": get_churn_driver_fallback(features_dict),
            "insight": "Using rule-based analysis",
            "top_contributing_features": []
        }

def get_churn_driver_fallback(features_dict):
    drivers = {
        'Frequent Delays': features_dict.get('recent_disruption_count', 0),
        'Service Failure': features_dict.get('recent_service_issues', 0) + features_dict.get('lounge_access_issues', 0),
        'Price Sensitivity': features_dict.get('fare_downgrade_trend', 0),
        'Loyalty Neglect': features_dict.get('loyalty_inactivity_days', 0) / 100,
        'Route Changes': features_dict.get('booking_abandon_rate', 0),
        'Inactivity': features_dict.get('app_usage_drop', 0) + features_dict.get('email_engagement_drop', 0)
    }
    return max(drivers, key=drivers.get)

def generate_mock_passenger_data(passenger_id, row, features_dict, churn_driver, llm_insights):
    first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Avery", "Quinn", "Skylar", "Reese",
                   "Cameron", "Blake", "Parker", "Sage", "Dakota", "Phoenix", "River", "Rowan", "Emerson", "Finley"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
                  "Anderson", "Taylor", "Thomas", "Moore", "Jackson", "Martin", "Lee", "Thompson", "White", "Harris"]
    
    import random
    random.seed(hash(passenger_id))
    name = f"{random.choice(first_names)} {random.choice(last_names)}"
    
    email = f"{name.lower().replace(' ', '.')}.{passenger_id.lower()}@email.com"
    
    if row['risk_score'] >= 70:
        tier = random.choice(["Platinum", "Gold"])
    elif row['risk_score'] >= 40:
        tier = random.choice(["Gold", "Silver"])
    else:
        tier = random.choice(["Silver", "Bronze"])
    
    tier_ltv = {"Platinum": (50000, 80000), "Gold": (30000, 50000), "Silver": (15000, 30000), "Bronze": (5000, 15000)}
    ltv = random.randint(*tier_ltv[tier])
    
    comm_channel = random.choice(["Email", "WhatsApp", "App"])
    
    tier_flights = {"Platinum": (150, 250), "Gold": (80, 150), "Silver": (30, 80), "Bronze": (10, 30)}
    total_flights = random.randint(*tier_flights[tier])
    
    miles_balance = total_flights * random.randint(800, 1500)
    
    days_ago = random.randint(1, 90)
    last_flight = (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")
    
    sentiment_score = max(10, min(90, int(100 - row['risk_score'] + random.randint(-15, 15))))
    
    if row['risk_score'] >= 70:
        open_tickets = random.randint(2, 5)
    elif row['risk_score'] >= 40:
        open_tickets = random.randint(0, 2)
    else:
        open_tickets = 0
    
    timeline = generate_timeline(churn_driver, row['risk_score'], days_ago, features_dict, llm_insights)
    
    return {
        "id": passenger_id,
        "name": name,
        "email": email,
        "riskScore": int(row['risk_score']),
        "churnDriver": churn_driver,
        "ltv": ltv,
        "tier": tier,
        "commChannel": comm_channel,
        "lastFlight": last_flight,
        "totalFlights": total_flights,
        "milesBalance": miles_balance,
        "sentimentScore": sentiment_score,
        "openTickets": open_tickets,
        "timeline": timeline,
        "llmInsight": llm_insights.get('insight', ''),
        "topFeatures": llm_insights.get('top_contributing_features', [])
    }

def generate_timeline(churn_driver, risk_score, days_since_last_flight, features_dict, llm_insights):
    timeline = []
    
    last_flight_date = (datetime.now() - timedelta(days=days_since_last_flight)).strftime("%Y-%m-%d")
    
    recent_disruptions = int(features_dict.get('recent_disruption_count', 0))
    service_issues = int(features_dict.get('recent_service_issues', 0))
    inactivity_days = int(features_dict.get('loyalty_inactivity_days', 0))
    
    if churn_driver == "Frequent Delays":
        timeline = [
            {"date": last_flight_date, "event": f"Flight delayed {min(recent_disruptions, 4)} hours", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 15)).strftime("%Y-%m-%d"), 
             "event": "Previous flight delayed 2 hours", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 30)).strftime("%Y-%m-%d"), 
             "event": "Complained about delays", "type": "neg"},
        ]
    elif churn_driver == "Service Failure":
        events = []
        if service_issues > 0:
            events.append({"date": last_flight_date, "event": "Service issue - Request not fulfilled", "type": "neg"})
        if features_dict.get('lounge_access_issues', 0) > 0:
            events.append({"date": (datetime.now() - timedelta(days=days_since_last_flight + 10)).strftime("%Y-%m-%d"), 
                          "event": "Lounge access denied", "type": "neg"})
        events.append({"date": (datetime.now() - timedelta(days=days_since_last_flight + 25)).strftime("%Y-%m-%d"), 
                      "event": "Complaint escalated", "type": "neg"})
        timeline = events
    elif churn_driver == "Loyalty Neglect":
        timeline = [
            {"date": last_flight_date, "event": "Regular flight - No issues", "type": "neu"},
            {"date": (datetime.now() - timedelta(days=max(30, inactivity_days//2))).strftime("%Y-%m-%d"), 
             "event": "Miles expiration notice", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 35)).strftime("%Y-%m-%d"), 
             "event": "Competitor offer received", "type": "neg"},
        ]
    elif churn_driver == "Route Changes":
        timeline = [
            {"date": last_flight_date, "event": "Preferred route discontinued", "type": "neg"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 15)).strftime("%Y-%m-%d"), 
             "event": "Had to use connecting flight", "type": "neg"},
        ]
    elif churn_driver == "Inactivity":
        timeline = [
            {"date": last_flight_date, "event": f"Last flight - {days_since_last_flight} days ago", "type": "neu"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 20)).strftime("%Y-%m-%d"), 
             "event": "Ignored promotional email", "type": "neg"},
        ]
    else:
        timeline = [
            {"date": last_flight_date, "event": "Regular flight completed", "type": "neu"},
            {"date": (datetime.now() - timedelta(days=days_since_last_flight + 15)).strftime("%Y-%m-%d"), 
             "event": "Searched for cheaper alternatives", "type": "neg"},
        ]
    
    return timeline

def llm_generate_persona_traits(persona_features):
    prompt = f"""Analyze this airline passenger's behavioral data and generate 5-6 unique persona traits.

Passenger Features:
- Average fare per km: {persona_features.get('avg_fare_per_km', 0):.2f}
- Cabin class mix ratio: {persona_features.get('cabin_class_mix_ratio', 0):.2f}
- Upgrade acceptance rate: {persona_features.get('upgrade_acceptance_rate', 0):.2f}
- Price comparison behavior: {persona_features.get('price_comparison_behavior_score', 0):.2f}
- Mobile-first engagement: {persona_features.get('mobile_first_engagement_score', 0):.2f}
- Spontaneous booking rate: {persona_features.get('spontaneous_booking_rate', 0):.2f}
- Meal preference intensity: {persona_features.get('meal_preference_intensity', 0):.2f}
- Lounge usage frequency: {persona_features.get('lounge_usage_frequency', 0):.2f}
- Complaint rate: {persona_features.get('complaint_rate', 0):.2f}
- Support sentiment score: {persona_features.get('support_sentiment_score', 0):.2f}
- Disruption rebooking rate: {persona_features.get('disruption_rebooking_rate', 0):.2f}
- Loyalty engagement score: {persona_features.get('loyalty_engagement_score', 0):.2f}
- Competitor search frequency: {persona_features.get('competitor_search_frequency', 0):.2f}

Generate 5-6 behavioral traits as percentages (0-100) that describe this passenger's travel preferences and behaviors.

Examples of traits: price_sensitive, comfort_preferred, genz_traveller, food_focused, lounge_enthusiast, low_frustration_tolerance, loyalty_oriented, spontaneous_traveler, mobile_native, premium_seeker

Provide JSON:
{{
  "traits": {{
    "trait_name_1": percentage_value,
    "trait_name_2": percentage_value,
    ...
  }},
  "summary": "brief 1-2 sentence description of passenger archetype"
}}"""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline behavioral analyst. Generate passenger persona traits as JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=600
        )
        
        raw_text = response.choices[0].message.content
        result = json.loads(raw_text)
        return result
    except Exception as e:
        print(f"LLM persona generation failed: {e}")
        return generate_fallback_persona(persona_features)

def generate_fallback_persona(features):
    traits = {
        "price_sensitive": min(100, int(features.get('price_comparison_behavior_score', 50) * 100)),
        "comfort_preferred": min(100, int(features.get('cabin_class_mix_ratio', 0.3) * 100)),
        "mobile_native": min(100, int(features.get('mobile_first_engagement_score', 0.5) * 100)),
        "loyalty_oriented": min(100, int(features.get('loyalty_engagement_score', 0.5) * 100)),
        "low_frustration_tolerance": min(100, int(features.get('complaint_rate', 0) * 20))
    }
    return {
        "traits": traits,
        "summary": "Behavioral profile generated from travel patterns"
    }

@app.route('/api/refresh-predictions', methods=['POST'])
def refresh_predictions():
    try:
        df = pd.read_csv(CSV_FILE)

        if not all(col in df.columns for col in FEATURE_COLUMNS):
            return jsonify({'error': 'Missing required feature columns in CSV'}), 400

        X = df[FEATURE_COLUMNS]
        dmatrix = xgb.DMatrix(X)

        model = load_model()
        predictions = model.predict(dmatrix)

        df['churn_probability'] = predictions
        df['churn_prediction'] = (predictions >= 0.5).astype(int)
        df['risk_score'] = df['churn_probability'].apply(calculate_risk_score)

        churn_mask = df['churn_prediction'] == 1
        df = adjust_medium_risk(df, churn_mask)

        try:
            with open(PASSENGERS_JSON, 'r') as f:
                passengers_data = json.load(f)
        except FileNotFoundError:
            passengers_data = []

        passenger_dict = {p['id']: p for p in passengers_data}

        print(f"Processing {len(df)} passengers from CSV...")
        
        for idx, row in df.iterrows():
            passenger_id = row.get('passenger_id', f'PAX-{str(idx+100).zfill(3)}')
            
            features_dict = {col: row[col] for col in FEATURE_COLUMNS}
            
            print(f"Analyzing passenger {passenger_id} with LLM...")
            churn_driver, llm_insights = llm_get_churn_driver_and_insights(features_dict, row['risk_score'])
            print(f"  - Churn Driver: {churn_driver}")

            if passenger_id in passenger_dict:
                p = passenger_dict[passenger_id]
                p['riskScore'] = int(row['risk_score'])
                p['churnDriver'] = churn_driver
                p['llmInsight'] = llm_insights.get('insight', '')
                p['topFeatures'] = llm_insights.get('top_contributing_features', [])
                print(f"  - Updated existing passenger")
            else:
                new_passenger = generate_mock_passenger_data(
                    passenger_id, 
                    row, 
                    features_dict, 
                    churn_driver,
                    llm_insights
                )
                passenger_dict[passenger_id] = new_passenger
                print(f"  - Created new passenger")

        updated_passengers = list(passenger_dict.values())
        
        with open(PASSENGERS_JSON, 'w') as f:
            json.dump(updated_passengers, f, indent=2)

        print(f"Saved {len(updated_passengers)} passengers to {PASSENGERS_JSON}")

        high_risk = len(df[df['risk_score'] >= 70])
        medium_risk = len(df[(df['risk_score'] >= 40) & (df['risk_score'] < 70)])
        low_risk = len(df[df['risk_score'] < 40])
        at_risk = high_risk + medium_risk

        return jsonify({
            'success': True,
            'message': 'Predictions updated successfully',
            'statistics': {
                'total': len(updated_passengers),
                'at_risk': at_risk,
                'high_risk': high_risk,
                'medium_risk': medium_risk,
                'low_risk': low_risk
            },
            'timestamp': datetime.now().isoformat()
        })

    except FileNotFoundError as e:
        return jsonify({'error': f'File not found: {str(e)}'}), 404
    except Exception as e:
        print(f"Prediction update failed: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Prediction update failed: {str(e)}'}), 500

@app.route('/api/passengers', methods=['GET'])
def get_passengers():
    try:
        with open(PASSENGERS_JSON, 'r') as f:
            passengers = json.load(f)
        return jsonify(passengers)
    except FileNotFoundError:
        return jsonify({'error': 'Passengers data not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/statistics', methods=['GET'])
def get_statistics():
    try:
        with open(PASSENGERS_JSON, 'r') as f:
            passengers = json.load(f)

        high_risk = len([p for p in passengers if p['riskScore'] >= 70])
        medium_risk = len([p for p in passengers if 40 <= p['riskScore'] < 70])
        low_risk = len([p for p in passengers if p['riskScore'] < 40])
        at_risk = high_risk + medium_risk

        return jsonify({
            'total': len(passengers),
            'at_risk': at_risk,
            'high_risk': high_risk,
            'medium_risk': medium_risk,
            'low_risk': low_risk
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/generate-persona', methods=['POST'])
def generate_persona():
    try:
        data = request.json
        passenger_id = data.get('passenger_id')

        if not passenger_id:
            return jsonify({'error': 'passenger_id is required'}), 400

        df = pd.read_csv(CSV_FILE)
        passenger_row = df[df['passenger_id'] == passenger_id]

        if passenger_row.empty:
            return jsonify({'error': 'Passenger not found in CSV'}), 404

        missing_cols = [col for col in PERSONA_FEATURE_COLUMNS if col not in df.columns]
        if missing_cols:
            return jsonify({'error': f'Missing persona feature columns: {missing_cols}'}), 400

        persona_features = passenger_row[PERSONA_FEATURE_COLUMNS].iloc[0].to_dict()
        
        print(f"Generating persona for {passenger_id}...")
        persona_data = llm_generate_persona_traits(persona_features)
        
        with open(PASSENGERS_JSON, 'r') as f:
            passengers = json.load(f)
        
        passenger = next((p for p in passengers if p['id'] == passenger_id), None)
        if not passenger:
            return jsonify({'error': 'Passenger not found in passengers.json'}), 404

        result = {
            'passenger_id': passenger_id,
            'passenger_name': passenger['name'],
            'traits': persona_data.get('traits', {}),
            'summary': persona_data.get('summary', ''),
            'raw_features': persona_features,
            'timestamp': datetime.now().isoformat()
        }

        return jsonify(result)

    except Exception as e:
        print(f"Persona generation failed: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Persona generation failed: {str(e)}'}), 500

@app.route('/api/analyze-passenger', methods=['POST'])
def analyze_passenger():
    try:
        data = request.json
        passenger_id = data.get('passenger_id')

        if not passenger_id:
            return jsonify({'error': 'passenger_id is required'}), 400

        with open(PASSENGERS_JSON, 'r') as f:
            passengers = json.load(f)

        passenger = next((p for p in passengers if p['id'] == passenger_id), None)

        if not passenger:
            return jsonify({'error': 'Passenger not found'}), 404

        df = pd.read_csv(CSV_FILE)
        passenger_row = df[df['passenger_id'] == passenger_id]

        if passenger_row.empty:
            return jsonify({'error': 'Passenger features not found'}), 404

        features = passenger_row[FEATURE_COLUMNS].iloc[0].to_dict()
        risk_score = passenger['riskScore']

        prompt = f"""Analyze this passenger's churn risk in detail.

Passenger: {passenger['name']} ({passenger_id})
Risk Score: {risk_score}%
Tier: {passenger['tier']}
LTV: ${passenger['ltv']:,}
Total Flights: {passenger['totalFlights']}
Miles Balance: {passenger['milesBalance']:,}
Last Flight: {passenger['lastFlight']}
Sentiment Score: {passenger['sentimentScore']}%
Open Tickets: {passenger['openTickets']}
Current Churn Driver: {passenger['churnDriver']}

Feature Analysis:
- Booking frequency change: {features['booking_freq_change']:.2f}
- Fare downgrade trend: {features['fare_downgrade_trend']:.2f}
- Booking abandon rate: {features['booking_abandon_rate']:.2f}
- Recent disruptions: {features['recent_disruption_count']:.0f}
- Service issues: {features['recent_service_issues']:.0f}
- Lounge access issues: {features['lounge_access_issues']:.0f}
- App usage drop: {features['app_usage_drop']:.2f}
- Email engagement drop: {features['email_engagement_drop']:.2f}
- Loyalty inactivity days: {features['loyalty_inactivity_days']:.0f}
- Ancillary spend drop: {features['ancillary_spend_drop']:.2f}
- Upgrade acceptance drop: {features['upgrade_acceptance_drop']:.2f}
- Spend per trip decline: {features['spend_per_trip_decline']:.2f}
- Frustration score: {features['frustration_score_llm']:.2f}
- Complaint frequency change: {features['complaint_frequency_change']:.2f}
- Churn intent signal: {features['churn_intent_signal_llm']:.2f}

Provide JSON:
{{
  "primary_driver": "confirm or refine churn driver",
  "top_factors": ["factor1", "factor2", "factor3", "factor4"],
  "insights": "2-3 sentences explaining churn risk",
  "recommended_actions": ["action1", "action2", "action3"]
}}"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are an airline customer retention analyst. Provide detailed analysis as JSON."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1500
        )
        
        analysis = json.loads(response.choices[0].message.content)

        result = {
            'passenger': passenger,
            'features': features,
            'analysis': analysis,
            'timestamp': datetime.now().isoformat()
        }

        return jsonify(result)

    except Exception as e:
        print(f"Analysis failed: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

if __name__ == '__main__':
    os.makedirs('data', exist_ok=True)
    os.makedirs('models', exist_ok=True)
    app.run(debug=True, host='0.0.0.0', port=5000)